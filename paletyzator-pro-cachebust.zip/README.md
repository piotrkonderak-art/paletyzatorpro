# Paletyzator Pro — wizualizacja 3D

Samodzielna aplikacja przeglądarkowa do wymiarowania palet (mieszanka SKU + kalkulator pojedynczy + baza SKU) z modelem 3D (Three.js) i dokumentem CMR. UI w układzie topbar/zakładki jak w referencyjnej aplikacji Vite „paletyzator”.

## Jak uruchomić

### Konta e-mail (Supabase + Resend)

Pełna instrukcja: **[`../supabase-auth-setup.md`](../supabase-auth-setup.md)**.

1. Skopiuj `js/config.example.js` → `js/config.js`.
2. Wklej `supabaseUrl`, `supabaseAnonKey`, `siteUrl` (publiczny HTTPS).
3. W Supabase włącz Email Auth + Redirect URLs; w SMTP ustaw Resend (`smtp.resend.com`).
4. Uruchom przez serwer lokalny lub hosting — **nie** polegaj na `file://` dla linków z e-maila.

Bez `config.js` działa **Tryb demonstracyjny** (przycisk na ekranie logowania).

### Telefon (iOS / Android) — jeden plik

Pobierz **`../paletyzator-pro-mobile.html`** (obok tego folderu w `docs/`).

1. Zapisz plik w **Pliki** (iOS) lub **Pobrane** (Android).
2. Otwórz go w **Safari** / **Chrome** (dotknij plik → Udostępnij → Safari / Otwórz w…).
3. Kliknij **Tryb demonstracyjny** (albo hostuj plik pod HTTPS i uzupełnij config pod konta e-mail).
4. 3D: jeden palec = obrót, uszczypnięcie = zoom. Potrzebny internet (Three.js + opcjonalnie Supabase z CDN).

> Linki potwierdzenia / resetu hasła **wymagają publicznego URL** — otwarcie z Pobranych (`file://`) nie obsłuży redirectów z e-maila.

### Opcja A — bezpośrednio w przeglądarce (komputer)

1. Otwórz plik `index.html` (podwójne kliknięcie lub przeciągnij do Chrome / Edge / Firefox).
2. Kliknij **Tryb demonstracyjny** albo skonfiguruj Supabase i zaloguj się e-mailem.
3. Przejdź do **Kalkulator** → ustaw kartony i paletę → **Oblicz paletyzację**.
4. W panelu **Wizualizacja 3D**: LPM = obrót, scroll = zoom, PPM / Shift+LPM = pan.

> Uwaga: Three.js i Supabase JS ładują się z CDN (`cdn.jsdelivr.net`). Potrzebne jest połączenie z internetem. Jeśli przeglądarka blokuje moduły ES przy `file://`, użyj opcji B albo pliku mobilnego.

### Opcja B — prosty serwer lokalny (zalecane przy Auth)

W katalogu tej aplikacji:

```bash
# Python 3
python3 -m http.server 8080

# albo Node (npx)
npx --yes serve -p 8080
```

Następnie otwórz: [http://localhost:8080](http://localhost:8080)  
Ustaw `siteUrl: 'http://localhost:8080'` w `js/config.js` i dodaj ten adres w Redirect URLs w Supabase.

## Co zawiera

| Ścieżka | Opis |
|---------|------|
| `index.html` | UI (PL) — auth, kalkulator, SKU, historia, ustawienia, CMR |
| `css/styles.css` | Style |
| `js/config.example.js` | Wzór konfiguracji Supabase (kopiuj do `config.js`) |
| `js/config.js` | Lokalne klucze (nie commituj produkcji) |
| `js/supabase-auth.js` | Klient Auth (sign-up, login, reset, resend) |
| `js/packing.js` | Algorytm warstwowy + pozycje kartonów (x, y, z) |
| `js/viewer3d.js` | Scena Three.js — paleta EUR, tektura, branding |
| `js/cmr.js` | List przewozowy CMR (pola 1–24, druk / PDF) |
| `js/app.js` | Logika aplikacji, localStorage, UI Auth |
| `assets/logo-paletyzator-pro.png` | Logo na kartonach 3D i w CMR |

Po **Oblicz paletyzację** przycisk **CMR** obok wizualizacji 3D otwiera edytowalny list przewozowy (druk / PDF). Dane nadawcy/odbiorcy: **Ustawienia**.

## Dane

- Produkty SKU i historia obliczeń: **localStorage** (klucz zależny od konta).
- Konta e-mail: **Supabase Auth** (sesja w przeglądarce); maile przez **Resend SMTP**.
- Domyślne produkty demo: `KARTON001` (40×30×20), `KARTON002` (60×40×30).

## Sterowanie 3D

- **LPM + przeciąganie** — orbit (obrót wokół palety)
- **Scroll** — zoom
- **PPM** lub **Shift + LPM** — pan
- **Reset kamery** — przywraca widok na cały ładunek
