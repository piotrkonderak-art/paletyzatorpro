# Kraj docelowy + limity kurierów

Moduł: `js/courier-rules.js` (ładowany przed `app.js`).

## Jak działa

1. Po **Oblicz paletyzację** w karcie wyniku pojawia się wybór **kraju docelowego** (pełna lista ISO, etykiety PL + wyszukiwanie).
2. Silnik porównuje **wysokość całkowitą** (`height` cm) i **masę ułożonych kartonów** (`weight` kg) oraz podstawę `L×W` z:
   - limitem regionalnym kraju (UE/EOG vs reszta świata),
   - limitami każdego kuriera (masa, wysokość, opcjonalnie euro-paleta).
3. UI pokazuje **pass/fail** dla kraju oraz listę kurierów z kryteriami, pasmami cen („od … zł”) i powodem odrzucenia.

## Założenia

Limity i ceny są **orientacyjne** (PL origin, typowe usługi paletowe/freight 2024–2025). Nie zastępują oferty umownej. Szczegóły w komentarzu nagłówkowym `courier-rules.js`.

## i18n

Klucze `courier.*` w `js/i18n.js` — PL pełne, EN/DE stuby.
