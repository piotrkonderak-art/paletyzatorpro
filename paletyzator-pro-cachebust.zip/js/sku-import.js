/**
 * Paletyzator Pro — import CSV / Excel (xlsx via SheetJS CDN) do bazy SKU.
 * Elastyczne mapowanie nagłówków + walidacja liczb.
 */
(function (global) {
  'use strict';

  const SHEETJS_CDN =
    'https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js';

  const HEADER_ALIASES = {
    sku: [
      'sku',
      'kod',
      'code',
      'product_code',
      'productcode',
      'index',
      'indeks',
      'artikel',
      'artnr',
      'art_nr',
    ],
    name: [
      'name',
      'nazwa',
      'product',
      'produkt',
      'description',
      'opis',
      'bezeichnung',
      'title',
      'tytul',
      'tytuł',
    ],
    l: [
      'l',
      'length',
      'dlugosc',
      'długość',
      'dlugość',
      'dl',
      'd',
      'len',
      'lange',
      'länge',
      'depth',
    ],
    w: [
      'w',
      'width',
      'szerokosc',
      'szerokość',
      'szer',
      's',
      'wid',
      'breite',
    ],
    h: [
      'h',
      'height',
      'wysokosc',
      'wysokość',
      'wys',
      'hei',
      'hohe',
      'höhe',
    ],
    weight: [
      'weight',
      'waga',
      'masa',
      'kg',
      'wt',
      'gewicht',
      'mass',
    ],
    qty: [
      'qty',
      'quantity',
      'ilosc',
      'ilość',
      'count',
      'szt',
      'sztuki',
      'menge',
      'anzahl',
    ],
  };

  function normHeader(h) {
    return String(h || '')
      .trim()
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^a-z0-9_]+/g, '_')
      .replace(/^_|_$/g, '');
  }

  function mapHeaders(headers) {
    const mapping = {};
    const used = new Set();
    const norms = headers.map((h, i) => ({ i, raw: h, n: normHeader(h) }));

    // 1) dokładne dopasowanie aliasów
    for (const field of Object.keys(HEADER_ALIASES)) {
      for (const alias of HEADER_ALIASES[field]) {
        const a = normHeader(alias);
        const hit = norms.find((x) => !used.has(x.i) && x.n === a);
        if (hit) {
          mapping[field] = hit.i;
          used.add(hit.i);
          break;
        }
      }
    }
    // 2) prefiks / zawiera tylko dla dłuższych aliasów (≥3), bez kolizji z już użytymi
    for (const field of Object.keys(HEADER_ALIASES)) {
      if (mapping[field] != null) continue;
      for (const alias of HEADER_ALIASES[field]) {
        const a = normHeader(alias);
        if (a.length < 3) continue;
        const hit = norms.find(
          (x) =>
            !used.has(x.i) &&
            (x.n === a || x.n.startsWith(a + '_') || x.n.endsWith('_' + a))
        );
        if (hit) {
          mapping[field] = hit.i;
          used.add(hit.i);
          break;
        }
      }
    }
    return mapping;
  }

  function parseNumber(v) {
    if (v == null || v === '') return NaN;
    if (typeof v === 'number') return v;
    let s = String(v).trim().replace(/\s/g, '');
    if (!s) return NaN;
    // 1.234,56 → 1234.56 ; 1,234.56 → 1234.56
    if (/^\d{1,3}(\.\d{3})+(,\d+)?$/.test(s)) {
      s = s.replace(/\./g, '').replace(',', '.');
    } else if (s.includes(',') && !s.includes('.')) {
      s = s.replace(',', '.');
    } else {
      s = s.replace(/,/g, '');
    }
    const n = Number(s);
    return Number.isFinite(n) ? n : NaN;
  }

  function detectDelimiter(src) {
    const first = String(src).split(/\r?\n/)[0] || '';
    // Ignoruj przecinki w cudzysłowach — zlicz poza quotes
    let commas = 0;
    let semis = 0;
    let tabs = 0;
    let inQ = false;
    for (let i = 0; i < first.length; i++) {
      const ch = first[i];
      if (ch === '"') {
        inQ = !inQ;
        continue;
      }
      if (inQ) continue;
      if (ch === ',') commas++;
      else if (ch === ';') semis++;
      else if (ch === '\t') tabs++;
    }
    if (tabs >= semis && tabs >= commas && tabs > 0) return '\t';
    if (semis >= commas && semis > 0) return ';';
    return ',';
  }

  function parseCsvText(text) {
    const rows = [];
    let row = [];
    let cur = '';
    let inQuotes = false;
    const src = String(text || '').replace(/^\uFEFF/, '');
    const delim = detectDelimiter(src);
    for (let i = 0; i < src.length; i++) {
      const ch = src[i];
      const next = src[i + 1];
      if (inQuotes) {
        if (ch === '"' && next === '"') {
          cur += '"';
          i++;
        } else if (ch === '"') {
          inQuotes = false;
        } else {
          cur += ch;
        }
        continue;
      }
      if (ch === '"') {
        inQuotes = true;
        continue;
      }
      if (ch === delim) {
        row.push(cur);
        cur = '';
        continue;
      }
      if (ch === '\n') {
        row.push(cur);
        rows.push(row);
        row = [];
        cur = '';
        continue;
      }
      if (ch === '\r') continue;
      cur += ch;
    }
    row.push(cur);
    if (row.some((c) => String(c).trim() !== '')) rows.push(row);
    return rows;
  }

  function rowsToProducts(matrix) {
    if (!matrix || !matrix.length) {
      return { products: [], errors: ['empty'], mapping: {}, headers: [] };
    }
    const headers = matrix[0].map((h) => String(h ?? '').trim());
    const mapping = mapHeaders(headers);
    const errors = [];
    const products = [];

    if (mapping.sku == null && mapping.name == null) {
      errors.push('needSkuOrName');
    }
    if (mapping.l == null || mapping.w == null || mapping.h == null) {
      errors.push('needDims');
    }

    for (let r = 1; r < matrix.length; r++) {
      const cells = matrix[r];
      if (!cells || !cells.some((c) => String(c ?? '').trim() !== '')) continue;

      const get = (field) =>
        mapping[field] != null ? cells[mapping[field]] : '';

      const skuRaw = String(get('sku') ?? '').trim();
      const nameRaw = String(get('name') ?? '').trim();
      const l = parseNumber(get('l'));
      const w = parseNumber(get('w'));
      const h = parseNumber(get('h'));
      const weightRaw = get('weight');
      const weight =
        weightRaw === '' || weightRaw == null ? 0 : parseNumber(weightRaw);
      const qtyRaw = get('qty');
      const qty =
        qtyRaw === '' || qtyRaw == null
          ? null
          : Math.floor(parseNumber(qtyRaw));

      const rowErrs = [];
      if (!skuRaw && !nameRaw) rowErrs.push('sku');
      if (!(l > 0)) rowErrs.push('l');
      if (!(w > 0)) rowErrs.push('w');
      if (!(h > 0)) rowErrs.push('h');
      if (weightRaw !== '' && weightRaw != null && !(weight >= 0)) {
        rowErrs.push('weight');
      }
      if (qty != null && !(qty >= 0)) rowErrs.push('qty');

      if (rowErrs.length) {
        errors.push({ row: r + 1, fields: rowErrs });
        continue;
      }

      products.push({
        sku: skuRaw || nameRaw.slice(0, 40) || 'SKU-' + r,
        name: nameRaw || skuRaw,
        l,
        w,
        h,
        weight: weight >= 0 ? weight : 0,
        qty: qty,
        _row: r + 1,
      });
    }

    return { products, errors, mapping, headers };
  }

  function parseCsv(text) {
    return rowsToProducts(parseCsvText(text));
  }

  let _xlsxLoading = null;
  function loadSheetJs() {
    if (global.XLSX) return Promise.resolve(global.XLSX);
    if (_xlsxLoading) return _xlsxLoading;
    _xlsxLoading = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = SHEETJS_CDN;
      s.async = true;
      s.onload = () => {
        if (global.XLSX) resolve(global.XLSX);
        else reject(new Error('SheetJS failed to load'));
      };
      s.onerror = () => reject(new Error('SheetJS CDN error'));
      document.head.appendChild(s);
    });
    return _xlsxLoading;
  }

  async function parseFile(file) {
    const name = (file && file.name) || '';
    const lower = name.toLowerCase();
    if (lower.endsWith('.xlsx') || lower.endsWith('.xls')) {
      const XLSX = await loadSheetJs();
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: 'array' });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const matrix = XLSX.utils.sheet_to_json(sheet, {
        header: 1,
        defval: '',
        raw: false,
      });
      return rowsToProducts(matrix);
    }
    const text = await file.text();
    return parseCsv(text);
  }

  global.PaletyzatorSkuImport = {
    HEADER_ALIASES,
    mapHeaders,
    parseNumber,
    parseCsv,
    parseCsvText,
    parseFile,
    rowsToProducts,
    loadSheetJs,
  };
})(typeof window !== 'undefined' ? window : globalThis);
