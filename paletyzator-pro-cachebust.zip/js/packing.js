/**
 * Paletyzator Pro — stabilne układanie z pozycjami 3D.
 *
 * Zasady:
 * 1. Większa stopa / cięższe najpierw (na dole).
 * 2. Każdy karton musi mieć ≥92% podparcia (paleta lub wierzchy poniżej).
 * 3. Tolerancja = max. zwis poza krawędź palety — tylko gdy potrzebny,
 *    bez rozszerzania footprintu i bez przesuwania kartonów, które już mieszczą się.
 * 4. 6 orientacji axis-aligned (dowolna ściana na dole) — wybór najlepszej.
 * 5. Clustering: te same SKU / rozmiary kładź obok siebie, bez rozsiania po kieszeniach.
 */
(function (global) {
  'use strict';

  const SUPPORT_MIN = 0.92;
  const EPS = 1e-6;

  function areaOf(l, w) {
    return l * w;
  }

  /** Max możliwa stopa spośród 6 orientacji (dowolna ściana na dole). */
  function maxBaseArea(l, w, h) {
    return Math.max(l * w, l * h, w * h);
  }

  /**
   * Wszystkie unikalne orientacje axis-aligned L×W×H
   * (l,w = stopa na palecie; h = wysokość).
   */
  function allFaceOrients(l, w, h) {
    const raw = [
      { l, w, h },
      { l: w, w: l, h },
      { l, w: h, h: w },
      { l: h, w: l, h: w },
      { l: w, w: h, h: l },
      { l: h, w, h: l },
    ];
    const out = [];
    for (const o of raw) {
      if (
        !out.some(
          (u) =>
            Math.abs(u.l - o.l) < EPS &&
            Math.abs(u.w - o.w) < EPS &&
            Math.abs(u.h - o.h) < EPS
        )
      ) {
        out.push(o);
      }
    }
    return out;
  }

  function rectOverlapArea(a, b) {
    const x0 = Math.max(a.x, b.x);
    const y0 = Math.max(a.y, b.y);
    const x1 = Math.min(a.x + a.l, b.x + b.l);
    const y1 = Math.min(a.y + a.w, b.y + b.w);
    if (x1 <= x0 + EPS || y1 <= y0 + EPS) return 0;
    return (x1 - x0) * (y1 - y0);
  }

  /**
   * Układ jednej warstwy (legacy / pomocniczy) — też 6 orientacji.
   * Tolerancja: pozwala wystawać poza L/W o ≤ tol, tylko gdy potrzeba.
   */
  function packLayer(items, L, W, tol = 0) {
    const t = Math.max(0, Number(tol) || 0);
    const remaining = items
      .map((b, i) => ({ ...b, remaining: b.count, idx: i }))
      .sort(
        (a, b) =>
          maxBaseArea(b.l, b.w, b.h) - maxBaseArea(a.l, a.w, a.h) ||
          (b.weight || 0) - (a.weight || 0)
      );
    const placed = [];
    const placements = [];
    let usedDepth = 0;
    let total = 0;

    while (remaining.some((b) => b.remaining > 0)) {
      const candidates = remaining
        .filter((b) => b.remaining > 0)
        .sort(
          (a, b) =>
            maxBaseArea(b.l, b.w, b.h) - maxBaseArea(a.l, a.w, a.h) ||
            (b.weight || 0) - (a.weight || 0)
        );

      let first = null;
      for (const b of candidates) {
        for (const o of allFaceOrients(b.l, b.w, b.h)) {
          const depthLeft = W - usedDepth;
          if (o.l <= L + t + EPS && o.w <= depthLeft + t + EPS) {
            first = { b, a: o.l, c: o.w, h: o.h };
            break;
          }
        }
        if (first) break;
      }
      if (!first) break;

      let rowDepth = first.c;
      let rowH = first.h;
      const rowItems = [];
      let cursorX = 0;

      for (const b of candidates) {
        if (b.remaining <= 0) continue;
        const depthLeft = W - usedDepth;
        const choices = allFaceOrients(b.l, b.w, b.h).filter((o) => {
          if (cursorX + o.l > L + t + EPS) return false;
          if (o.w > depthLeft + t + EPS) return false;
          if (rowItems.length && Math.abs(o.w - rowDepth) > EPS) return false;
          if (rowItems.length && Math.abs(o.h - rowH) > EPS) return false;
          return true;
        });
        if (!choices.length) continue;
        // Największa stopa w rzędzie, potem dłuższy bok wzdłuż L
        choices.sort(
          (x, y) => areaOf(y.l, y.w) - areaOf(x.l, x.w) || y.l - x.l
        );
        const o = choices[0];
        const a = o.l;
        const c = o.w;
        if (rowItems.length === 0) {
          rowDepth = c;
          rowH = o.h;
        }

        let n = 0;
        let x = cursorX;
        while (b.remaining - n > 0) {
          const end = x + a;
          if (end <= L + EPS) {
            n++;
            x = end;
            continue;
          }
          if (end <= L + t + EPS && x < L + EPS) {
            n++;
            x = end;
          }
          break;
        }
        if (n <= 0) continue;

        rowItems.push({ idx: b.idx, n, l: a, w: c, h: o.h, startX: cursorX });
        for (let i = 0; i < n; i++) {
          placements.push({
            idx: b.idx,
            x: cursorX + i * a,
            y: usedDepth,
            l: a,
            w: c,
            h: o.h,
          });
        }
        b.remaining -= n;
        cursorX += n * a;
        total += n;
        if (cursorX >= L - EPS) break;
      }

      if (!rowItems.length) break;
      placed.push(...rowItems);
      usedDepth += rowDepth;
      if (usedDepth >= W - EPS) break;
    }

    return {
      placed,
      placements,
      total,
      remaining: remaining.reduce((s, b) => s + b.remaining, 0),
    };
  }

  /**
   * Wysokość oparcia (grawitacja): max wierzchołków przecinających footprint,
   * albo 0 = paleta. Nie bierze „pustego” z=0 gdy coś już zajmuje XY.
   */
  function restingSupport(foot, placed) {
    let restZ = 0;
    for (const p of placed) {
      if (rectOverlapArea(foot, p) > EPS) {
        restZ = Math.max(restZ, p.z + p.h);
      }
    }

    let supported = 0;
    if (restZ < EPS) {
      // Na palecie — podparcie = część footprintu leżąca na powierzchni palety
      // (zwis poza paletą nie jest podparty przez paletę; liczymy to osobno w callerze)
      supported = foot.l * foot.w; // caller ogranicza zwis; tu pełne przy z=0
    } else {
      for (const p of placed) {
        if (Math.abs(p.z + p.h - restZ) > 0.05) continue;
        supported += rectOverlapArea(foot, p);
      }
    }
    const ratio = supported / (foot.l * foot.w);
    return { z: restZ, ratio };
  }

  function collides(foot, z, h, placed) {
    const top = z + h;
    for (const p of placed) {
      const pTop = p.z + p.h;
      if (top <= p.z + EPS || z >= pTop - EPS) continue;
      if (rectOverlapArea(foot, p) > EPS) return true;
    }
    return false;
  }

  /**
   * Czy footprint jest dopuszczalny względem palety L×W z tolerancją tol.
   * Karton może wystawać poza [0,L]×[0,W] o co najwyżej tol z każdej strony.
   * Nie wymagamy „rozszerzonego” prostokąta — tylko max overhang ≤ tol.
   */
  function withinTolerance(foot, L, W, tol) {
    const left = Math.max(0, -foot.x);
    const bottom = Math.max(0, -foot.y);
    const right = Math.max(0, foot.x + foot.l - L);
    const top = Math.max(0, foot.y + foot.w - W);
    return left <= tol + EPS && right <= tol + EPS && bottom <= tol + EPS && top <= tol + EPS;
  }

  function candidateAnchors(placed, L, W, tol) {
    const pts = [{ x: 0, y: 0 }];
    for (const p of placed) {
      pts.push(
        { x: p.x, y: p.y },
        { x: p.x + p.l, y: p.y },
        { x: p.x, y: p.y + p.w },
        { x: p.x + p.l, y: p.y + p.w },
        { x: 0, y: p.y },
        { x: p.x, y: 0 },
        { x: L, y: p.y },
        { x: p.x, y: W }
      );
    }
    // Gęstsza siatka na powierzchni palety (bez sztucznego rozszerzania)
    for (let x = 0; x <= L + EPS; x += 4) {
      for (let y = 0; y <= W + EPS; y += 4) {
        pts.push({ x, y });
      }
    }
    // Kotwice lekko poza krawędzią — tylko do zwisu ≤ tol (gdy tol>0)
    if (tol > EPS) {
      for (let x = -tol; x <= L + tol + EPS; x += Math.max(2, tol)) {
        pts.push({ x, y: 0 }, { x, y: W });
      }
      for (let y = -tol; y <= W + tol + EPS; y += Math.max(2, tol)) {
        pts.push({ x: 0, y }, { x: L, y });
      }
    }

    const seen = new Set();
    const out = [];
    for (const p of pts) {
      const key = `${Math.round(p.x * 10)}_${Math.round(p.y * 10)}`;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(p);
    }
    return out;
  }

  function sameFamily(unit, p) {
    if (unit.idx === p.idx) return true;
    if (unit.productId && p.productId && unit.productId === p.productId) return true;
    // Ten sam rozmiar bazowy (niezależnie od orientacji)
    const ua = [unit.l, unit.w, unit.h].sort((a, b) => a - b);
    const pa = [p.l, p.w, p.h].sort((a, b) => a - b);
    return (
      Math.abs(ua[0] - pa[0]) < EPS &&
      Math.abs(ua[1] - pa[1]) < EPS &&
      Math.abs(ua[2] - pa[2]) < EPS
    );
  }

  /** Długość wspólnej krawędzi w XY (stykanie bokami), 0 jeśli tylko róg / brak. */
  function edgeContact(a, b) {
    const xOverlap =
      Math.min(a.x + a.l, b.x + b.l) - Math.max(a.x, b.x);
    const yOverlap =
      Math.min(a.y + a.w, b.y + b.w) - Math.max(a.y, b.y);
    // Stykanie pionowe (wspólna krawędź równoległa do Y)
    if (Math.abs(a.x + a.l - b.x) < 0.05 || Math.abs(b.x + b.l - a.x) < 0.05) {
      return Math.max(0, yOverlap);
    }
    // Stykanie poziome (wspólna krawędź równoległa do X)
    if (Math.abs(a.y + a.w - b.y) < 0.05 || Math.abs(b.y + b.w - a.y) < 0.05) {
      return Math.max(0, xOverlap);
    }
    return 0;
  }

  function clusterMetrics(unit, foot, z, placed) {
    let sameContact = 0;
    let anyContact = 0;
    let sameCount = 0;
    let distSame = Infinity;
    const cx = foot.x + foot.l / 2;
    const cy = foot.y + foot.w / 2;
    const family = [];

    for (const p of placed) {
      if (Math.abs(p.z - z) > 0.05) continue;
      const contact = edgeContact(foot, p);
      if (contact > EPS) {
        anyContact += contact;
        if (sameFamily(unit, p)) sameContact += contact;
      }
      if (sameFamily(unit, p)) {
        sameCount += 1;
        family.push(p);
        const pcx = p.x + p.l / 2;
        const pcy = p.y + p.w / 2;
        distSame = Math.min(distSame, Math.hypot(cx - pcx, cy - pcy));
      }
    }
    if (!Number.isFinite(distSame)) distSame = 1e6;

    // AABB rodziny po dodaniu foot
    family.push(foot);
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    let filled = 0;
    for (const p of family) {
      minX = Math.min(minX, p.x);
      minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x + p.l);
      maxY = Math.max(maxY, p.y + p.w);
      filled += p.l * p.w;
    }
    const famW = Math.max(0, maxX - minX);
    const famD = Math.max(0, maxY - minY);
    const famAabb = famW * famD;
    const famWaste = Math.max(0, famAabb - filled);
    // Kara za „wydłużone L”: stosunek obwodu do powierzchni
    const famPerim = 2 * (famW + famD);

    return {
      sameContact,
      anyContact,
      sameCount,
      distSame,
      famAabb,
      famWaste,
      famPerim,
    };
  }

  function loadAabb(placed, foot) {
    let minX = Infinity;
    let minY = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    const all = foot ? placed.concat([foot]) : placed;
    if (!all.length) return 0;
    for (const p of all) {
      minX = Math.min(minX, p.x);
      minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x + p.l);
      maxY = Math.max(maxY, p.y + p.w);
    }
    return Math.max(0, maxX - minX) * Math.max(0, maxY - minY);
  }

  function isValidPose(foot, o, placed, L, W, tol, availableH) {
    if (!withinTolerance(foot, L, W, tol)) return null;
    const sup = restingSupport(foot, placed);
    let ratio = sup.ratio;
    if (sup.z < EPS) {
      ratio = 1;
    } else if (ratio + EPS < SUPPORT_MIN) {
      return null;
    }
    if (sup.z + o.h > availableH + EPS) return null;
    if (collides(foot, sup.z, o.h, placed)) return null;
    return { z: sup.z, ratio };
  }

  function scoreCandidate(unit, foot, o, placed, L, W, z, ratio) {
    const overhang =
      Math.max(0, -foot.x) +
      Math.max(0, -foot.y) +
      Math.max(0, foot.x + foot.l - L) +
      Math.max(0, foot.y + foot.w - W);
    const cluster = clusterMetrics(unit, foot, z, placed);
    // Uwaga: nie nazywać lokalnej zmiennej `loadAabb` — zasłania funkcję (TDZ).
    const loadAabbArea = loadAabb(placed, foot);
    const orphan =
      cluster.sameCount > 0 && cluster.sameContact < EPS ? 1 : 0;
    return {
      z,
      orphan,
      sameContact: cluster.sameContact,
      famWaste: cluster.famWaste,
      famAabb: cluster.famAabb,
      famPerim: cluster.famPerim,
      distSame: cluster.distSame,
      loadAabb: loadAabbArea,
      anyContact: cluster.anyContact,
      overhang,
      baseArea: o.l * o.w,
      h: o.h,
      ratio,
      corner: Math.max(0, foot.x) + Math.max(0, foot.y),
      x: foot.x,
      y: foot.y,
      l: o.l,
      w: o.w,
    };
  }

  /**
   * Porównanie kandydatów. strategy:
   * - balanced (domyślnie) — kompakt + większa stopa
   * - fewerLayers — preferuj niższe pudła (płaskie) → mniej warstw
   * - preferUpright — preferuj mniejszą stopę / wyższe pudła
   */
  function betterScore(a, b, strategy) {
    const strat = strategy || 'balanced';
    if (!b) return true;
    if (a.z < b.z - EPS) return true;
    if (Math.abs(a.z - b.z) > EPS) return false;
    // Twardo: sąsiad rodziny > odległa kieszeń
    if (a.orphan !== b.orphan) return a.orphan < b.orphan;

    if (strat === 'fewerLayers') {
      if (a.h < b.h - EPS) return true;
      if (a.h > b.h + EPS) return false;
      if (a.baseArea > b.baseArea + EPS) return true;
      if (a.baseArea < b.baseArea - EPS) return false;
    } else if (strat === 'preferUpright') {
      if (a.baseArea < b.baseArea - EPS) return true;
      if (a.baseArea > b.baseArea + EPS) return false;
      if (a.h > b.h + EPS) return true;
      if (a.h < b.h - EPS) return false;
    }

    // Kompaktowy klaster rodziny (mniej pustek w AABB)
    if (a.famWaste < b.famWaste - EPS) return true;
    if (a.famWaste > b.famWaste + EPS) return false;
    if (a.famAabb < b.famAabb - EPS) return true;
    if (a.famAabb > b.famAabb + EPS) return false;
    if (a.sameContact > b.sameContact + EPS) return true;
    if (a.sameContact < b.sameContact - EPS) return false;
    if (a.famPerim < b.famPerim - EPS) return true;
    if (a.famPerim > b.famPerim + EPS) return false;
    if (a.distSame < b.distSame - EPS) return true;
    if (a.distSame > b.distSame + EPS) return false;
    if (a.loadAabb < b.loadAabb - EPS) return true;
    if (a.loadAabb > b.loadAabb + EPS) return false;
    if (a.anyContact > b.anyContact + EPS) return true;
    if (a.anyContact < b.anyContact - EPS) return false;
    if (a.baseArea > b.baseArea + EPS) return true;
    if (a.baseArea < b.baseArea - EPS) return false;
    if (a.overhang < b.overhang - EPS) return true;
    if (a.overhang > b.overhang + EPS) return false;
    if (a.h < b.h - EPS) return true;
    if (a.h > b.h + EPS) return false;
    return a.corner < b.corner - EPS;
  }

  function findPlacement(unit, placed, L, W, tol, availableH, strategy) {
    let orients = allFaceOrients(unit.l, unit.w, unit.h);
    if (strategy === 'fewerLayers') {
      orients = orients.slice().sort((a, b) => a.h - b.h || b.l * b.w - a.l * a.w);
    } else if (strategy === 'preferUpright') {
      orients = orients.slice().sort((a, b) => a.l * a.w - b.l * b.w || b.h - a.h);
    }

    // Kotwice od krawędzi rodziny — najpierw rosnący blok
    const familyAnchors = [];
    for (const p of placed) {
      if (!sameFamily(unit, p)) continue;
      familyAnchors.push(
        { x: p.x + p.l, y: p.y },
        { x: p.x, y: p.y + p.w },
        { x: p.x - unit.l, y: p.y }, // przybliżenie; pełne orients poniżej
        { x: p.x, y: p.y - unit.w },
        { x: p.x + p.l, y: p.y + p.w },
        { x: p.x, y: p.y },
        { x: p.x + p.l, y: p.y },
        { x: p.x, y: p.y + p.w }
      );
    }
    const anchors = [...familyAnchors, ...candidateAnchors(placed, L, W, tol)];

    const adjacent = [];
    const fallback = [];

    for (const o of orients) {
      if (o.l > L + 2 * tol + EPS || o.w > W + 2 * tol + EPS) continue;
      for (const a of anchors) {
        const origins = [
          { x: a.x, y: a.y },
          { x: a.x - o.l, y: a.y },
          { x: a.x, y: a.y - o.w },
          { x: a.x - o.l, y: a.y - o.w },
        ];
        for (const origin of origins) {
          const foot = { x: origin.x, y: origin.y, l: o.l, w: o.w };
          const pose = isValidPose(foot, o, placed, L, W, tol, availableH);
          if (!pose) continue;
          const score = scoreCandidate(
            unit,
            foot,
            o,
            placed,
            L,
            W,
            pose.z,
            pose.ratio
          );
          if (score.sameContact > EPS) adjacent.push(score);
          else fallback.push(score);
        }
      }
    }

    // Jeśli istnieje JAKIKOLWIEK slot przy klastrze — użyj TYLKO tych (żadnych odległych kieszeni)
    const pool = adjacent.length ? adjacent : fallback;
    let best = null;
    for (const s of pool) {
      if (betterScore(s, best, strategy)) best = s;
    }
    return best;
  }

  const STRATEGY_META = {
    balanced: {
      id: 'balanced',
      tradeoffKey: 'variants.tradeoff.balanced',
    },
    fewerLayers: {
      id: 'fewerLayers',
      tradeoffKey: 'variants.tradeoff.fewerLayers',
    },
    preferUpright: {
      id: 'preferUpright',
      tradeoffKey: 'variants.tradeoff.preferUpright',
    },
  };

  /**
   * @param {Array} boxes — {count,l,w,h,weight,sku?,productId?}
   * @param {Object} pallet — {L,W,ph,maxH,maxWeight,tol?,palletLabel?,strategy?}
   */
  function calculatePalletization(boxes, pallet) {
    const { L, W, ph, maxH, maxWeight, palletLabel } = pallet;
    const strategy =
      pallet.strategy && STRATEGY_META[pallet.strategy]
        ? pallet.strategy
        : 'balanced';
    const tol = Math.max(0, Number(pallet.tol) || 0);
    if (
      !boxes.length ||
      boxes.some(
        (b) =>
          !b.l ||
          !b.w ||
          !b.h ||
          !Number.isFinite(b.l + b.w + b.h) ||
          b.l <= 0 ||
          b.w <= 0 ||
          b.h <= 0 ||
          !(b.count > 0)
      )
    ) {
      return { error: 'Uzupełnij poprawne wymiary i liczbę kartonów.' };
    }
    if (!(L > 0 && W > 0 && ph >= 0 && maxH > ph)) {
      return { error: 'Sprawdź wymiary palety i maksymalną wysokość.' };
    }
    if (!Number.isFinite(tol) || tol < 0) {
      return { error: 'Tolerancja musi być liczbą ≥ 0.' };
    }

    const availableH = maxH - ph;

    // Kolejka: największa stopa → cięższe → wyższe
    const queue = [];
    boxes.forEach((b, idx) => {
      for (let i = 0; i < b.count; i++) {
        queue.push({
          idx,
          l: b.l,
          w: b.w,
          h: b.h,
          weight: b.weight || 0,
          sku: b.sku || 'Własne',
          productId: b.productId || 'custom',
        });
      }
    });
    queue.sort(
      (a, b) =>
        maxBaseArea(b.l, b.w, b.h) - maxBaseArea(a.l, a.w, a.h) ||
        b.weight - a.weight ||
        Math.min(b.l, b.w, b.h) - Math.min(a.l, a.w, a.h) ||
        a.idx - b.idx
    );

    const placed = [];
    let loadedWeight = 0;

    /**
     * Spróbuj ułożyć całą grupę SKU jako prostokątny blok (siatka),
     * żeby uniknąć rozsiania / kształtu L z samotnymi końcówkami.
     */
    function tryPlaceFamilyBlock(group) {
      const n = group.length;
      if (n <= 1) return 0;
      const sample = group[0];
      let best = null;

      let faceOrients = allFaceOrients(sample.l, sample.w, sample.h);
      if (strategy === 'fewerLayers') {
        faceOrients = faceOrients
          .slice()
          .sort((a, b) => a.h - b.h || b.l * b.w - a.l * a.w);
      } else if (strategy === 'preferUpright') {
        faceOrients = faceOrients
          .slice()
          .sort((a, b) => a.l * a.w - b.l * b.w || b.h - a.h);
      }
      for (const o of faceOrients) {
        if (o.l > L + 2 * tol + EPS || o.w > W + 2 * tol + EPS) continue;
        for (let cols = 1; cols <= n; cols++) {
          const rows = Math.ceil(n / cols);
          if ((cols - 1) * rows >= n) continue; // zbędne układy
          const blockL = cols * o.l;
          const blockW = rows * o.w;
          if (blockL > L + 2 * tol + EPS || blockW > W + 2 * tol + EPS) continue;

          // Kotwice: róg palety + krawędzie już leżących
          const anchors = [{ x: 0, y: 0 }, ...candidateAnchors(placed, L, W, tol)];
          for (const a of anchors) {
            for (const origin of [
              { x: a.x, y: a.y },
              { x: a.x - blockL, y: a.y },
              { x: a.x, y: a.y - blockW },
              { x: a.x - blockL, y: a.y - blockW },
            ]) {
              const block = { x: origin.x, y: origin.y, l: blockL, w: blockW };
              if (!withinTolerance(block, L, W, tol)) continue;

              // Wspólna wysokość oparcia całego bloku = max restZ pod komórkami
              // Sprawdź każdą komórkę siatki
              const cells = [];
              let ok = true;
              let blockZ = 0;
              for (let r = 0; r < rows && ok; r++) {
                for (let c = 0; c < cols; c++) {
                  const i = r * cols + c;
                  if (i >= n) break;
                  const foot = {
                    x: block.x + c * o.l,
                    y: block.y + r * o.w,
                    l: o.l,
                    w: o.w,
                  };
                  const pose = isValidPose(
                    foot,
                    o,
                    placed,
                    L,
                    W,
                    tol,
                    availableH
                  );
                  if (!pose) {
                    ok = false;
                    break;
                  }
                  // Wszystkie komórki muszą mieć ten sam z (płaska półka)
                  if (cells.length && Math.abs(pose.z - blockZ) > 0.05) {
                    ok = false;
                    break;
                  }
                  blockZ = pose.z;
                  cells.push({ foot, z: pose.z });
                }
              }
              if (!ok || cells.length < n) continue;

              // Limit masy
              const addW = group
                .slice(0, cells.length)
                .reduce((s, u) => s + u.weight, 0);
              if (maxWeight >= 0 && loadedWeight + addW > maxWeight + EPS) {
                continue;
              }

              const score = {
                z: blockZ,
                aabb: blockL * blockW,
                corner: Math.max(0, block.x) + Math.max(0, block.y),
                overhang:
                  Math.max(0, -block.x) +
                  Math.max(0, -block.y) +
                  Math.max(0, block.x + blockL - L) +
                  Math.max(0, block.y + blockW - W),
                o,
                cells,
                n: cells.length,
              };
              if (
                !best ||
                score.z < best.z - EPS ||
                (Math.abs(score.z - best.z) < EPS && score.aabb < best.aabb - EPS) ||
                (Math.abs(score.z - best.z) < EPS &&
                  Math.abs(score.aabb - best.aabb) < EPS &&
                  score.overhang < best.overhang - EPS) ||
                (Math.abs(score.z - best.z) < EPS &&
                  Math.abs(score.aabb - best.aabb) < EPS &&
                  Math.abs(score.overhang - best.overhang) < EPS &&
                  score.corner < best.corner - EPS)
              ) {
                best = score;
              }
            }
          }
        }
      }

      if (!best) return 0;
      let placedN = 0;
      for (let i = 0; i < best.cells.length; i++) {
        const u = group[i];
        const cell = best.cells[i];
        if (maxWeight >= 0 && loadedWeight + u.weight > maxWeight + EPS) break;
        placed.push({
          idx: u.idx,
          x: cell.foot.x,
          y: cell.foot.y,
          z: cell.z,
          l: best.o.l,
          w: best.o.w,
          h: best.o.h,
          // Orientacja względem fabrycznych L×W×H SKU (dowolny bok na dole)
          baseL: u.l,
          baseW: u.w,
          baseH: u.h,
          weight: u.weight,
          sku: u.sku,
          productId: u.productId,
          colorIndex: u.idx,
        });
        loadedWeight += u.weight;
        placedN++;
      }
      return placedN;
    }

    // Grupuj kolejkę według SKU (idx) — zachowaj kolejność typów
    const groups = [];
    for (const unit of queue) {
      const last = groups[groups.length - 1];
      if (last && last[0].idx === unit.idx) last.push(unit);
      else groups.push([unit]);
    }

    for (const group of groups) {
      let done = tryPlaceFamilyBlock(group);
      // Reszta / gdy blok się nie udał — sztuka po sztuce z twardym clusteringiem
      for (let i = done; i < group.length; i++) {
        const unit = group[i];
        if (maxWeight >= 0 && loadedWeight + unit.weight > maxWeight + EPS) {
          continue;
        }
        const pos = findPlacement(unit, placed, L, W, tol, availableH, strategy);
        if (!pos) continue;
        placed.push({
          idx: unit.idx,
          x: pos.x,
          y: pos.y,
          z: pos.z,
          l: pos.l,
          w: pos.w,
          h: pos.h,
          baseL: unit.l,
          baseW: unit.w,
          baseH: unit.h,
          weight: unit.weight,
          sku: unit.sku,
          productId: unit.productId,
          colorIndex: unit.idx,
        });
        loadedWeight += unit.weight;
      }
    }

    const allPlacements = placed.map((p) => ({ ...p }));

    const layerMap = new Map();
    for (const p of allPlacements) {
      const key = Math.round(p.z * 10) / 10;
      if (!layerMap.has(key)) {
        layerMap.set(key, { z: key, count: 0, height: 0, weight: 0 });
      }
      const layer = layerMap.get(key);
      layer.count += 1;
      layer.height = Math.max(layer.height, p.h);
      layer.weight += p.weight;
    }
    const layerSummaries = [...layerMap.values()]
      .sort((a, b) => a.z - b.z)
      .map((layer, i) => ({
        number: i + 1,
        count: layer.count,
        height: layer.height,
        weight: layer.weight,
      }));

    const stackHeight = allPlacements.reduce((m, p) => Math.max(m, p.z + p.h), 0);
    const totalRequested = boxes.reduce((s, b) => s + b.count, 0);
    const totalWeight = boxes.reduce((s, b) => s + b.count * b.weight, 0);
    const loaded = allPlacements.length;

    // packL/packW = faktyczny AABB ładunku (informacyjnie); nie jest to „rozszerzona paleta”
    let minX = 0;
    let minY = 0;
    let maxX = L;
    let maxY = W;
    for (const p of allPlacements) {
      minX = Math.min(minX, p.x);
      minY = Math.min(minY, p.y);
      maxX = Math.max(maxX, p.x + p.l);
      maxY = Math.max(maxY, p.y + p.w);
    }

    return {
      date: new Date().toLocaleString('pl-PL'),
      pallet: palletLabel || `${L} × ${W} cm`,
      L,
      W,
      ph,
      maxH,
      maxWeight,
      tol,
      strategy,
      packL: maxX - minX,
      packW: maxY - minY,
      totalBoxes: totalRequested,
      loadedBoxes: loaded,
      remainingBoxes: Math.max(0, totalRequested - loaded),
      layers: layerSummaries.length,
      height: ph + stackHeight,
      loadHeight: stackHeight,
      weight: loadedWeight,
      requestedWeight: totalWeight,
      full: loaded >= totalRequested,
      boxes: boxes.map((b) => ({ ...b })),
      layerSummaries,
      placements: allPlacements,
    };
  }

  function resultFingerprint(r) {
    if (!r || r.error) return '';
    return [
      r.loadedBoxes,
      r.remainingBoxes,
      r.layers,
      Number(r.height).toFixed(2),
      Number(r.weight).toFixed(2),
      Number(r.loadHeight).toFixed(2),
    ].join('|');
  }

  /**
   * 2–3 warianty strategii układania (reuse silnika).
   * Deduplikuje wyniki o tym samym fingerprintcie, zachowując kolejność.
   */
  function calculateVariants(boxes, pallet) {
    const ids = ['balanced', 'fewerLayers', 'preferUpright'];
    const out = [];
    const seen = new Set();
    for (const id of ids) {
      const result = calculatePalletization(boxes, { ...pallet, strategy: id });
      if (result.error) {
        if (!out.length) return [{ ...STRATEGY_META[id], result }];
        continue;
      }
      const fp = resultFingerprint(result);
      if (seen.has(fp) && out.length) continue;
      seen.add(fp);
      out.push({ ...STRATEGY_META[id], result });
    }
    // Jeśli wszystkie identyczne — i tak pokaż 1–2 z etykietami strategii
    if (out.length === 1 && !out[0].result.error) {
      const only = out[0];
      for (const id of ids) {
        if (id === only.id) continue;
        const result = calculatePalletization(boxes, { ...pallet, strategy: id });
        if (result.error) continue;
        out.push({ ...STRATEGY_META[id], result, sameAs: only.id });
        if (out.length >= 2) break;
      }
    }
    return out.slice(0, 3);
  }

  global.PaletyzatorPacking = {
    packLayer,
    calculatePalletization,
    calculateVariants,
    STRATEGY_META,
    allFaceOrients,
    maxBaseArea,
  };
})(typeof window !== 'undefined' ? window : globalThis);
