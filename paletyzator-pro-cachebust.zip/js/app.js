/**
 * Paletyzator Pro — logika UI, dane lokalne, integracja z packing + 3D.
 */
(function () {
  'use strict';

  const $ = (id) => document.getElementById(id);

  const t = (key, vars) =>
    (window.I18n && typeof window.I18n.t === 'function'
      ? window.I18n.t(key, vars)
      : key);

  function billing() {
    return window.PaletyzatorBilling || null;
  }

  function requireFeature(name) {
    const B = billing();
    if (!B || B.hasFeature(name)) return true;
    alert(t('billing.locked'));
    showView('billing');
    return false;
  }

  function refreshBillingUi() {
    const B = billing();
    if (!B) return;
    const sub = B.getSubscription();
    const tier = B.getTier();
    if ($('billing-status-line')) {
      $('billing-status-line').textContent = B.statusLabel(sub);
    }
    if ($('plan-badge-name')) {
      $('plan-badge-name').textContent = t('billing.tier.' + tier.id);
    }
    const cancelWrap = $('billing-cancel-wrap');
    if (cancelWrap) {
      const can = typeof B.canCancelSubscription === 'function' && B.canCancelSubscription();
      cancelWrap.classList.toggle('hidden', !can);
    }
    const portalBtn = $('btn-stripe-portal');
    if (portalBtn) {
      const showPortal =
        typeof B.canOpenPortal === 'function' && B.canOpenPortal();
      portalBtn.classList.toggle('hidden', !showPortal);
    }
    renderBillingTiers();
    renderAdminCodes();
    applyFeatureGates();
  }

  function mailApi() {
    return window.PaletyzatorMail || null;
  }

  /** Best-effort transactional mail (Edge Function). Never blocks UX. */
  async function notifyMail(type, meta) {
    const Mail = mailApi();
    if (!Mail || demoMode) return { ok: false, skipped: true };
    try {
      return await Mail.sendTransactional(type, meta || {});
    } catch (e) {
      console.warn('[mail]', type, e);
      return { ok: false, error: e.message || String(e) };
    }
  }

  function renderBillingTiers() {
    const B = billing();
    const el = $('billing-tiers');
    if (!B || !el) return;
    const sub = B.getSubscription();
    const current = sub.tier;
    const entitled =
      !!(sub && sub.verified) &&
      (sub.source === 'stripe' ||
        sub.source === 'trial' ||
        sub.source === 'promo' ||
        sub.source === 'admin_grant');
    const hasBusiness =
      typeof B.isBusinessEntitled === 'function'
        ? B.isBusinessEntitled()
        : entitled && current === 'business';
    const order = ['starter', 'pro', 'business'];
    const featKeys = [
      ['mixCalc', 'billing.feat.mix'],
      ['liveAlerts', 'billing.feat.alerts'],
      ['viewer3d', 'billing.feat.3d'],
      ['packingVariants', 'billing.feat.variants'],
      ['courierChecks', 'billing.feat.courier'],
      ['offerPdf', 'billing.feat.pdf'],
      ['skuImport', 'billing.feat.import'],
      ['cmr', 'billing.feat.cmr'],
      ['vies', 'billing.feat.vies'],
      ['exportData', 'billing.feat.export'],
    ];
    el.innerHTML = order
      .map((id) => {
        const tier = B.TIERS[id];
        const f = tier.features;
        const lis = featKeys
          .map(
            ([k, label]) =>
              `<li class="${f[k] ? '' : 'off'}">${t(label)}</li>`
          )
          .join('');
        const priceLabel =
          (B.formatPriceLabel && B.formatPriceLabel(id)) || '';
        const hasPrice = !!(B.priceIdForTier && B.priceIdForTier(id));
        const isCurrent = id === current && entitled;
        let action = '';
        if (isCurrent || (hasBusiness && id === 'business')) {
          action = `<div class="tier-action"><span class="tier-current-label">${t('billing.currentPlan')}</span></div>`;
        } else if (hasBusiness) {
          // Już Business — bez Kup na niższych planach
          action = '';
        } else if (hasPrice) {
          action = `<div class="tier-action"><button type="button" class="primary tier-buy" data-buy-tier="${id}">${t('billing.buy')}</button></div>`;
        }
        return `<article class="billing-tier ${id === current ? 'is-current' : ''} ${id === 'business' ? 'is-top' : ''}">
          <h3>${t('billing.tier.' + id)}</h3>
          ${priceLabel ? `<p class="tier-price">${esc(priceLabel)}</p>` : ''}
          <p class="tier-desc">${t('billing.tier.' + id + '.desc')}</p>
          <ul>${lis}</ul>
          <div class="hint">SKU: ${tier.maxSkuRows}${id === current ? ' · ✓' : ''}</div>
          ${action}
        </article>`;
      })
      .join('');
    el.querySelectorAll('[data-buy-tier]').forEach((btn) => {
      btn.addEventListener('click', () => startCheckoutFlow(btn.dataset.buyTier));
    });
  }

  async function startCheckoutFlow(tierId) {
    const B = billing();
    if (!B || typeof B.startCheckout !== 'function') return;
    if (demoMode) {
      alert(t('billing.err.loginRequired'));
      return;
    }
    const Auth = window.PaletyzatorAuth;
    if (!Auth || !Auth.isConfigured || !Auth.isConfigured()) {
      alert(t('billing.err.loginRequired'));
      return;
    }
    try {
      const { data } = await Auth.getClient().auth.getSession();
      if (!data?.session) {
        alert(t('billing.err.loginRequired'));
        return;
      }
    } catch (_) {
      alert(t('billing.err.loginRequired'));
      return;
    }
    const btn = document.querySelector(`[data-buy-tier="${tierId}"]`);
    if (btn) {
      btn.disabled = true;
      btn.textContent = t('billing.buyWait');
    }
    try {
      const res = await B.startCheckout(tierId);
      if (!res.ok || !res.url) {
        alert(res.error || t('billing.err.checkout'));
        return;
      }
      location.href = res.url;
    } catch (e) {
      alert(e.message || t('billing.err.checkout'));
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = t('billing.buy');
      }
    }
  }

  async function openPortalFlow() {
    const B = billing();
    if (!B || typeof B.openCustomerPortal !== 'function') return;
    const res = await B.openCustomerPortal();
    if (!res.ok || !res.url) {
      alert(res.error || t('billing.err.portal'));
      return;
    }
    location.href = res.url;
  }

  async function handleCheckoutReturn() {
    let params;
    try {
      params = new URLSearchParams(location.search || '');
    } catch (_) {
      return;
    }
    const checkout = params.get('checkout');
    if (!checkout) return;
    const B = billing();
    if (!B) return;

    if (checkout === 'success') {
      showView('billing');
      const line = $('billing-status-line');
      if (line) line.textContent = t('billing.buyWait');
      // Nie ufaj ?plan= — czekaj na wiersz z webhooka w Supabase
      let res = { ok: false };
      try {
        if (typeof B.confirmCheckoutFromServer === 'function') {
          res = await B.confirmCheckoutFromServer({ attempts: 10, delayMs: 800 });
        } else if (typeof B.syncRemoteSubscription === 'function') {
          res = await B.syncRemoteSubscription();
        }
      } catch (_) {
        /* ignore */
      }
      refreshBillingUi();
      if (line) {
        line.textContent = res.ok && res.subscription && res.subscription.verified
          ? B.statusLabel() + ' — ' + t('billing.checkoutSuccess')
          : t('billing.checkoutPending');
      }
    } else if (checkout === 'cancel') {
      showView('billing');
    }

    try {
      const u = new URL(location.href);
      u.searchParams.delete('checkout');
      u.searchParams.delete('plan');
      u.searchParams.delete('portal');
      history.replaceState({}, '', u.pathname + u.search + u.hash);
    } catch (_) {
      /* ignore */
    }
  }

  function isClientBuild() {
    const c = window.PALETYZATOR_CONFIG || {};
    if (c.clientBuild === true || c.clientBuild === 'true' || c.clientBuild === 1) {
      return true;
    }
    const B = billing();
    return !!(B && B.isClientBuild && B.isClientBuild());
  }

  /** Paczka klienta: usuń panel właściciela z DOM — nie da się włączyć z UI. */
  function stripAdminUiForClient() {
    if (!isClientBuild()) return;
    document.querySelectorAll('[data-admin-only]').forEach((el) => el.remove());
    const card = $('billing-admin-card');
    if (card) card.remove();
    // Układ redeem na pełną szerokość
    const redeem = $('redeem-form')?.closest('.card');
    const grid = redeem?.parentElement;
    if (grid && grid.classList.contains('grid2')) {
      grid.classList.remove('grid2');
    }
  }

  /** Pełna app: admin tylko dla ownerEmails (nie demo). */
  function syncAdminActor() {
    const B = billing();
    if (!B || typeof B.setAdminActor !== 'function') return;
    B.setAdminActor(demoMode ? '' : activeUserEmail || '');
  }

  function isOwnerSession() {
    if (isClientBuild() || demoMode) return false;
    const B = billing();
    if (!B) return false;
    if (typeof B.isOwnerEmail === 'function') {
      return B.isOwnerEmail(activeUserEmail);
    }
    return !!(B.isAdminUnlocked && B.isAdminUnlocked());
  }

  function updateAdminCardVisibility() {
    const card = $('billing-admin-card');
    if (!card) return;
    const show = isOwnerSession();
    card.classList.toggle('hidden', !show);
    const redeem = $('redeem-form')?.closest('.card');
    const grid = redeem?.parentElement;
    if (grid) {
      if (show) grid.classList.add('grid2');
      else grid.classList.remove('grid2');
    }
  }

  function renderAdminCodes() {
    if (isClientBuild()) return;
    const B = billing();
    if (!B) return;
    syncAdminActor();
    updateAdminCardVisibility();
    const unlocked = isOwnerSession();
    $('admin-lock-panel')?.classList.add('hidden');
    $('admin-codes-panel')?.classList.toggle('hidden', !unlocked);
    if (!unlocked) return;
    const body = $('admin-codes-body');
    if (!body) return;
    const rows = B.listCodes();
    body.innerHTML = rows.length
      ? rows
          .map(
            (c) => `<tr>
          <td><strong style="letter-spacing:0.06em">${esc(c.code)}</strong></td>
          <td><span class="billing-status-${c.status}">${t('billing.status.' + c.status)}</span></td>
          <td>${esc(B.formatDate(c.createdAt))}</td>
          <td>${esc(B.formatDate(c.usedAt))}</td>
          <td>${esc(B.formatDate(c.trialEndsAt))}</td>
          <td><button type="button" class="quiet smallbtn" data-copy="${esc(c.code)}">${t('billing.copy')}</button></td>
        </tr>`
          )
          .join('')
      : `<tr><td colspan="6" class="empty">—</td></tr>`;
    body.querySelectorAll('[data-copy]').forEach((btn) => {
      btn.addEventListener('click', async () => {
        try {
          await navigator.clipboard.writeText(btn.dataset.copy);
          btn.textContent = t('billing.copied');
          setTimeout(() => (btn.textContent = t('billing.copy')), 1200);
        } catch (_) {
          prompt('Code', btn.dataset.copy);
        }
      });
    });
  }

  function applyFeatureGates() {
    const B = billing();
    if (!B) return;
    const has3d = B.hasFeature('viewer3d');
    const hasCmr = B.hasFeature('cmr');
    const hasVies = B.hasFeature('vies');
    const hasSingle = B.hasFeature('singleCalc');
    const hasExport = B.hasFeature('exportData');
    const hasOfferPdf = B.hasFeature('offerPdf');
    const hasSkuImport = B.hasFeature('skuImport');
    const hasCourier = B.hasFeature('courierChecks');
    const hasVariants = B.hasFeature('packingVariants');
    const hasTol = B.hasFeature('tolerance');

    document.querySelectorAll('.calc-3d-card').forEach((el) => {
      el.classList.toggle('feature-locked', !has3d);
    });
    let note = document.getElementById('lock-note-3d');
    if (!has3d) {
      if (!note) {
        note = document.createElement('p');
        note.id = 'lock-note-3d';
        note.className = 'feature-lock-note';
        document.querySelector('.calc-3d-card')?.appendChild(note);
      }
      note.textContent = t('billing.locked');
      note.classList.remove('hidden');
    } else if (note) note.classList.add('hidden');

    if ($('btn-cmr')) {
      if (!hasCmr) {
        $('btn-cmr').disabled = true;
        $('btn-cmr').title = t('billing.lockedTitle');
      } else {
        $('btn-cmr').title = '';
      }
    }
    document.querySelectorAll('[data-view="single"]').forEach((b) => {
      b.classList.toggle('feature-locked', !hasSingle);
      b.style.opacity = hasSingle ? '' : '0.55';
    });
    document.querySelectorAll('[data-view="vies"]').forEach((b) => {
      b.classList.toggle('feature-locked', !hasVies);
      b.style.opacity = hasVies ? '' : '0.55';
      b.title = hasVies ? '' : t('billing.lockedTitle');
    });
    if ($('btn-export-products')) $('btn-export-products').disabled = !hasExport;
    if ($('btn-export-history')) $('btn-export-history').disabled = !hasExport;
    if ($('btn-import-csv')) {
      $('btn-import-csv').disabled = !hasSkuImport;
      $('btn-import-csv').title = hasSkuImport ? '' : t('billing.lockedTitle');
    }
    if ($('import-csv-file')) $('import-csv-file').disabled = !hasSkuImport;
    if ($('btn-offer-pdf')) {
      $('btn-offer-pdf').disabled = !hasOfferPdf || !lastResult;
      if (!hasOfferPdf) $('btn-offer-pdf').title = t('billing.lockedTitle');
      else $('btn-offer-pdf').title = '';
    }
    if ($('calc-dest-country')) {
      $('calc-dest-country').disabled = !hasCourier;
      $('calc-dest-country').title = hasCourier ? '' : t('billing.lockedTitle');
    }
    const variantsCard = $('calc-variants-card');
    if (variantsCard && !hasVariants) {
      variantsCard.hidden = true;
    }
    if ($('pallet-tol')) {
      $('pallet-tol').disabled = !hasTol;
      if (!hasTol) $('pallet-tol').value = 0;
    }
    if ($('vies-submit')) {
      $('vies-submit').disabled = !hasVies;
      $('vies-submit').title = hasVies ? '' : t('billing.lockedTitle');
    }
    if ($('vies-pdf-btn') && !hasVies) {
      $('vies-pdf-btn').disabled = true;
      $('vies-pdf-btn').title = t('billing.lockedTitle');
    }
  }


  /** Odcienie kraftu — zgodne z wizualizacją 3D (kartony tekturowe). */
  const BOX_COLORS = [
    '#c4a574', '#b8956a', '#d2b48c', '#a89068', '#c9ab7a', '#bba06e', '#d0b896',
    '#ad9a6c',
  ];

  let activeUserId = null;
  let activeUserEmail = '';
  let authMode = 'login';
  let demoMode = false;
  let pendingVerifyEmail = '';
  let authBusy = false;
  let products = [];
  let historyData = [];
  let lastResult = null;
  let lastVariants = [];
  let pendingCsvImport = null;
  let liveAlertTimer = null;
  let lastViesResult = null;
  let pendingAvatarDataUrl = null;
  let pendingBannerDataUrl = null;
  let accountCreatedAt = null;
  let boxRowCounter = 0;
  let viewer = null;
  const DEMO_PASS_DEFAULT = 'demo1234';

  function storageKey(key) {
    return 'pp_' + (activeUserId || 'guest') + '_' + key;
  }

  function load(key, fallback) {
    try {
      const v = JSON.parse(localStorage.getItem(storageKey(key)));
      return v ?? fallback;
    } catch (e) {
      return fallback;
    }
  }

  function persist() {
    localStorage.setItem(storageKey('products'), JSON.stringify(products));
    localStorage.setItem(storageKey('history'), JSON.stringify(historyData));
    refreshDashboard();
  }

  function esc(s) {
    return String(s ?? '').replace(
      /[&<>"']/g,
      (c) =>
        ({
          '&': '&amp;',
          '<': '&lt;',
          '>': '&gt;',
          '"': '&quot;',
          "'": '&#39;',
        })[c]
    );
  }

  async function ensureViewer() {
    if (viewer) return viewer;
    const el = $('viewer-3d');
    if (!el || !window.PalletViewer3D) return null;
    viewer = new window.PalletViewer3D(el);
    await viewer.init();
    return viewer;
  }

  function showView(name) {
    const B = billing();
    if (name === 'single' && B && !B.hasFeature('singleCalc')) {
      alert(t('billing.locked'));
      name = 'billing';
    }
    if (name === 'vies' && B && !B.hasFeature('vies')) {
      alert(t('billing.locked'));
      name = 'billing';
    }
    document.querySelectorAll('.view').forEach((v) => v.classList.remove('active'));
    const section = $('view-' + name);
    if (section) section.classList.add('active');
    document.querySelectorAll('.tabs .tab').forEach((b) =>
      b.classList.toggle('active', b.dataset.view === name)
    );
    if (name === 'products') renderProducts();
    if (name === 'history') renderHistory();
    if (name === 'dashboard') refreshDashboard();
    if (name === 'single') refreshSingleSkuOptions();
    if (name === 'billing') refreshBillingUi();
    if (name === 'user') refreshUserSettingsUi();
    if (name === 'calculator') {
      if (!$('box-rows').children.length) seedSkuRows();
      renumberSkuRows();
      ensureViewer().then((v) => {
        if (!v) return;
        if (lastResult && lastResult.placements) v.renderResult(lastResult);
        else v.renderEmpty();
      });
    }
  }

  document.querySelectorAll('.tabs .tab').forEach((b) =>
    b.addEventListener('click', () => showView(b.dataset.view))
  );

  function refreshDashboard() {
    $('stat-products').textContent = products.length;
    $('stat-history').textContent = historyData.length;
    const r = historyData.slice(0, 4);
    $('recent-list').innerHTML = r.length
      ? '<div class="tablewrap"><table style="min-width:0"><thead><tr><th>Data</th><th>Kartony</th><th>Paleta</th></tr></thead><tbody>' +
        r
          .map(
            (x) =>
              `<tr><td>${esc(x.date)}</td><td>${x.totalBoxes}</td><td>${esc(x.pallet)}</td></tr>`
          )
          .join('') +
        '</tbody></table></div>'
      : `<div class="empty">${t('dash.recentEmpty')}</div>`;
  }

  const MAX_SKU_ROWS_CAP = 40;
  function maxSkuRowsAllowed() {
    const B = billing();
    return B ? Math.min(MAX_SKU_ROWS_CAP, B.maxSkuRows()) : MAX_SKU_ROWS_CAP;
  }
  const DEFAULT_SKU_ROWS = 10;
  function defaultSkuRows() {
    return Math.min(DEFAULT_SKU_ROWS, maxSkuRowsAllowed());
  }

  function renumberSkuRows() {
    document.querySelectorAll('#box-rows .box-row').forEach((row, i) => {
      const num = row.querySelector('.sku-num');
      if (num) num.textContent = String(i + 1);
    });
  }

  function seedSkuRows() {
    $('box-rows').innerHTML = '';
    const seeds = products.slice(0, 3);
    const defaults = [
      seeds[0] ? { productId: seeds[0].id, count: 12 } : { count: '' },
      seeds[1] ? { productId: seeds[1].id, count: 8 } : { count: '' },
      seeds[2] ? { productId: seeds[2].id, count: 4 } : { count: '' },
    ];
    for (let i = 0; i < defaultSkuRows(); i++) {
      addBoxRow(defaults[i] || { count: '' });
    }
    renumberSkuRows();
  }

  function addBoxRow(data = {}) {
    if (document.querySelectorAll('.box-row').length >= maxSkuRowsAllowed()) {
      alert(t('alert.maxSku', { n: maxSkuRowsAllowed() }));
      return;
    }
    const id = ++boxRowCounter;
    const countVal =
      data.count === '' || data.count == null ? '' : data.count;
    const row = document.createElement('div');
    row.className = 'box-row';
    row.dataset.row = id;
    row.innerHTML = `
      <span class="sku-num" aria-hidden="true"></span>
      <div class="field sku-product"><label class="sr-only">Produkt / SKU</label><select class="box-product"></select></div>
      <div class="field sku-count"><label class="sr-only">${t('row.qty')}</label><input class="box-count" type="number" min="0" step="1" value="${countVal}" placeholder="0"></div>
      <div class="sku-dims">
        <input class="box-l" type="number" min=".1" step=".1" value="${data.l ?? ''}" placeholder="D" title="${t('row.len')}" aria-label="${t('row.len')}">
        <span>×</span>
        <input class="box-w" type="number" min=".1" step=".1" value="${data.w ?? ''}" placeholder="S" title="${t('row.wid')}" aria-label="${t('row.wid')}">
        <span>×</span>
        <input class="box-h" type="number" min=".1" step=".1" value="${data.h ?? ''}" placeholder="W" title="${t('row.hei')}" aria-label="${t('row.hei')}">
      </div>
      <div class="field sku-weight"><label class="sr-only">${t('row.weight')}</label><input class="box-weight" type="number" min="0" step=".01" value="${data.weight ?? ''}" placeholder="kg"></div>
      <button class="danger iconbtn no-print" type="button" title="${t('row.remove')}" aria-label="${t('row.remove')}">×</button>`;
    $('box-rows').appendChild(row);

    const sel = row.querySelector('.box-product');
    sel.innerHTML =
      '<option value="custom">' + t('row.custom') + '</option>' +
      products
        .map(
          (p) =>
            `<option value="${esc(p.id)}">${esc(p.sku)} — ${esc(p.name)}</option>`
        )
        .join('');
    if (data.productId && products.some((p) => p.id === data.productId)) {
      sel.value = data.productId;
    }
    if (sel.value !== 'custom') {
      fillBoxRow(row, products.find((p) => p.id === sel.value));
      if (countVal !== '') row.querySelector('.box-count').value = countVal;
    }

    sel.addEventListener('change', () => {
      if (sel.value === 'custom') return;
      fillBoxRow(row, products.find((p) => p.id === sel.value));
    });
    row.querySelector('.iconbtn').addEventListener('click', () => removeBoxRow(id));
    renumberSkuRows();
  }

  function fillBoxRow(row, p) {
    if (!p) return;
    row.querySelector('.box-l').value = p.l;
    row.querySelector('.box-w').value = p.w;
    row.querySelector('.box-h').value = p.h;
    row.querySelector('.box-weight').value = p.weight || 0;
  }

  function removeBoxRow(id) {
    const el = document.querySelector(`.box-row[data-row="${id}"]`);
    if (el) el.remove();
    renumberSkuRows();
  }

  function palletChanged() {
    const v = $('pallet-type').value;
    const dims = {
      '120x80': [120, 80],
      '60x80': [80, 60],
      '120x120': [120, 120],
    };
    if (dims[v]) {
      $('pallet-length').value = dims[v][0];
      $('pallet-width').value = dims[v][1];
    }
    // Domyślna maks. wysokość zależna od typu palety
    const maxHByType = {
      '60x80': 150,
      '120x80': 180,
    };
    if (maxHByType[v] != null) {
      $('max-height').value = maxHByType[v];
    }
  }

  function getBoxes() {
    return [...document.querySelectorAll('.box-row')]
      .map((row) => ({
        productId: row.querySelector('.box-product').value,
        sku:
          row.querySelector('.box-product').selectedOptions[0]?.textContent ||
          'Własne wymiary',
        count: Math.floor(Number(row.querySelector('.box-count').value)),
        l: Number(row.querySelector('.box-l').value),
        w: Number(row.querySelector('.box-w').value),
        h: Number(row.querySelector('.box-h').value),
        weight: Number(row.querySelector('.box-weight').value) || 0,
      }))
      .filter((b) => b.count > 0 && b.l > 0 && b.w > 0 && b.h > 0);
  }

  function renderLegend(boxes) {
    const el = $('viewer-legend');
    if (!el) return;
    const seen = new Map();
    boxes.forEach((b, i) => {
      const key = b.productId || b.sku || i;
      if (!seen.has(key)) seen.set(key, { label: b.sku, color: BOX_COLORS[i % BOX_COLORS.length] });
    });
    el.innerHTML = [...seen.values()]
      .map(
        (x) =>
          `<span class="legend-item"><span class="legend-swatch" style="background:${x.color}"></span>${esc(x.label)}</span>`
      )
      .join('');
  }

  function failReasonLabel(code) {
    const map = {
      height: t('courier.failHeight'),
      weight: t('courier.failWeight'),
      base: t('courier.failBase'),
      country: t('courier.failCountry'),
    };
    return map[code] || code;
  }

  function renderCourierSection(r, countryCode) {
    if (billing() && !billing().hasFeature('courierChecks')) {
      return `<div class="courier-panel feature-locked">
        <div class="courier-panel-head">
          <h4 data-i18n-keep="1">${t('courier.title')}</h4>
          <p class="hint feature-lock-note">${t('billing.locked')}</p>
        </div>
      </div>`;
    }
    const CR = window.PaletyzatorCourierRules;
    if (!CR) {
      return `<div class="courier-panel"><p class="hint">${t('courier.unavailable')}</p></div>`;
    }
    const locale = (window.I18n && window.I18n.getLocale && window.I18n.getLocale()) || 'pl';
    const countries = CR.getCountries(locale);
    const code = String(countryCode || CR.getSavedCountry() || 'PL').toUpperCase();
    const evalResult = CR.evaluate(code, {
      heightCm: Number(r.height),
      weightKg: Number(r.weight),
      L: Number(r.L),
      W: Number(r.W),
    });
    const options = countries
      .map(
        (c) =>
          `<option value="${esc(c.code)}"${c.code === code ? ' selected' : ''}>${esc(c.name)} (${esc(c.code)})</option>`
      )
      .join('');

    const countryFailHtml = (evalResult.fails || [])
      .map((f) => `<li>${esc(failReasonLabel(f))}</li>`)
      .join('');

    const badgeClass = evalResult.ok ? 'courier-badge ok' : 'courier-badge fail';
    const badgeText = evalResult.ok
      ? t('courier.countryPass')
      : t('courier.countryFail');

    const limits = evalResult.limits || {};
    const countryMeta = evalResult.country
      ? CR.countryLabel(evalResult.country, locale)
      : code;

    const rows = (evalResult.couriers || [])
      .map((c) => {
        const status = c.ok
          ? `<span class="courier-status ok">${t('courier.eligible')}</span>`
          : `<span class="courier-status fail">${t('courier.ineligible')}</span>`;
        const reasons = (c.fails || [])
          .map((f) => esc(failReasonLabel(f)))
          .join(', ');
        const bands = (c.pricingBands || [])
          .map(
            (b) =>
              `<li>${esc(b.label)}: <strong>${t('courier.priceFrom', { n: b.priceFromPln })}</strong></li>`
          )
          .join('');
        const matchBand = c.priceBand
          ? `<div class="courier-match-price">${t('courier.yourBand')}: <strong>${esc(c.priceBand.label)} — ${t('courier.priceFrom', { n: c.priceBand.priceFromPln })}</strong></div>`
          : '';
        const baseLim =
          c.maxLCm != null && c.maxWCm != null
            ? ` · ${c.maxLCm}×${c.maxWCm} cm`
            : '';
        return `<article class="courier-card${c.ok ? '' : ' is-fail'}${c.serves ? '' : ' is-noserve'}">
          <header class="courier-card-head">
            <h4>${esc(c.name)}</h4>
            ${status}
          </header>
          <div class="courier-criteria">${t('courier.criteria')}: <strong>≤ ${c.maxWeightKg} kg</strong> · <strong>≤ ${c.maxHeightCm} cm</strong>${baseLim}</div>
          ${matchBand}
          <ul class="courier-bands">${bands}</ul>
          ${
            reasons
              ? `<p class="courier-why">${t('courier.why')}: ${reasons}</p>`
              : ''
          }
          ${c.notePl ? `<p class="courier-note">${esc(c.notePl)}</p>` : ''}
        </article>`;
      })
      .join('');

    return `<div class="courier-panel" id="courier-panel">
      <div class="courier-panel-head">
        <h4 data-i18n-keep="1">${t('courier.title')}</h4>
        <p class="hint">${t('courier.lead')}</p>
      </div>
      <div class="courier-select-row">
        <label for="dest-country-filter">${t('courier.country')}</label>
        <input type="search" id="dest-country-filter" class="courier-filter" placeholder="${esc(t('courier.search'))}" autocomplete="off">
        <select id="dest-country" aria-label="${esc(t('courier.country'))}">${options}</select>
      </div>
      <div class="courier-verdict ${evalResult.ok ? 'is-ok' : 'is-fail'}">
        <span class="${badgeClass}">${badgeText}</span>
        <div class="courier-verdict-body">
          <p>${t('courier.forCountry', { country: countryMeta, code })}</p>
          <p class="courier-dims">${t('courier.palletDims', {
            h: Number(r.height).toFixed(1),
            w: Number(r.weight).toFixed(2),
            L: r.L,
            W: r.W,
          })}</p>
          <p class="courier-limits">${t('courier.countryLimits', {
            h: limits.maxHeightCm,
            w: limits.maxWeightKg,
          })}</p>
          <p class="courier-count">${t('courier.eligibleCount', {
            n: evalResult.eligibleCount,
            total: evalResult.servingCount,
          })}</p>
          ${
            countryFailHtml
              ? `<ul class="courier-fail-list">${countryFailHtml}</ul>`
              : ''
          }
        </div>
      </div>
      <div class="courier-list">${rows}</div>
      <p class="courier-assumptions hint">${esc(evalResult.assumptions || CR.ASSUMPTIONS)}</p>
    </div>`;
  }

  function getDestCountryCode() {
    const CR = window.PaletyzatorCourierRules;
    const fromCalc = $('calc-dest-country')?.value;
    if (fromCalc) return String(fromCalc).toUpperCase();
    const fromResult = $('dest-country')?.value;
    if (fromResult) return String(fromResult).toUpperCase();
    return (CR && CR.getSavedCountry && CR.getSavedCountry()) || 'PL';
  }

  function populateCalcDestCountry() {
    const CR = window.PaletyzatorCourierRules;
    const sel = $('calc-dest-country');
    if (!CR || !sel) return;
    const locale =
      (window.I18n && window.I18n.getLocale && window.I18n.getLocale()) || 'pl';
    const current = getDestCountryCode();
    const list = CR.getCountries(locale);
    sel.innerHTML = list
      .map(
        (c) =>
          `<option value="${esc(c.code)}"${c.code === current ? ' selected' : ''}>${esc(c.name)} (${esc(c.code)})</option>`
      )
      .join('');
    if (![...sel.options].some((o) => o.value === current) && list[0]) {
      sel.value = list[0].code;
    } else {
      sel.value = current;
    }
  }

  function syncDestCountry(code) {
    const CR = window.PaletyzatorCourierRules;
    const cc = String(code || 'PL').toUpperCase();
    if (CR && CR.saveCountry) CR.saveCountry(cc);
    if ($('calc-dest-country') && $('calc-dest-country').value !== cc) {
      $('calc-dest-country').value = cc;
    }
    if ($('dest-country') && $('dest-country').value !== cc) {
      $('dest-country').value = cc;
    }
    scheduleLiveLimitAlerts();
  }

  function bindCourierPanel(r) {
    const CR = window.PaletyzatorCourierRules;
    if (!CR) return;
    const select = $('dest-country');
    const filter = $('dest-country-filter');
    if (!select) return;

    const refill = (q) => {
      const locale = (window.I18n && window.I18n.getLocale && window.I18n.getLocale()) || 'pl';
      const needle = String(q || '').trim().toLowerCase();
      const current = select.value;
      const list = CR.getCountries(locale).filter(
        (c) =>
          !needle ||
          c.search.includes(needle) ||
          c.code.toLowerCase().includes(needle) ||
          c.name.toLowerCase().includes(needle)
      );
      select.innerHTML = list
        .map(
          (c) =>
            `<option value="${esc(c.code)}"${c.code === current ? ' selected' : ''}>${esc(c.name)} (${esc(c.code)})</option>`
        )
        .join('');
      if (!list.some((c) => c.code === current) && list[0]) {
        select.value = list[0].code;
      }
    };

    filter?.addEventListener('input', () => refill(filter.value));
    select.addEventListener('change', () => {
      syncDestCountry(select.value);
      // Re-render only courier block to keep scroll; simplest: full result refresh
      const html = $('result-content');
      if (!html) return;
      const box = html.querySelector('.resultbox');
      if (!box) {
        renderResultHTML(r);
        return;
      }
      const panel = $('courier-panel');
      const next = renderCourierSection(r, select.value);
      if (panel) {
        panel.outerHTML = next;
        bindCourierPanel(r);
      } else {
        renderResultHTML(r);
      }
    });
  }

  function getPalletParams() {
    return {
      L: Number($('pallet-length').value),
      W: Number($('pallet-width').value),
      ph: Number($('pallet-height').value),
      maxH: Number($('max-height').value),
      maxWeight: Number($('max-weight').value),
      tol: Number($('pallet-tol')?.value) || 0,
      palletLabel: $('pallet-type').selectedOptions[0]?.textContent || '',
    };
  }

  function scheduleLiveLimitAlerts() {
    if (liveAlertTimer) clearTimeout(liveAlertTimer);
    liveAlertTimer = setTimeout(updateLiveLimitAlerts, 280);
  }

  function updateLiveLimitAlerts() {
    const host = $('live-limit-alerts');
    if (!host) return;
    const B = billing();
    if (B && !B.hasFeature('liveAlerts')) {
      host.hidden = true;
      host.innerHTML = '';
      return;
    }
    const hasCourierAlerts = !B || B.hasFeature('courierChecks');
    const boxes = getBoxes();
    const pallet = getPalletParams();
    const warnings = [];
    const projectedWeight = boxes.reduce(
      (s, b) => s + (Number(b.count) || 0) * (Number(b.weight) || 0),
      0
    );
    const totalQty = boxes.reduce((s, b) => s + (Number(b.count) || 0), 0);

    if (totalQty <= 0) {
      host.hidden = true;
      host.innerHTML = '';
      return;
    }

    if (
      Number.isFinite(pallet.maxWeight) &&
      pallet.maxWeight >= 0 &&
      projectedWeight > pallet.maxWeight + 1e-6
    ) {
      warnings.push(
        t('live.overMaxWeight', {
          w: projectedWeight.toFixed(2),
          max: pallet.maxWeight,
        })
      );
    }

    // Szacunek wysokości: wynik bieżący lub szybki pack (debounced)
    let heightCm = lastResult ? Number(lastResult.height) : null;
    let weightForCourier = projectedWeight;
    if (
      window.PaletyzatorPacking &&
      boxes.length &&
      pallet.L > 0 &&
      pallet.W > 0 &&
      pallet.maxH > pallet.ph
    ) {
      try {
        const quick = window.PaletyzatorPacking.calculatePalletization(
          boxes,
          pallet
        );
        if (quick && !quick.error) {
          heightCm = Number(quick.height);
          weightForCourier = Number(quick.weight);
          if (
            Number.isFinite(pallet.maxH) &&
            heightCm > pallet.maxH + 1e-6
          ) {
            warnings.push(
              t('live.overMaxHeight', {
                h: heightCm.toFixed(1),
                max: pallet.maxH,
              })
            );
          }
          if (!quick.full) {
            warnings.push(
              t('live.partialFit', {
                loaded: quick.loadedBoxes,
                total: quick.totalBoxes,
              })
            );
          }
        }
      } catch (_) {
        /* ignore projection errors */
      }
    }

    // Full courier alerts — Pro/Business; Starter stays on light height/weight/partial.
    const CR = window.PaletyzatorCourierRules;
    const country = getDestCountryCode();
    if (hasCourierAlerts && CR && country && heightCm != null) {
      const ev = CR.evaluate(country, {
        heightCm,
        weightKg: weightForCourier,
        L: pallet.L,
        W: pallet.W,
      });
      if (ev && !ev.ok) {
        const fails = (ev.fails || [])
          .map((c) => failReasonLabel(c))
          .join(', ');
        warnings.push(
          t('live.courierFail', {
            country:
              (ev.country && CR.countryLabel(ev.country)) || country,
            n: ev.eligibleCount || 0,
            fails: fails || '—',
          })
        );
      } else if (ev && ev.eligibleCount === 0) {
        warnings.push(t('live.noCourier', { country }));
      } else if (ev) {
        const tight = (ev.couriers || []).filter(
          (c) =>
            c.serves &&
            c.ok &&
            (weightForCourier > c.maxWeightKg * 0.9 ||
              heightCm > c.maxHeightCm * 0.9)
        );
        if (tight.length) {
          warnings.push(
            t('live.nearLimit', {
              names: tight
                .slice(0, 3)
                .map((c) => c.name)
                .join(', '),
            })
          );
        }
      }
    }

    if (!warnings.length) {
      host.hidden = true;
      host.innerHTML = '';
      return;
    }
    host.hidden = false;
    host.innerHTML =
      `<div class="live-alerts-title">${esc(t('live.title'))}</div>` +
      `<ul>${warnings.map((w) => `<li>${esc(w)}</li>`).join('')}</ul>`;
  }

  function renderVariants(variants, activeId) {
    const card = $('calc-variants-card');
    const host = $('variants-compare');
    if (!card || !host) return;
    lastVariants = variants || [];
    const canCompare =
      !billing() || billing().hasFeature('packingVariants');
    if (!lastVariants.length || !canCompare) {
      card.hidden = true;
      host.innerHTML = '';
      return;
    }
    card.hidden = false;
    const active = activeId || lastResult?.strategy || lastVariants[0].id;
    host.innerHTML = lastVariants
      .map((v) => {
        const r = v.result;
        const isActive = v.id === active;
        const sameNote = v.sameAs
          ? `<p class="variants-same">${esc(t('variants.sameAs', { id: t('variants.name.' + v.sameAs) }))}</p>`
          : '';
        return `<article class="variant-card${isActive ? ' is-active' : ''}" data-variant="${esc(v.id)}">
          <header>
            <h4>${esc(t('variants.name.' + v.id))}</h4>
            ${isActive ? `<span class="variant-badge">${esc(t('variants.active'))}</span>` : ''}
          </header>
          <p class="variant-tradeoff">${esc(t(v.tradeoffKey || 'variants.tradeoff.' + v.id))}</p>
          ${sameNote}
          <ul class="variant-stats">
            <li><span>${esc(t('calc.loaded'))}</span><strong>${esc(r.loadedBoxes)}/${esc(r.totalBoxes)}</strong></li>
            <li><span>${esc(t('calc.layers'))}</span><strong>${esc(r.layers)}</strong></li>
            <li><span>${esc(t('calc.totalH'))}</span><strong>${esc(Number(r.height).toFixed(1))} cm</strong></li>
            <li><span>${esc(t('calc.loadedW'))}</span><strong>${esc(Number(r.weight).toFixed(2))} kg</strong></li>
          </ul>
          <button type="button" class="secondary smallbtn variant-pick" data-pick="${esc(v.id)}" ${isActive ? 'disabled' : ''}>
            ${esc(isActive ? t('variants.active') : t('variants.pick'))}
          </button>
        </article>`;
      })
      .join('');

    host.querySelectorAll('[data-pick]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-pick');
        const chosen = lastVariants.find((x) => x.id === id);
        if (!chosen || chosen.result.error) return;
        applyActiveResult(chosen.result, { keepVariants: true });
      });
    });
  }

  async function applyActiveResult(result, opts = {}) {
    lastResult = result;
    renderResultHTML(result);
    renderLegend(result.boxes || getBoxes());
    setCmrEnabled(true);
    if (!opts.keepVariants && lastVariants.length) {
      renderVariants(lastVariants, result.strategy);
    } else if (opts.keepVariants) {
      renderVariants(lastVariants, result.strategy);
    }
    const hint = $('viewer-hint-text');
    if (hint) {
      hint.textContent = t('viz.hintN', { n: result.placements?.length || 0 });
    }
    if (billing()?.hasFeature('viewer3d')) {
      const v = await ensureViewer();
      if (v) v.renderResult(result);
    }
    applyFeatureGates();
    scheduleLiveLimitAlerts();
  }

  function renderResultHTML(r) {
    const full = r.full;
    $('result-status').textContent = full
      ? t('calc.resultOk')
      : t('calc.resultPartial');

    const layerHtml =
      (r.layerSummaries || [])
        .map((x) =>
          t('calc.layerLine', { n: x.number, count: x.count, h: x.height })
        )
        .join('<br>') || t('calc.noLayer');

    const dest =
      (window.PaletyzatorCourierRules &&
        window.PaletyzatorCourierRules.getSavedCountry()) ||
      'PL';

    $('result-content').innerHTML = `<div class="resultbox">
      <div class="resultmain">
        <div class="resultitem"><small>${t('calc.loaded')}</small><strong>${r.loadedBoxes} <em>/ ${r.totalBoxes}</em></strong></div>
        <div class="resultitem"><small>${t('calc.layers')}</small><strong>${r.layers}</strong></div>
        <div class="resultitem"><small>${t('calc.totalH')}</small><strong>${Number(r.height).toFixed(1)} <em>cm</em></strong></div>
        <div class="resultitem"><small>${t('calc.loadedW')}</small><strong>${Number(r.weight).toFixed(2)} <em>kg</em></strong></div>
        <div class="resultitem"><small>${t('calc.base')}</small><strong>${r.L} × ${r.W} <em>cm</em></strong></div>
        <div class="resultitem"><small>${t('calc.remaining')}</small><strong>${r.remainingBoxes}</strong></div>
      </div>
      <div class="kpi-line" style="margin-top:12px"><span>${t('calc.loadH')}</span><strong>${Number(r.loadHeight).toFixed(1)} cm</strong></div>
      <div class="kpi-line"><span>${t('calc.ph')}</span><strong>${Number(r.ph).toFixed(1)} cm</strong></div>
      <div class="kpi-line"><span>${t('calc.tolLine')}</span><strong>${Number(r.tol || 0).toFixed(1)} cm</strong></div>
      ${
        Number(r.tol) > 0
          ? `<div class="kpi-line"><span>${t('calc.packOutline')}</span><strong>${Number(r.packL).toFixed(1)} × ${Number(r.packW).toFixed(1)} cm</strong></div>`
          : ''
      }
      <div class="kpi-line"><span>${t('calc.reqWeight')}</span><strong>${Number(r.requestedWeight).toFixed(2)} kg</strong></div>
      <div class="resultnote">${layerHtml}</div>
      ${
        !full
          ? `<div class="alert">${t('calc.alertPartial')}</div>`
          : ''
      }
      <div class="alert" style="background:#f6f8fc;border-color:#e1e6ef;color:#5e6b80">${t('calc.disclaimer')}</div>
      ${renderCourierSection(r, dest)}
    </div>`;
    bindCourierPanel(r);
  }

  async function calculate() {
    try {
      const boxes = getBoxes();
      if (!boxes.length) {
        alert(t('alert.needBoxes'));
        return;
      }
      if (!window.PaletyzatorPacking) {
        alert(t('alert.noPacking'));
        return;
      }
      const pallet = getPalletParams();
      const Pack = window.PaletyzatorPacking;

      const canVariants =
        !billing() || billing().hasFeature('packingVariants');
      let variants = [];
      if (canVariants && typeof Pack.calculateVariants === 'function') {
        variants = Pack.calculateVariants(boxes, pallet);
      } else {
        const result = Pack.calculatePalletization(boxes, pallet);
        variants = [
          {
            id: 'balanced',
            tradeoffKey: 'variants.tradeoff.balanced',
            result,
          },
        ];
      }

      const firstOk = variants.find((v) => v.result && !v.result.error);
      if (!firstOk) {
        alert(variants[0]?.result?.error || t('alert.noPacking'));
        return;
      }

      lastVariants = canVariants ? variants : [firstOk];
      renderVariants(lastVariants, firstOk.id);
      await applyActiveResult(firstOk.result, { keepVariants: true });
      bumpProfileStat('calcRuns', 1, {
        lastCalcAt: new Date().toISOString(),
        lastPallet: firstOk.result.L + '×' + firstOk.result.W,
      });
    } catch (err) {
      console.error('[calculate]', err);
      alert(
        t('alert.calcErr', {
          msg: err && err.message ? err.message : String(err),
        })
      );
    }
  }

  function saveCurrent() {
    if (!lastResult) {
      calculate();
      if (!lastResult) return;
    }
    historyData.unshift({ ...lastResult, id: Date.now() });
    historyData = historyData.slice(0, 300);
    persist();
    renderHistory();
    alert(t('alert.savedHist'));
  }

  function printReport() {
    if (!lastResult) {
      calculate();
      if (!lastResult) return;
    }
    window.print();
  }

  async function downloadOfferPdf() {
    if (!requireFeature('offerPdf')) return;
    if (!lastResult) {
      alert(t('alert.needCalc'));
      return;
    }
    if (!window.PaletyzatorOfferPdf) {
      alert(t('alert.noOffer'));
      return;
    }
    const countryCode = getDestCountryCode();
    await window.PaletyzatorOfferPdf.openOfferPdf(lastResult, { countryCode });
  }

  function resetCalc() {
    seedSkuRows();
    $('result-content').innerHTML = `<div class="empty">${t('calc.resultEmpty')}</div>`;
    $('result-status').textContent = t('calc.resultIdle');
    lastResult = null;
    lastVariants = [];
    renderVariants([]);
    $('viewer-legend').innerHTML = '';
    setCmrEnabled(false);
    applyFeatureGates();
    scheduleLiveLimitAlerts();
    ensureViewer().then((v) => v && v.renderEmpty());
  }

  function saveProduct(e) {
    e.preventDefault();
    const id = $('edit-id').value || 'sku-' + Date.now();
    const item = {
      id,
      sku: $('sku').value.trim(),
      name: $('product-name').value.trim(),
      l: Number($('prod-length').value),
      w: Number($('prod-width').value),
      h: Number($('prod-height').value),
      weight: Number($('prod-weight').value) || 0,
    };
    if (
      products.some(
        (p) => p.sku.toLowerCase() === item.sku.toLowerCase() && p.id !== id
      )
    ) {
      alert(t('alert.skuExists'));
      return;
    }
    if ($('edit-id').value) products = products.map((p) => (p.id === id ? item : p));
    else products.push(item);
    persist();
    clearProductForm();
    renderProducts();
    refreshBoxOptions();
    alert(t('alert.productSaved'));
  }

  function clearProductForm() {
    $('product-form').reset();
    $('edit-id').value = '';
    $('prod-weight').value = 0;
    $('product-form-title').textContent = t('products.add');
  }

  function editProduct(id) {
    const p = products.find((x) => x.id === id);
    if (!p) return;
    $('edit-id').value = p.id;
    $('sku').value = p.sku;
    $('product-name').value = p.name;
    $('prod-length').value = p.l;
    $('prod-width').value = p.w;
    $('prod-height').value = p.h;
    $('prod-weight').value = p.weight;
    $('product-form-title').textContent = t('products.edit');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function deleteProduct(id) {
    if (!confirm('Usunąć ten produkt z bazy SKU?')) return;
    products = products.filter((p) => p.id !== id);
    persist();
    renderProducts();
    refreshBoxOptions();
  }

  function renderProducts() {
    const q = ($('product-search')?.value || '').toLowerCase();
    const list = products.filter((p) =>
      (p.sku + ' ' + p.name).toLowerCase().includes(q)
    );
    $('products-table').innerHTML = list
      .map(
        (p) =>
          `<tr>
            <td><strong>${esc(p.sku)}</strong></td>
            <td>${esc(p.name)}</td>
            <td>${p.l} × ${p.w} × ${p.h} cm</td>
            <td>${Number(p.weight || 0).toFixed(2)} kg</td>
            <td>
              <button class="quiet smallbtn" type="button" data-edit="${esc(p.id)}">${t('products.editBtn')}</button>
              <button class="danger smallbtn" type="button" data-del="${esc(p.id)}">${t('products.delBtn')}</button>
            </td>
          </tr>`
      )
      .join('');
    $('products-empty').style.display = list.length ? 'none' : 'block';
    $('product-count').textContent = t('products.count', { n: products.length });

    $('products-table').querySelectorAll('[data-edit]').forEach((btn) =>
      btn.addEventListener('click', () => editProduct(btn.dataset.edit))
    );
    $('products-table').querySelectorAll('[data-del]').forEach((btn) =>
      btn.addEventListener('click', () => deleteProduct(btn.dataset.del))
    );
  }

  function refreshBoxOptions() {
    document.querySelectorAll('.box-row').forEach((row) => {
      const old = row.querySelector('.box-product').value;
      const sel = row.querySelector('.box-product');
      sel.innerHTML =
        '<option value="custom">' + t('row.custom') + '</option>' +
        products
          .map(
            (p) =>
              `<option value="${esc(p.id)}">${esc(p.sku)} — ${esc(p.name)}</option>`
          )
          .join('');
      sel.value = products.some((p) => p.id === old) ? old : 'custom';
    });
    refreshSingleSkuOptions();
  }

  function refreshSingleSkuOptions() {
    const sel = $('single-sku');
    if (!sel) return;
    const prev = sel.value;
    sel.innerHTML = products
      .map((p) => `<option value="${esc(p.id)}">${esc(p.sku)} — ${esc(p.name)}</option>`)
      .join('');
    if (products.some((p) => p.id === prev)) sel.value = prev;
  }

  function computeOrientations(cartonL, cartonW, cartonH, palletL, palletW, maxH, ph) {
    const usableH = Math.max(0, maxH - ph);
    const maps = [
      ['L×W×H', cartonL, cartonW, cartonH],
      ['L×H×W', cartonL, cartonH, cartonW],
      ['W×L×H', cartonW, cartonL, cartonH],
      ['W×H×L', cartonW, cartonH, cartonL],
      ['H×L×W', cartonH, cartonL, cartonW],
      ['H×W×L', cartonH, cartonW, cartonL],
    ];
    return maps.map(([label, baseL, baseW, cH]) => {
      const perLayer =
        baseL > 0 && baseW > 0
          ? Math.floor(palletL / baseL) * Math.floor(palletW / baseW)
          : 0;
      const layers = cH > 0 ? Math.max(0, Math.floor(usableH / cH)) : 0;
      return { label, baseL, baseW, cartonH: cH, perLayer, layers, capacity: perLayer * layers };
    });
  }

  function runSingleCalc() {
    const sku = products.find((p) => p.id === $('single-sku').value);
    if (!sku) {
      alert(t('alert.pickSku'));
      return null;
    }
    const qty = Math.floor(Number($('single-qty').value)) || 0;
    let pl = Number($('single-pl').value);
    let pw = Number($('single-pw').value);
    const type = $('single-pallet').value;
    const dims = { '120x80': [120, 80], '60x80': [60, 80], '120x120': [120, 120] };
    if (dims[type]) {
      pl = dims[type][0];
      pw = dims[type][1];
      $('single-pl').value = pl;
      $('single-pw').value = pw;
    }
    const ph = Number($('single-ph').value);
    const mh = Number($('single-mh').value);
    const mw = Number($('single-mw').value);
    const orients = computeOrientations(sku.l, sku.w, sku.h, pl, pw, mh, ph);
    const best = orients.reduce((a, b) => (b.capacity > a.capacity ? b : a), orients[0]);
    const weightCap = sku.weight > 0 ? Math.floor(mw / sku.weight) : Infinity;
    const realCap = Math.min(best.capacity, weightCap);
    const fits = qty <= realCap;

    $('single-orient-body').innerHTML = orients
      .map((o) => {
        const bestCls = o.label === best.label ? ' orient-best' : '';
        return `<tr class="${bestCls}">
          <td>${esc(o.label)}</td>
          <td class="num">${o.baseL}</td>
          <td class="num">${o.baseW}</td>
          <td class="num">${o.cartonH}</td>
          <td class="num">${o.perLayer}</td>
          <td class="num">${o.layers}</td>
          <td class="num">${o.capacity}</td>
        </tr>`;
      })
      .join('');

    $('single-summary').innerHTML = `
      <div class="resultbox">
        <div class="resultmain">
          <div class="resultitem"><small>SKU</small><strong>${esc(sku.sku)}</strong></div>
          <div class="resultitem"><small>Pojemność realna</small><strong>${realCap}</strong></div>
          <div class="resultitem"><small>Pojemność geo (best)</small><strong>${best.capacity}</strong></div>
          <div class="resultitem"><small>Limit wagowy</small><strong>${Number.isFinite(weightCap) ? weightCap : '—'}</strong></div>
        </div>
        <div class="kpi-line" style="margin-top:10px"><span>Żądana ilość</span><strong>${qty}</strong></div>
        <div class="kpi-line"><span>Ocena</span><strong>${fits ? '<span class="pill-ok">MIEŚCI SIĘ</span>' : '<span class="pill-bad">NIE MIEŚCI SIĘ</span>'}</strong></div>
        <div class="resultnote">Najlepsza orientacja: ${esc(best.label)} · ${best.perLayer}/warstwę × ${best.layers} warstw</div>
      </div>`;
    return { sku, qty, pl, pw, ph, mh, mw, best, realCap };
  }

  function singleToMix() {
    const r = runSingleCalc();
    if (!r) return;
    showView('calculator');
    $('box-rows').innerHTML = '';
    addBoxRow({
      productId: r.sku.id,
      count: r.qty,
      l: r.sku.l,
      w: r.sku.w,
      h: r.sku.h,
      weight: r.sku.weight,
    });
    for (let i = 1; i < DEFAULT_SKU_ROWS; i++) addBoxRow({ count: '' });
    renumberSkuRows();
    $('pallet-length').value = r.pl;
    $('pallet-width').value = r.pw;
    $('pallet-height').value = r.ph;
    $('max-height').value = r.mh;
    $('max-weight').value = r.mw;
    const typeMap = { '120,80': '120x80', '60,80': '60x80', '120,120': '120x120' };
    $('pallet-type').value = typeMap[`${r.pl},${r.pw}`] || 'custom';
    calculate();
  }

  function renderHistory() {
    $('history-table').innerHTML = historyData
      .map(
        (h) =>
          `<tr>
            <td>${esc(h.date)}</td>
            <td>${esc(h.pallet)}</td>
            <td>${h.loadedBoxes} / ${h.totalBoxes}</td>
            <td>${Number(h.height).toFixed(1)} cm</td>
            <td>${Number(h.weight).toFixed(2)} kg</td>
            <td>
              <button class="quiet smallbtn" type="button" data-load="${h.id}">${t('history.load')}</button>
              <button class="danger smallbtn" type="button" data-hdel="${h.id}">${t('history.delete')}</button>
            </td>
          </tr>`
      )
      .join('');
    $('history-empty').style.display = historyData.length ? 'none' : 'block';

    $('history-table').querySelectorAll('[data-load]').forEach((btn) =>
      btn.addEventListener('click', () => loadHistory(btn.dataset.load))
    );
    $('history-table').querySelectorAll('[data-hdel]').forEach((btn) =>
      btn.addEventListener('click', () => deleteHistory(btn.dataset.hdel))
    );
  }

  async function loadHistory(id) {
    const h = historyData.find((x) => String(x.id) === String(id));
    if (!h) return;
    lastResult = h;
    showView('calculator');
    renderResultHTML(h);
    renderLegend(h.boxes || []);
    setCmrEnabled(true);
    const v = await ensureViewer();
    if (v && h.placements) v.renderResult(h);
    else if (v) {
      // Starsze zapisy bez pozycji — przelicz ponownie
      const rebuilt = window.PaletyzatorPacking.calculatePalletization(h.boxes || [], {
        L: h.L,
        W: h.W,
        ph: h.ph,
        maxH: h.maxH,
        maxWeight: h.maxWeight,
        tol: h.tol || 0,
        palletLabel: h.pallet,
      });
      if (!rebuilt.error) {
        lastResult = { ...h, placements: rebuilt.placements };
        v.renderResult(lastResult);
      }
    }
  }

  function deleteHistory(id) {
    historyData = historyData.filter((h) => String(h.id) !== String(id));
    persist();
    renderHistory();
  }

  function clearHistory() {
    if (!confirm('Wyczyścić całą historię obliczeń?')) return;
    historyData = [];
    persist();
    renderHistory();
  }

  function download(name, data, type) {
    const blob = new Blob([data], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
  }

  function exportProducts() {
    if (!requireFeature('exportData')) return;
    download(
      'paletyzator_produkty.json',
      JSON.stringify(products, null, 2),
      'application/json'
    );
  }

  function importProducts(e) {
    const f = e.target.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (
          !Array.isArray(data) ||
          data.some((p) => !p.sku || !p.name || !(p.l > 0 && p.w > 0 && p.h > 0))
        )
          throw new Error();
        products = data.map((p) => ({
          ...p,
          id: p.id || 'sku-' + Date.now() + Math.random(),
        }));
        persist();
        renderProducts();
        refreshBoxOptions();
        alert(t('alert.imported'));
      } catch (err) {
        alert(
          'Nie udało się zaimportować pliku. Sprawdź, czy to poprawny eksport JSON.'
        );
      }
      e.target.value = '';
    };
    reader.readAsText(f);
  }

  async function importCsvProducts(e) {
    const f = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!f) return;
    if (!requireFeature('skuImport')) return;
    if (!window.PaletyzatorSkuImport) {
      alert(t('alert.noSkuImport'));
      return;
    }
    try {
      const parsed = await window.PaletyzatorSkuImport.parseFile(f);
      if (!parsed.products.length) {
        const msg =
          parsed.errors && parsed.errors.length
            ? t('alert.csvParseFail')
            : t('alert.csvEmpty');
        alert(msg);
        return;
      }
      pendingCsvImport = parsed;
      const preview = $('sku-import-preview');
      const meta = $('sku-import-meta');
      const errEl = $('sku-import-errors');
      if (meta) {
        const mapped = Object.keys(parsed.mapping || {})
          .map((k) => k + '←' + (parsed.headers[parsed.mapping[k]] || '?'))
          .join(', ');
        meta.textContent = t('products.csvMeta', {
          n: parsed.products.length,
          file: f.name,
          map: mapped,
        });
      }
      if (preview) {
        preview.innerHTML = parsed.products
          .slice(0, 80)
          .map(
            (p) => `<tr>
              <td>${esc(p.sku)}</td>
              <td>${esc(p.name)}</td>
              <td>${esc(p.l)}</td><td>${esc(p.w)}</td><td>${esc(p.h)}</td>
              <td>${esc(p.weight)}</td>
              <td>${p.qty == null ? '—' : esc(p.qty)}</td>
            </tr>`
          )
          .join('');
      }
      if (errEl) {
        const rowErrs = (parsed.errors || []).filter((x) => x && x.row);
        if (rowErrs.length) {
          errEl.hidden = false;
          errEl.textContent = t('products.csvRowErrors', {
            n: rowErrs.length,
            sample: rowErrs
              .slice(0, 5)
              .map((e) => e.row + ':' + (e.fields || []).join('/'))
              .join(', '),
          });
        } else {
          errEl.hidden = true;
          errEl.textContent = '';
        }
      }
      const dlg = $('sku-import-dialog');
      if (dlg && typeof dlg.showModal === 'function') dlg.showModal();
      else if (confirm(t('products.csvConfirmFallback', { n: parsed.products.length }))) {
        commitCsvImport('merge');
      }
    } catch (err) {
      console.error('[csv-import]', err);
      alert(t('alert.csvParseFail'));
    }
  }

  function commitCsvImport(mode) {
    if (!requireFeature('skuImport')) return;
    if (!pendingCsvImport || !pendingCsvImport.products.length) return;
    const incoming = pendingCsvImport.products.map((p) => ({
      id: 'sku-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8),
      sku: p.sku,
      name: p.name,
      l: p.l,
      w: p.w,
      h: p.h,
      weight: p.weight || 0,
    }));
    if (mode === 'replace') {
      products = incoming;
    } else {
      const bySku = new Map(
        products.map((p) => [String(p.sku).toLowerCase(), p])
      );
      for (const item of incoming) {
        const key = item.sku.toLowerCase();
        if (bySku.has(key)) {
          const old = bySku.get(key);
          const merged = { ...old, ...item, id: old.id };
          bySku.set(key, merged);
        } else {
          bySku.set(key, item);
        }
      }
      products = [...bySku.values()];
    }
    pendingCsvImport = null;
    persist();
    renderProducts();
    refreshBoxOptions();
    alert(t('alert.imported'));
  }

  function exportHistory() {
    if (!requireFeature('exportData')) return;
    const rows = [
      [
        'Data',
        'Paleta',
        'Długość palety cm',
        'Szerokość palety cm',
        'Kartony ułożone',
        'Kartony łącznie',
        'Warstwy',
        'Wysokość cm',
        'Masa kg',
      ],
      ...historyData.map((h) => [
        h.date,
        h.pallet,
        h.L,
        h.W,
        h.loadedBoxes,
        h.totalBoxes,
        h.layers,
        h.height,
        h.weight,
      ]),
    ];
    const csv = rows
      .map((r) =>
        r.map((v) => '"' + String(v ?? '').replace(/"/g, '""') + '"').join(';')
      )
      .join('\r\n');
    download('historia_paletyzacji.csv', '\ufeff' + csv, 'text/csv;charset=utf-8');
  }

  function getCmrPartiesFromForm() {
    const defaults =
      (window.PaletyzatorCMR && window.PaletyzatorCMR.defaultParties()) || {};
    const saved = load('settings', null)?.cmr || {};
    return {
      sender: $('cmr-sender')?.value?.trim() || saved.sender || defaults.sender || '',
      consignee: saved.consignee || defaults.consignee || '',
      deliveryPlace: saved.deliveryPlace || defaults.deliveryPlace || '',
      takeOverPlace: saved.takeOverPlace || defaults.takeOverPlace || '',
      carrier: saved.carrier || defaults.carrier || '',
      senderInstructions:
        saved.senderInstructions || defaults.senderInstructions || '',
    };
  }

  function applyCmrPartiesToForm(p) {
    if (!$('cmr-sender')) return;
    if (p && p.sender != null) $('cmr-sender').value = p.sender;
  }

  function collectSettings() {
    const prev = load('settings', null) || {};
    const prevCmr = prev.cmr || {};
    return {
      ph: Number($('setting-pallet-height').value),
      mh: Number($('setting-max-height').value),
      mw: Number($('setting-max-weight').value),
      cmr: {
        ...prevCmr,
        sender: $('cmr-sender')?.value?.trim() || '',
      },
    };
  }

  function saveSettings() {
    localStorage.setItem(storageKey('settings'), JSON.stringify(collectSettings()));
    $('pallet-height').value = $('setting-pallet-height').value;
    $('max-height').value = $('setting-max-height').value;
    $('max-weight').value = $('setting-max-weight').value;
    alert(t('alert.settingsSaved'));
  }

  function setCmrEnabled(on) {
    const btn = $('btn-cmr');
    if (!btn) return;
    btn.disabled = !on;
    btn.title = on
      ? 'Wygeneruj list przewozowy CMR'
      : 'Najpierw oblicz paletyzację';
  }

  async function openCmrDocument() {
    if (!requireFeature('cmr')) return;
    if (!lastResult) {
      alert(t('alert.needCalc'));
      return;
    }
    if (!window.PaletyzatorCMR) {
      alert(t('alert.noCmr'));
      return;
    }
    const btn = $('btn-cmr');
    if (btn) {
      btn.disabled = true;
      btn.textContent = t('viz.cmrBusy');
    }
    try {
      await window.PaletyzatorCMR.openCmr(lastResult, getCmrPartiesFromForm());
      bumpProfileStat('cmrOpens', 1);
    } catch (e) {
      alert(e.message || 'Nie udało się otworzyć CMR.');
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = t('viz.cmr');
        setCmrEnabled(!!lastResult);
      }
    }
  }

  function resetAll() {
    if (
      !confirm(
        'To usunie produkty, historię i ustawienia z tej przeglądarki. Kontynuować?'
      )
    )
      return;
    localStorage.removeItem(storageKey('products'));
    localStorage.removeItem(storageKey('history'));
    localStorage.removeItem(storageKey('settings'));
    products = [];
    historyData = [];
    refreshDashboard();
    renderProducts();
    renderHistory();
    resetCalc();
    alert(t('alert.dataCleared'));
  }

  function init() {
    if (!products.length) {
      products = [
        {
          id: 'demo-seed',
          sku: '60.018',
          name: 'zawias m18',
          l: 36,
          w: 25.5,
          h: 18,
          weight: 15,
        },
        {
          id: 'demo-1',
          sku: 'KARTON001',
          name: 'Karton 40×30×20',
          l: 40,
          w: 30,
          h: 20,
          weight: 2.5,
        },
        {
          id: 'demo-2',
          sku: 'KARTON002',
          name: 'Karton 60×40×30',
          l: 60,
          w: 40,
          h: 30,
          weight: 4.2,
        },
      ];
      persist();
    }
    const s = load('settings', null);
    if (s) {
      if (s.ph != null) {
        $('setting-pallet-height').value = s.ph;
        $('pallet-height').value = s.ph;
      }
      if (s.mh != null) {
        $('setting-max-height').value = s.mh;
        $('max-height').value = s.mh;
      }
      if (s.mw != null) {
        $('setting-max-weight').value = s.mw;
        $('max-weight').value = s.mw;
      }
      if (s.cmr) applyCmrPartiesToForm(s.cmr);
    } else if (window.PaletyzatorCMR) {
      applyCmrPartiesToForm(window.PaletyzatorCMR.defaultParties());
    }
    setCmrEnabled(false);
    seedSkuRows();
    populateCalcDestCountry();
    renderProducts();
    renderHistory();
    refreshDashboard();
    refreshSingleSkuOptions();
    scheduleLiveLimitAlerts();
    showView('calculator');
  }

  function authApi() {
    return window.PaletyzatorAuth || null;
  }

  function supabaseReady() {
    const a = authApi();
    return !!(a && a.isConfigured() && a.getClient());
  }

  function showPanelMessage(elId, message, type = 'error') {
    const el = $(elId);
    if (!el) return;
    el.textContent = message || '';
    el.className = message
      ? type === 'success'
        ? 'auth-success'
        : 'auth-error'
      : 'hidden';
  }

  function showAuthPanel(name) {
    const panels = {
      main: 'auth-panel-main',
      verify: 'auth-panel-verify',
      forgot: 'auth-panel-forgot',
      reset: 'auth-panel-reset',
    };
    Object.keys(panels).forEach((k) => {
      const el = $(panels[k]);
      if (el) el.classList.toggle('hidden', k !== name);
    });
    showAuthMessage('');
    showPanelMessage('verify-message', '');
    showPanelMessage('forgot-message', '');
    showPanelMessage('reset-message', '');
  }

  function refreshConfigNote() {
    const note = $('auth-config-note');
    if (!note) return;
    if (supabaseReady()) {
      note.classList.remove('hidden');
      note.textContent = t('auth.configOk');
    } else {
      note.classList.remove('hidden');
      note.textContent = t('auth.configMissing');
    }
  }

  function setAuthMode(mode) {
    authMode = mode;
    const reg = mode === 'register';
    showAuthPanel('main');
    $('auth-title').textContent = reg ? t('auth.register') : t('auth.login');
    $('auth-subtitle').textContent = reg
      ? supabaseReady()
        ? t('auth.subtitleRegister')
        : t('auth.subtitleRegisterNoSb')
      : supabaseReady()
        ? t('auth.subtitleLogin')
        : t('auth.subtitleLoginNoSb');
    $('tab-login').classList.toggle('active', !reg);
    $('tab-register').classList.toggle('active', reg);
    $('auth-confirm-wrap').classList.toggle('hidden', !reg);
    $('forgot-button').classList.toggle('hidden', reg);
    $('auth-submit').textContent = reg ? t('auth.register') : t('auth.login');
    $('auth-password').autocomplete = reg ? 'new-password' : 'current-password';
    showAuthMessage('');
    refreshConfigNote();
  }

  function showAuthMessage(message, type = 'error') {
    showPanelMessage('auth-message', message, type);
  }

  function openApp(user, isDemo = false) {
    activeUserId = isDemo ? 'demo-' + user.id : 'sb-' + user.id;
    activeUserEmail = user.email || 'konto demonstracyjne';
    demoMode = isDemo;
    products = load('products', []);
    historyData = load('history', []);
    ensureAccountCreated(user, isDemo);
    syncAdminActor();
    updateAdminCardVisibility();
    $('auth-screen').classList.add('hidden');
    $('main-app').style.display = 'flex';
    $('user-email').textContent = activeUserEmail;
    $('user-mode-label').textContent = isDemo
      ? t('auth.mode.demo')
      : t('auth.mode.user');
    const loadedAvatar = loadAvatarDataUrl(user);
    if (
      loadedAvatar &&
      /^https?:\/\//i.test(loadedAvatar) &&
      !localStorage.getItem(storageKey('avatar_public'))
    ) {
      localStorage.setItem(storageKey('avatar_public'), loadedAvatar);
    }
    applyAvatarToChrome(loadedAvatar);
    applyBanner(loadBannerDataUrl(user));
    init();
    refreshBillingUi();
    refreshUserSettingsUi();
    if (!isDemo) {
      const B = billing();
      if (B && typeof B.syncRemoteSubscription === 'function') {
        B.syncRemoteSubscription()
          .then(() => refreshBillingUi())
          .catch(() => {});
      }
      handleCheckoutReturn().catch(() => {});
    }
    const LB = window.PaletyzatorLeaderboard;
    if (LB) {
      LB.startSessionTracking(
        activeUserId,
        () => {
          const s = getProfileStats();
          return {
            displayName:
              (activeUserEmail || 'user').split('@')[0] || 'user',
            calcRuns: Math.max(Number(s.calcRuns) || 0, historyData.length),
            sessionSeconds: Number(s.sessionSeconds) || 0,
            avatarUrl: getRankAvatarUrl(),
            source: demoMode ? 'demo' : 'local',
          };
        },
        { syncRemote: !demoMode && supabaseReady() }
      );
      publishLeaderboardStats();
      refreshAuthRank();
      if (!isDemo && supabaseReady()) {
        ensureAvatarSyncedToRank(loadedAvatar);
      }
    }
  }

  /** Migruje lokalny/base64 avatar → Storage + avatar_url w rankingu. */
  async function ensureAvatarSyncedToRank(dataUrl) {
    if (!dataUrl || demoMode || !supabaseReady()) return;
    let publicUrl = getRankAvatarUrl();
    if (!publicUrl || /^data:/i.test(publicUrl)) {
      if (/^data:image\//i.test(dataUrl)) {
        publicUrl = await uploadAvatarPublic(dataUrl);
      } else if (/^https?:\/\//i.test(dataUrl)) {
        publicUrl = dataUrl;
        localStorage.setItem(storageKey('avatar_public'), dataUrl);
      }
    }
    if (!publicUrl) return;
    const LB = window.PaletyzatorLeaderboard;
    if (!LB) return;
    const s = getProfileStats();
    const tracked =
      typeof LB.getSessionSecondsTracked === 'function'
        ? LB.getSessionSecondsTracked()
        : 0;
    await LB.syncRemote({
      displayName: activeUserEmail || 'user',
      calcRuns: Math.max(Number(s.calcRuns) || 0, historyData.length),
      sessionSeconds: Math.max(Number(s.sessionSeconds) || 0, tracked),
      avatarUrl: publicUrl,
    });
    await refreshAuthRank({ silent: true });
  }

  function ensureAccountCreated(user, isDemo) {
    if (!isDemo && user && user.created_at) {
      accountCreatedAt = user.created_at;
      try {
        localStorage.setItem(storageKey('account_created'), user.created_at);
      } catch (_) { /* ignore */ }
      return;
    }
    let created = localStorage.getItem(storageKey('account_created'));
    if (!created) {
      created = new Date().toISOString();
      localStorage.setItem(storageKey('account_created'), created);
    }
    accountCreatedAt = created;
  }

  function getProfileStats() {
    const base = load('profile_stats', null) || {};
    return {
      calcRuns: Number(base.calcRuns) || 0,
      cmrOpens: Number(base.cmrOpens) || 0,
      trialRedeems: Number(base.trialRedeems) || 0,
      sessionSeconds: Number(base.sessionSeconds) || 0,
      lastCalcAt: base.lastCalcAt || null,
      lastPallet: base.lastPallet || null,
    };
  }

  function bumpProfileStat(key, by, extra) {
    const s = getProfileStats();
    if (key) s[key] = (Number(s[key]) || 0) + (by || 1);
    if (extra && typeof extra === 'object') Object.assign(s, extra);
    const LB = window.PaletyzatorLeaderboard;
    if (LB && activeUserId) {
      const tracked =
        typeof LB.getSessionSecondsTracked === 'function'
          ? LB.getSessionSecondsTracked()
          : 0;
      s.sessionSeconds = Math.max(Number(s.sessionSeconds) || 0, tracked);
    }
    localStorage.setItem(storageKey('profile_stats'), JSON.stringify(s));
    publishLeaderboardStats(s);
    if ($('view-user')?.classList.contains('active')) refreshUserStats();
  }

  /** URL do rankingu: public storage (https) > mały data URL > lokalny avatar. */
  function getRankAvatarUrl() {
    const pub = localStorage.getItem(storageKey('avatar_public'));
    if (pub && /^https?:\/\//i.test(pub)) return pub;
    const local = localStorage.getItem(storageKey('avatar'));
    if (local && /^https?:\/\//i.test(local)) return local;
    if (local && /^data:image\//i.test(local) && local.length < 48000) return local;
    return pub || null;
  }

  function compressDataUrl(dataUrl, maxSide, quality) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(img.width * scale));
        canvas.height = Math.max(1, Math.round(img.height * scale));
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.onerror = () => reject(new Error('avatar compress failed'));
      img.src = dataUrl;
    });
  }

  async function uploadAvatarPublic(dataUrl) {
    if (demoMode || !supabaseReady() || !dataUrl) return null;
    try {
      const Auth = authApi();
      const client = Auth && Auth.getClient && Auth.getClient();
      if (!client) return null;
      const { data: sess } = await client.auth.getSession();
      const user = sess?.session?.user;
      if (!user) return null;
      const small = await compressDataUrl(dataUrl, 128, 0.78);
      const blob = await (await fetch(small)).blob();
      const path = user.id + '/avatar.jpg';
      const { error } = await client.storage.from('avatars').upload(path, blob, {
        upsert: true,
        contentType: 'image/jpeg',
        cacheControl: '3600',
      });
      if (error) {
        console.warn('[avatar storage]', error.message);
        if (small.length < 48000) {
          localStorage.setItem(storageKey('avatar_public'), small);
          return small;
        }
        return null;
      }
      const { data } = client.storage.from('avatars').getPublicUrl(path);
      const url =
        data.publicUrl +
        (data.publicUrl.indexOf('?') >= 0 ? '&' : '?') +
        'v=' +
        Date.now();
      localStorage.setItem(storageKey('avatar_public'), url);
      return url;
    } catch (e) {
      console.warn('[avatar storage]', e.message || e);
      return null;
    }
  }

  async function clearAvatarPublic() {
    localStorage.removeItem(storageKey('avatar_public'));
    if (demoMode || !supabaseReady()) return;
    try {
      const Auth = authApi();
      const client = Auth && Auth.getClient && Auth.getClient();
      if (!client) return;
      const { data: sess } = await client.auth.getSession();
      const user = sess?.session?.user;
      if (!user) return;
      await client.storage.from('avatars').remove([user.id + '/avatar.jpg']);
    } catch (_) { /* ignore */ }
  }

  function publishLeaderboardStats(stats) {
    const LB = window.PaletyzatorLeaderboard;
    if (!LB || !activeUserId) return;
    const s = stats || getProfileStats();
    const tracked =
      typeof LB.getSessionSecondsTracked === 'function'
        ? LB.getSessionSecondsTracked()
        : 0;
    const calcRuns = Math.max(Number(s.calcRuns) || 0, historyData.length);
    const sessionSeconds = Math.max(Number(s.sessionSeconds) || 0, tracked);
    const displayName =
      (activeUserEmail || 'user').split('@')[0] || 'user';
    const avatarUrl = getRankAvatarUrl();
    const localAvatar = localStorage.getItem(storageKey('avatar')) || null;
    LB.upsertLocal({
      id: activeUserId,
      displayName,
      calcRuns,
      sessionSeconds,
      avatarUrl: avatarUrl || localAvatar,
      source: demoMode ? 'demo' : 'local',
    });
    if (!demoMode && supabaseReady()) {
      LB.syncRemote({
        displayName: activeUserEmail || displayName,
        calcRuns,
        sessionSeconds,
        avatarUrl: avatarUrl,
      }).then((res) => {
        if (res && res.ok) refreshAuthRank({ silent: true });
      });
    }
  }

  function applyLoginAds() {
    const cfg = (window.PALETYZATOR_CONFIG && window.PALETYZATOR_CONFIG.loginAds) || [];
    const bySlot = {};
    cfg.forEach((item) => {
      if (item && item.slot != null) bySlot[Number(item.slot)] = item;
    });
    document.querySelectorAll('.auth-ad-slot[data-ad-slot]').forEach((el) => {
      const n = Number(el.getAttribute('data-ad-slot'));
      const item = bySlot[n] || {};
      const enabled = item.enabled !== false;
      const href = (item.href || el.getAttribute('data-ad-href') || '').trim();
      const imageUrl = (item.imageUrl || el.getAttribute('data-ad-image') || '').trim();
      const label = (item.label || '').trim();
      el.classList.remove('is-live', 'is-hidden-slot');
      el.querySelectorAll('.auth-ad-slot__img').forEach((img) => img.remove());
      if (!enabled) {
        el.classList.add('is-hidden-slot');
        el.setAttribute('aria-hidden', 'true');
        return;
      }
      el.removeAttribute('aria-hidden');
      const labelEl = el.querySelector('.auth-ad-slot__label');
      if (labelEl) {
        if (label) {
          labelEl.textContent = label;
          labelEl.removeAttribute('data-i18n');
        } else {
          labelEl.setAttribute('data-i18n', 'ads.placeholder');
          labelEl.textContent = t('ads.placeholder');
        }
      }
      if (imageUrl && /^https?:\/\//i.test(imageUrl)) {
        const img = document.createElement('img');
        img.className = 'auth-ad-slot__img';
        img.src = imageUrl;
        img.alt = label || t('ads.placeholder');
        img.loading = 'lazy';
        el.appendChild(img);
        el.classList.add('is-live');
        el.setAttribute('data-ad-image', imageUrl);
      } else {
        el.setAttribute('data-ad-image', '');
      }
      if (href && /^https?:\/\//i.test(href)) {
        el.href = href;
        el.target = '_blank';
        el.rel = 'noopener noreferrer sponsored';
        el.removeAttribute('aria-disabled');
        el.removeAttribute('tabindex');
        el.onclick = null;
        el.classList.add('is-live');
        el.setAttribute('data-ad-href', href);
      } else {
        el.href = '#';
        el.setAttribute('aria-disabled', 'true');
        el.setAttribute('tabindex', '-1');
        el.removeAttribute('target');
        el.removeAttribute('rel');
        el.setAttribute('data-ad-href', '');
        el.onclick = (ev) => ev.preventDefault();
      }
    });
  }

  function setRankNoteEl(noteEl, source) {
    if (!noteEl) return;
    let key = 'rank.note';
    if (source === 'supabase') key = 'rank.noteLive';
    else if (source === 'empty') key = 'rank.noteEmpty';
    else if (source === 'fallback') key = 'rank.noteFallback';
    else if (source === 'loading') key = 'rank.noteLoading';
    noteEl.setAttribute('data-i18n', key);
    noteEl.textContent = t(key);
    noteEl.classList.toggle('is-fallback', source === 'fallback');
    noteEl.classList.toggle('is-live', source === 'supabase');
  }

  function monthLabelUtc(month) {
    try {
      const [y, m] = month.split('-');
      const d = new Date(Date.UTC(Number(y), Number(m) - 1, 1));
      return d.toLocaleDateString(undefined, {
        month: 'long',
        year: 'numeric',
        timeZone: 'UTC',
      });
    } catch (_) {
      return month;
    }
  }

  function fillRankList(elId, metric, month) {
    const LB = window.PaletyzatorLeaderboard;
    const el = $(elId);
    if (!el || !LB) return;
    const top = LB.topBy(metric, month, 3);
    if (!top.length) {
      el.innerHTML = `<li class="rank-empty"><span class="rank-name">${esc(t('rank.empty'))}</span></li>`;
      return;
    }
    el.innerHTML = top
      .map((u, i) => {
        const place = i + 1;
        const val =
          metric === 'time'
            ? LB.formatDuration(u.sessionSeconds)
            : String(u.calcRuns);
        return `<li class="place-${place}">
            ${LB.trophySvg(place)}
            ${LB.avatarHtml ? LB.avatarHtml(u) : ''}
            <span class="rank-name">${esc(u.displayName)}</span>
            <span class="rank-metric">${esc(val)}</span>
          </li>`;
      })
      .join('');
  }

  function paintAuthRankLists() {
    const LB = window.PaletyzatorLeaderboard;
    if (!LB) return;
    const month = LB.monthKey();
    const label = $('auth-rank-month');
    if (label) label.textContent = monthLabelUtc(month);
    const userLabel = $('user-rank-month');
    if (userLabel) userLabel.textContent = monthLabelUtc(month);
    const source = LB.getSource ? LB.getSource(month) : 'fallback';
    setRankNoteEl($('auth-rank-note'), source);
    setRankNoteEl($('user-rank-note'), source);
    fillRankList('auth-rank-calcs', 'calcs', month);
    fillRankList('auth-rank-time', 'time', month);
    fillRankList('user-rank-calcs', 'calcs', month);
    fillRankList('user-rank-time', 'time', month);
  }

  /** Top z Supabase; seed tylko gdy offline / brak tabeli. */
  let _rankRefreshToken = 0;
  async function refreshAuthRank(opts) {
    const LB = window.PaletyzatorLeaderboard;
    if (!LB) return;
    const silent = opts && opts.silent;
    const token = ++_rankRefreshToken;
    if (!silent) {
      setRankNoteEl($('auth-rank-note'), 'loading');
      setRankNoteEl($('user-rank-note'), 'loading');
    }
    try {
      await LB.pullRemote();
    } catch (_) { /* fallback inside pullRemote */ }
    if (token !== _rankRefreshToken) return;
    paintAuthRankLists();
  }

  /** synchroniczny paint z cache (locale change) + async refresh */
  function renderAuthRank() {
    paintAuthRankLists();
    refreshAuthRank({ silent: true });
  }

  function favoritePalletFromHistory() {
    const counts = {};
    historyData.forEach((h) => {
      const key =
        h.L && h.W
          ? h.L + '×' + h.W
          : h.pallet || h.palletLabel || '';
      if (!key) return;
      counts[key] = (counts[key] || 0) + 1;
    });
    let best = null;
    let n = 0;
    Object.keys(counts).forEach((k) => {
      if (counts[k] > n) {
        n = counts[k];
        best = k;
      }
    });
    return best;
  }

  function formatProfileDate(iso) {
    if (!iso) return '—';
    try {
      return new Date(iso).toLocaleString(undefined, {
        dateStyle: 'medium',
        timeStyle: 'short',
      });
    } catch (_) {
      return String(iso);
    }
  }

  function loadAvatarDataUrl(user) {
    const local = localStorage.getItem(storageKey('avatar'));
    if (local) return local;
    const meta =
      user &&
      user.user_metadata &&
      (user.user_metadata.avatar_url || user.user_metadata.avatar);
    return meta || '';
  }

  function loadBannerDataUrl(user) {
    const local = localStorage.getItem(storageKey('banner'));
    if (local) return local;
    const meta =
      user &&
      user.user_metadata &&
      (user.user_metadata.banner_url || user.user_metadata.banner);
    return meta || '';
  }

  function paintAvatarNode(node, dataUrl, letter) {
    if (!node) return;
    if (dataUrl) {
      node.classList.add('has-image');
      node.style.backgroundImage = 'url(' + JSON.stringify(String(dataUrl)) + ')';
      node.textContent = '';
    } else {
      node.classList.remove('has-image');
      node.style.backgroundImage = '';
      node.textContent = letter;
    }
  }

  function applyAvatarToChrome(dataUrl) {
    const letter = (activeUserEmail[0] || 'U').toUpperCase();
    paintAvatarNode($('user-avatar'), dataUrl, letter);
    paintAvatarNode($('avatar-preview'), dataUrl, letter);
    paintAvatarNode($('avatar-preview-edit'), dataUrl, letter);
  }

  function applyBanner(dataUrl) {
    const banner = $('user-banner');
    const preview = $('banner-preview');
    const paint = (node, emptyText) => {
      if (!node) return;
      if (dataUrl) {
        node.classList.add('has-image');
        node.style.backgroundImage = 'url(' + JSON.stringify(String(dataUrl)) + ')';
        if (emptyText) node.textContent = '';
      } else {
        node.classList.remove('has-image');
        node.style.backgroundImage = '';
        if (emptyText) node.textContent = emptyText;
      }
    };
    paint(banner, false);
    paint(preview, t('user.bannerEmpty'));
  }

  function refreshUserStats() {
    const el = $('user-stats');
    if (!el) return;
    const s = getProfileStats();
    const calcRuns = Math.max(s.calcRuns, historyData.length);
    const lastAt =
      s.lastCalcAt ||
      (historyData[0] && (historyData[0].date || historyData[0].id
        ? historyData[0].date || new Date(historyData[0].id).toISOString()
        : null));
    const fav =
      favoritePalletFromHistory() || s.lastPallet || '—';
    let compareHtml = '';
    const LB = window.PaletyzatorLeaderboard;
    if (LB) {
      publishLeaderboardStats(s);
      refreshAuthRank({ silent: true });
      const pct = LB.calcPercentile(calcRuns);
      const text =
        pct.percentile <= 0
          ? t('user.stat.percentileLow')
          : t('user.stat.percentile', { n: pct.percentile });
      compareHtml = `<div class="user-stat user-stat-compare"><label>${esc(t('user.stat.compare'))}</label><strong>${esc(text)}</strong></div>`;
    }
    const rows = [
      { label: t('user.stat.calcs'), value: String(calcRuns) },
      { label: t('user.stat.sku'), value: String(products.length) },
      { label: t('user.stat.cmr'), value: String(s.cmrOpens) },
      {
        label: t('user.stat.lastCalc'),
        value: lastAt ? formatProfileDate(lastAt) : t('user.stat.never'),
      },
      { label: t('user.stat.favPallet'), value: fav },
      { label: t('user.stat.trials'), value: String(s.trialRedeems) },
    ];
    el.innerHTML =
      rows
        .map(
          (r) =>
            `<div class="user-stat"><label>${esc(r.label)}</label><strong>${esc(r.value)}</strong></div>`
        )
        .join('') + compareHtml;
  }

  function refreshUserSettingsUi() {
    const avatarUrl = localStorage.getItem(storageKey('avatar')) || '';
    const bannerUrl = localStorage.getItem(storageKey('banner')) || '';
    pendingAvatarDataUrl = avatarUrl || null;
    pendingBannerDataUrl = bannerUrl || null;
    applyAvatarToChrome(avatarUrl);
    applyBanner(bannerUrl);
    if ($('user-profile-email')) {
      $('user-profile-email').textContent = activeUserEmail || '—';
    }
    if ($('user-profile-mode')) {
      $('user-profile-mode').textContent = demoMode
        ? t('auth.mode.demo')
        : t('auth.mode.user');
    }
    const created =
      accountCreatedAt || localStorage.getItem(storageKey('account_created'));
    if ($('user-profile-since')) {
      $('user-profile-since').textContent = created
        ? t('user.stat.since', { date: formatProfileDate(created) })
        : t('user.stat.sinceUnknown');
    }
    refreshUserStats();
  }

  function showUserMsg(id, text, type) {
    showPanelMessage(id, text, type);
  }

  function resizeImageToDataUrl(file, opts) {
    const maxSide = (opts && opts.maxSide) || 256;
    const mode = (opts && opts.mode) || 'fit';
    const outW = (opts && opts.width) || null;
    const outH = (opts && opts.height) || null;
    return new Promise((resolve, reject) => {
      if (!file || !file.type.startsWith('image/')) {
        reject(new Error(t('user.avatarNeedFile')));
        return;
      }
      if (file.size > 3.5 * 1024 * 1024) {
        reject(new Error(t('user.avatarTooBig')));
        return;
      }
      const reader = new FileReader();
      reader.onerror = () => reject(new Error(t('user.avatarNeedFile')));
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          if (mode === 'cover' && outW && outH) {
            canvas.width = outW;
            canvas.height = outH;
            const scale = Math.max(outW / img.width, outH / img.height);
            const w = img.width * scale;
            const h = img.height * scale;
            const x = (outW - w) / 2;
            const y = (outH - h) / 2;
            ctx.drawImage(img, x, y, w, h);
          } else {
            const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
            canvas.width = Math.max(1, Math.round(img.width * scale));
            canvas.height = Math.max(1, Math.round(img.height * scale));
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          }
          resolve(canvas.toDataURL('image/jpeg', 0.85));
        };
        img.onerror = () => reject(new Error(t('user.avatarNeedFile')));
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  async function pushUserMediaMeta(patch) {
    if (demoMode || !supabaseReady()) return;
    try {
      const Auth = authApi();
      const client = Auth && Auth.getClient && Auth.getClient();
      if (client) await client.auth.updateUser({ data: patch });
    } catch (_) { /* local still ok */ }
  }

  async function saveAvatar() {
    const dataUrl = pendingAvatarDataUrl;
    if (!dataUrl) {
      showUserMsg('avatar-message', t('user.avatarNeedFile'), 'error');
      return;
    }
    localStorage.setItem(storageKey('avatar'), dataUrl);
    applyAvatarToChrome(dataUrl);
    const publicUrl = await uploadAvatarPublic(dataUrl);
    const metaUrl = publicUrl || dataUrl;
    await pushUserMediaMeta({ avatar_url: metaUrl });
    const LB = window.PaletyzatorLeaderboard;
    if (!demoMode && LB && supabaseReady()) {
      const s = getProfileStats();
      const tracked =
        typeof LB.getSessionSecondsTracked === 'function'
          ? LB.getSessionSecondsTracked()
          : 0;
      await LB.syncRemote({
        displayName: activeUserEmail || 'user',
        calcRuns: Math.max(Number(s.calcRuns) || 0, historyData.length),
        sessionSeconds: Math.max(Number(s.sessionSeconds) || 0, tracked),
        avatarUrl: publicUrl || getRankAvatarUrl(),
      });
      await refreshAuthRank({ silent: true });
    } else {
      publishLeaderboardStats();
    }
    showUserMsg('avatar-message', t('user.avatarSaved'), 'success');
  }

  async function clearAvatar() {
    pendingAvatarDataUrl = null;
    localStorage.removeItem(storageKey('avatar'));
    await clearAvatarPublic();
    applyAvatarToChrome('');
    if ($('avatar-file')) $('avatar-file').value = '';
    await pushUserMediaMeta({ avatar_url: null });
    const LB = window.PaletyzatorLeaderboard;
    if (!demoMode && LB && supabaseReady()) {
      const s = getProfileStats();
      await LB.syncRemote({
        displayName: activeUserEmail || 'user',
        calcRuns: Math.max(Number(s.calcRuns) || 0, historyData.length),
        sessionSeconds: Number(s.sessionSeconds) || 0,
        avatarUrl: null,
      });
      await refreshAuthRank({ silent: true });
    } else {
      publishLeaderboardStats();
    }
    showUserMsg('avatar-message', t('user.avatarCleared'), 'success');
  }

  async function saveBanner() {
    const dataUrl = pendingBannerDataUrl;
    if (!dataUrl) {
      showUserMsg('avatar-message', t('user.bannerNeedFile'), 'error');
      return;
    }
    localStorage.setItem(storageKey('banner'), dataUrl);
    applyBanner(dataUrl);
    await pushUserMediaMeta({ banner_url: dataUrl });
    showUserMsg('avatar-message', t('user.bannerSaved'), 'success');
  }

  async function clearBanner() {
    pendingBannerDataUrl = null;
    localStorage.removeItem(storageKey('banner'));
    applyBanner('');
    if ($('banner-file')) $('banner-file').value = '';
    await pushUserMediaMeta({ banner_url: null });
    showUserMsg('avatar-message', t('user.bannerCleared'), 'success');
  }

  function getDemoPassword() {
    return localStorage.getItem(storageKey('demo_password')) || DEMO_PASS_DEFAULT;
  }

  function setDemoPassword(pw) {
    localStorage.setItem(storageKey('demo_password'), pw);
  }

  async function submitUserPassword(e) {
    e.preventDefault();
    const cur = $('user-pass-current')?.value || '';
    const next = $('user-pass-new')?.value || '';
    const conf = $('user-pass-confirm')?.value || '';
    if (next.length < 8) {
      showUserMsg('user-pass-message', t('auth.err.short'), 'error');
      return;
    }
    if (next !== conf) {
      showUserMsg('user-pass-message', t('auth.err.mismatch'), 'error');
      return;
    }
    const btn = $('user-pass-submit');
    if (btn) btn.disabled = true;
    try {
      if (demoMode) {
        if (cur !== getDemoPassword()) {
          showUserMsg(
            'user-pass-message',
            t('user.passWrong') + ' ' + t('user.passDemoHint'),
            'error'
          );
          return;
        }
        setDemoPassword(next);
        showUserMsg('user-pass-message', t('user.passOk'), 'success');
        $('user-password-form')?.reset();
        return;
      }
      if (!supabaseReady()) {
        showUserMsg('user-pass-message', t('user.passNeedsSb'), 'error');
        return;
      }
      const Auth = authApi();
      try {
        await Auth.signIn(activeUserEmail, cur);
      } catch (_) {
        showUserMsg('user-pass-message', t('user.passWrong'), 'error');
        return;
      }
      await Auth.updatePassword(next);
      showUserMsg('user-pass-message', t('user.passOk'), 'success');
      $('user-password-form')?.reset();
      notifyMail('password_changed', {
        name: (activeUserEmail || '').split('@')[0] || 'Kliencie',
      });
    } catch (err) {
      showUserMsg(
        'user-pass-message',
        err.plMessage || (authApi() && authApi().plError(err)) || err.message,
        'error'
      );
    } finally {
      if (btn) btn.disabled = false;
    }
  }

  async function cancelSubscriptionFlow() {
    const B = billing();
    if (!B || !B.cancelSubscription) return;
    if (!confirm(t('billing.cancelConfirm'))) return;
    const res = B.cancelSubscription();
    const msg = $('billing-cancel-message');
    if (!res.ok) {
      if (msg) {
        msg.textContent = res.error || t('billing.cancel.none');
        msg.className = 'auth-error';
      }
      return;
    }
    const planName = t('billing.tier.' + (res.previousTier || 'business'));
    if (msg) {
      msg.textContent = t('billing.cancelOk');
      msg.className = 'auth-success';
    }
    refreshBillingUi();
    applyFeatureGates();
    const mailRes = await notifyMail('subscription_cancelled', {
      plan: planName,
      name: (activeUserEmail || '').split('@')[0] || 'Kliencie',
    });
    if (msg && mailRes && mailRes.skipped && !demoMode) {
      msg.textContent = t('billing.cancelOk') + ' ' + t('billing.cancelMailSkip');
    } else if (msg && mailRes && mailRes.ok === false && !mailRes.skipped) {
      msg.textContent = t('billing.cancelOk') + ' ' + t('billing.cancelMailFail');
      msg.className = 'auth-success';
    }
  }

  function renderViesResult(payload) {
    const body = $('vies-result-body');
    const status = $('vies-result-status');
    const pdfBtn = $('vies-pdf-btn');
    if (!body) return;
    if (!payload || !payload.result) {
      body.className = 'vies-result empty';
      body.textContent = t('vies.resultEmpty');
      if (status) status.textContent = t('vies.resultIdle');
      if (pdfBtn) pdfBtn.disabled = true;
      return;
    }
    const r = payload.result;
    const ok = !!r.valid;
    if (status) {
      status.textContent = ok ? t('vies.valid') : t('vies.invalid');
    }
    const dt =
      window.PaletyzatorVies && window.PaletyzatorVies.formatDateTime
        ? window.PaletyzatorVies.formatDateTime(r.requestDate)
        : { local: r.requestDate || '', utc: '' };
    const src =
      window.PaletyzatorVies && window.PaletyzatorVies.sourceLabel
        ? window.PaletyzatorVies.sourceLabel(r.source)
        : r.source;
    body.className = 'vies-result ' + (ok ? 'is-valid' : 'is-invalid');
    body.innerHTML = `
      <div class="kpi-line"><span data-i18n-skip>${t('vies.pdf.vat')}</span><strong>${esc(r.fullVat)}</strong></div>
      <div class="kpi-line"><span>${t('vies.pdf.result')}</span><strong class="${ok ? 'ok' : 'bad'}">${esc(ok ? t('vies.valid') : t('vies.invalid'))}</strong></div>
      <div class="kpi-line"><span>${t('vies.name')}</span><strong>${esc(r.name || '—')}</strong></div>
      <div class="kpi-line"><span>${t('vies.address')}</span><strong style="white-space:pre-wrap;text-align:right;max-width:60%">${esc(r.address || '—')}</strong></div>
      <div class="kpi-line"><span>${t('vies.ref')}</span><strong>${esc(r.requestIdentifier || t('vies.refMissing'))}</strong></div>
      <div class="kpi-line"><span>${t('vies.queriedAt')}</span><strong>${esc(dt.local)}</strong></div>
      <div class="kpi-line"><span>${t('vies.source')}</span><strong>${esc(src)}</strong></div>
      ${payload.fallback ? `<p class="hint" style="margin-top:10px">${esc(t('vies.fallbackNote'))}</p>` : ''}
    `;
    if (pdfBtn) pdfBtn.disabled = false;
  }

  async function submitVies(e) {
    e.preventDefault();
    if (!requireFeature('vies')) return;
    if (!window.PaletyzatorVies) {
      showUserMsg('vies-message', t('vies.err.network'), 'error');
      return;
    }
    const full = ($('vies-full')?.value || '').trim();
    const number = ($('vies-number')?.value || '').trim();
    const country = ($('vies-country')?.value || 'PL').trim();
    const btn = $('vies-submit');
    if (btn) {
      btn.disabled = true;
      btn.textContent = t('vies.checking');
    }
    showUserMsg('vies-message', '', 'error');
    try {
      const res = await window.PaletyzatorVies.checkVat(
        full || number,
        full ? '' : country
      );
      if (!res.ok) {
        lastViesResult = null;
        renderViesResult(null);
        showUserMsg('vies-message', res.error || t('vies.err.network'), 'error');
        return;
      }
      lastViesResult = res.result;
      renderViesResult(res);
      const msg = $('vies-message');
      if (msg) msg.className = 'hidden';
    } catch (err) {
      lastViesResult = null;
      renderViesResult(null);
      showUserMsg('vies-message', err.message || t('vies.err.network'), 'error');
    } finally {
      if (btn) {
        btn.disabled = false;
        btn.textContent = t('vies.check');
      }
    }
  }

  async function openViesPdf() {
    if (!requireFeature('vies')) return;
    if (!lastViesResult || !window.PaletyzatorVies) {
      alert(t('vies.resultEmpty'));
      return;
    }
    try {
      await window.PaletyzatorVies.openConfirmationPdf(lastViesResult);
    } catch (err) {
      alert(err.message || t('vies.err.network'));
    }
  }

  async function submitAuth(e) {
    e.preventDefault();
    if (authBusy) return;
    const email = $('auth-email').value.trim().toLowerCase();
    const password = $('auth-password').value;
    if (authMode === 'register' && password !== $('auth-password-confirm').value) {
      showAuthMessage(t('auth.err.mismatch'));
      return;
    }
    if (password.length < 8) {
      showAuthMessage(t('auth.err.short'));
      return;
    }
    if (!email) {
      showAuthMessage(t('auth.err.email'));
      return;
    }

    if (!supabaseReady()) {
      showAuthMessage(t('auth.err.noSb'), 'error');
      return;
    }

    const Auth = authApi();
    authBusy = true;
    $('auth-submit').disabled = true;
    try {
      if (authMode === 'register') {
        const data = await Auth.signUp(email, password);
        const needsConfirm =
          !data.session ||
          (data.user && !data.user.email_confirmed_at && !data.session);
        if (data.session && data.user) {
          openApp(
            {
              id: data.user.id,
              email: data.user.email || email,
              created_at: data.user.created_at,
            },
            false
          );
          notifyMail('registration_welcome', {
            name: email.split('@')[0] || 'Kliencie',
            email,
          });
          return;
        }
        pendingVerifyEmail = email;
        const lead = $('verify-lead');
        if (lead) {
          lead.innerHTML = t('auth.verifyLead', { email: `<strong id="verify-email-label">${esc(email)}</strong>` });
        } else if ($('verify-email-label')) {
          $('verify-email-label').textContent = email;
        }
        showAuthPanel('verify');
        showPanelMessage(
          'verify-message',
          needsConfirm
            ? t('auth.ok.verifyPending')
            : t('auth.ok.verified'),
          'success'
        );
      } else {
        const data = await Auth.signIn(email, password);
        const user = data.user || data.session?.user;
        if (!user) throw new Error('Brak danych użytkownika po logowaniu.');
        openApp(
          {
            id: user.id,
            email: user.email || email,
            created_at: user.created_at,
          },
          false
        );
      }
    } catch (err) {
      showAuthMessage(err.plMessage || Auth.plError(err) || err.message || String(err));
    } finally {
      authBusy = false;
      $('auth-submit').disabled = false;
    }
  }

  function openForgotPanel() {
    if (!supabaseReady()) {
      showAuthMessage(t('auth.err.resetNeedsSb'), 'error');
      return;
    }
    $('forgot-email').value = $('auth-email').value.trim();
    showAuthPanel('forgot');
  }

  async function submitForgot(e) {
    e.preventDefault();
    if (authBusy) return;
    const email = $('forgot-email').value.trim().toLowerCase();
    if (!email) {
      showPanelMessage('forgot-message', 'Podaj adres e-mail.');
      return;
    }
    if (!supabaseReady()) {
      showPanelMessage(
        'forgot-message',
        'Brak konfiguracji Supabase.'
      );
      return;
    }
    const Auth = authApi();
    if (!Auth.getRedirectBase()) {
      showPanelMessage('forgot-message', t('auth.err.siteUrl'), 'error');
      return;
    }
    authBusy = true;
    $('forgot-submit').disabled = true;
    try {
      await Auth.resetPasswordForEmail(email);
      showPanelMessage('forgot-message', t('auth.ok.resetSent'), 'success');
    } catch (err) {
      showPanelMessage(
        'forgot-message',
        err.plMessage || Auth.plError(err) || err.message
      );
    } finally {
      authBusy = false;
      $('forgot-submit').disabled = false;
    }
  }

  async function submitReset(e) {
    e.preventDefault();
    if (authBusy) return;
    const p1 = $('reset-password').value;
    const p2 = $('reset-password-confirm').value;
    if (p1.length < 8) {
      showPanelMessage('reset-message', t('auth.err.short'));
      return;
    }
    if (p1 !== p2) {
      showPanelMessage('reset-message', t('auth.err.mismatch'));
      return;
    }
    const Auth = authApi();
    authBusy = true;
    $('reset-submit').disabled = true;
    try {
      await Auth.updatePassword(p1);
      showPanelMessage('reset-message', t('auth.ok.passwordSaved'), 'success');
      const session = await Auth.getSession();
      const user = session?.user;
      if (user) {
        Auth.clearAuthHash();
        openApp(
          {
            id: user.id,
            email: user.email,
            created_at: user.created_at,
          },
          false
        );
        notifyMail('password_changed', {
          name: (user.email || '').split('@')[0] || 'Kliencie',
          email: user.email,
        });
      } else {
        setTimeout(() => setAuthMode('login'), 800);
      }
    } catch (err) {
      showPanelMessage(
        'reset-message',
        err.plMessage || Auth.plError(err) || err.message
      );
    } finally {
      authBusy = false;
      $('reset-submit').disabled = false;
    }
  }

  async function resendConfirm() {
    if (authBusy) return;
    const email = pendingVerifyEmail || $('auth-email').value.trim().toLowerCase();
    if (!email) {
      showPanelMessage('verify-message', 'Brak adresu e-mail do ponownego wysłania.');
      return;
    }
    const Auth = authApi();
    authBusy = true;
    $('btn-resend-confirm').disabled = true;
    try {
      await Auth.resendConfirmation(email);
      showPanelMessage('verify-message', t('auth.ok.resend'), 'success');
    } catch (err) {
      showPanelMessage(
        'verify-message',
        err.plMessage || Auth.plError(err) || err.message
      );
    } finally {
      authBusy = false;
      $('btn-resend-confirm').disabled = false;
    }
  }

  function demoLogin() {
    const email = $('auth-email').value.trim().toLowerCase() || 'demo@lokalnie.test';
    openApp(
      {
        id: btoa(unescape(encodeURIComponent(email)))
          .replace(/[^a-zA-Z0-9]/g, '')
          .slice(0, 32),
        email,
      },
      true
    );
  }

  async function signOut() {
    publishLeaderboardStats();
    if (window.PaletyzatorLeaderboard) {
      window.PaletyzatorLeaderboard.stopSessionTracking();
    }
    if (!demoMode && supabaseReady()) {
      try {
        await authApi().signOut();
      } catch (_) { /* ignore */ }
    }
    const B = billing();
    if (B && typeof B.clearEntitlement === 'function') B.clearEntitlement();
    activeUserId = null;
    activeUserEmail = '';
    demoMode = false;
    syncAdminActor();
    updateAdminCardVisibility();
    $('main-app').style.display = 'none';
    $('auth-screen').classList.remove('hidden');
    setAuthMode('login');
    renderAuthRank();
  }

  async function bootstrapAuth() {
    refreshConfigNote();
    setAuthMode('login');
    if (!supabaseReady()) return;

    const Auth = authApi();
    const hints = Auth.peekAuthUrlHints();
    let appOpened = false;

    const enterFromSession = (user) => {
      if (!user || appOpened || demoMode) return;
      if ($('main-app').style.display !== 'none') return;
      appOpened = true;
      Auth.clearAuthHash();
      openApp(
        {
          id: user.id,
          email: user.email,
          created_at: user.created_at,
        },
        false
      );
    };

    Auth.onAuthStateChange(async (event, session) => {
      if (event === 'PASSWORD_RECOVERY') {
        showAuthPanel('reset');
        return;
      }
      if (event === 'SIGNED_IN' && session?.user) {
        if (hints.type === 'recovery' || hints.ui === 'reset') {
          showAuthPanel('reset');
          return;
        }
        enterFromSession(session.user);
      }
    });

    try {
      if (hints.type === 'recovery' || hints.ui === 'reset') {
        showAuthPanel('reset');
      }
      const session = await Auth.getSession();
      if (hints.type === 'recovery' || hints.ui === 'reset') {
        return;
      }
      if (session?.user) {
        enterFromSession(session.user);
      } else if (hints.ui === 'verified') {
        showAuthMessage(t('auth.ok.verified'), 'success');
        Auth.clearAuthHash();
      }
    } catch (err) {
      console.warn('[auth]', err);
    }
  }

  // Paczka klienta: usuń admin z DOM zanim podepniemy handlery
  stripAdminUiForClient();

  // Wire UI
  $('tab-login').addEventListener('click', () => setAuthMode('login'));
  $('tab-register').addEventListener('click', () => setAuthMode('register'));
  $('auth-form').addEventListener('submit', submitAuth);
  $('forgot-button').addEventListener('click', openForgotPanel);
  $('forgot-form')?.addEventListener('submit', submitForgot);
  $('reset-form')?.addEventListener('submit', submitReset);
  $('btn-forgot-back')?.addEventListener('click', () => setAuthMode('login'));
  $('btn-verify-back')?.addEventListener('click', () => setAuthMode('login'));
  $('btn-resend-confirm')?.addEventListener('click', resendConfirm);
  $('demo-button').addEventListener('click', demoLogin);
  $('btn-signout').addEventListener('click', () => signOut());
  $('btn-new-calc').addEventListener('click', () => showView('calculator'));
  $('btn-open-sku').addEventListener('click', () => showView('products'));
  $('btn-goto-calc').addEventListener('click', () => showView('calculator'));
  $('btn-reset-calc').addEventListener('click', resetCalc);
  $('btn-add-box').addEventListener('click', () => addBoxRow());
  $('pallet-type').addEventListener('change', () => {
    palletChanged();
    scheduleLiveLimitAlerts();
  });
  $('btn-calculate').addEventListener('click', () => calculate());
  $('btn-save-calc').addEventListener('click', saveCurrent);
  $('btn-print').addEventListener('click', printReport);
  $('btn-offer-pdf')?.addEventListener('click', () => downloadOfferPdf());
  $('product-form').addEventListener('submit', saveProduct);
  $('btn-clear-product').addEventListener('click', clearProductForm);
  $('btn-export-products').addEventListener('click', exportProducts);
  $('btn-import-products').addEventListener('click', () =>
    $('import-file').click()
  );
  $('btn-import-csv')?.addEventListener('click', () =>
    $('import-csv-file')?.click()
  );
  $('import-file').addEventListener('change', importProducts);
  $('import-csv-file')?.addEventListener('change', importCsvProducts);
  $('sku-import-form')?.addEventListener('submit', (ev) => {
    const submitter = ev.submitter;
    const value = submitter && submitter.value;
    if (value === 'merge' || value === 'replace') {
      commitCsvImport(value);
    }
    pendingCsvImport = null;
  });
  $('product-search').addEventListener('input', renderProducts);
  $('calc-dest-country')?.addEventListener('change', () => {
    syncDestCountry($('calc-dest-country').value);
  });
  // Live limit alerts: SKU rows + pallet params
  const liveRoot = $('box-rows');
  liveRoot?.addEventListener('input', scheduleLiveLimitAlerts);
  liveRoot?.addEventListener('change', scheduleLiveLimitAlerts);
  [
    'pallet-height',
    'pallet-length',
    'pallet-width',
    'max-height',
    'max-weight',
    'pallet-tol',
  ].forEach((id) => {
    $(id)?.addEventListener('input', scheduleLiveLimitAlerts);
    $(id)?.addEventListener('change', scheduleLiveLimitAlerts);
  });
  $('btn-export-history').addEventListener('click', exportHistory);
  $('btn-clear-history').addEventListener('click', clearHistory);
  $('btn-save-settings').addEventListener('click', saveSettings);
  $('btn-save-settings-cmr')?.addEventListener('click', saveSettings);
  $('btn-reset-all').addEventListener('click', resetAll);
  $('vies-form')?.addEventListener('submit', submitVies);
  $('vies-pdf-btn')?.addEventListener('click', openViesPdf);
  $('avatar-file')?.addEventListener('change', async (ev) => {
    const file = ev.target.files && ev.target.files[0];
    if (!file) return;
    try {
      pendingAvatarDataUrl = await resizeImageToDataUrl(file, { maxSide: 256 });
      applyAvatarToChrome(pendingAvatarDataUrl);
      const msg = $('avatar-message');
      if (msg) msg.className = 'hidden';
    } catch (err) {
      showUserMsg('avatar-message', err.message || t('user.avatarNeedFile'), 'error');
    }
  });
  $('banner-file')?.addEventListener('change', async (ev) => {
    const file = ev.target.files && ev.target.files[0];
    if (!file) return;
    try {
      pendingBannerDataUrl = await resizeImageToDataUrl(file, {
        mode: 'cover',
        width: 1200,
        height: 400,
      });
      applyBanner(pendingBannerDataUrl);
      const msg = $('avatar-message');
      if (msg) msg.className = 'hidden';
    } catch (err) {
      showUserMsg('avatar-message', err.message || t('user.bannerNeedFile'), 'error');
    }
  });
  $('btn-avatar-save')?.addEventListener('click', () => saveAvatar());
  $('btn-avatar-clear')?.addEventListener('click', () => clearAvatar());
  $('btn-banner-save')?.addEventListener('click', () => saveBanner());
  $('btn-banner-clear')?.addEventListener('click', () => clearBanner());
  $('user-password-form')?.addEventListener('submit', submitUserPassword);
  $('btn-viewer-reset').addEventListener('click', async () => {
    const v = await ensureViewer();
    if (v) v.resetCamera();
  });
  $('btn-viewer-recalc').addEventListener('click', () => calculate());
  $('btn-cmr').addEventListener('click', openCmrDocument);
  $('btn-single-calc')?.addEventListener('click', () => runSingleCalc());
  $('btn-single-to-mix')?.addEventListener('click', () => singleToMix());
  $('single-pallet')?.addEventListener('change', () => {
    const v = $('single-pallet').value;
    const dims = { '120x80': [120, 80], '60x80': [60, 80], '120x120': [120, 120] };
    if (dims[v]) {
      $('single-pl').value = dims[v][0];
      $('single-pw').value = dims[v][1];
    }
    const maxHByType = { '60x80': 150, '120x80': 180 };
    if (maxHByType[v] != null && $('single-mh')) {
      $('single-mh').value = maxHByType[v];
    }
  });


  // Billing / trial codes
  $('redeem-form')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const B = billing();
    if (!B) return;
    if (demoMode) {
      const msg = $('redeem-message');
      if (msg) {
        msg.textContent = t('billing.err.loginRequired');
        msg.className = 'auth-error';
      }
      return;
    }
    const msg = $('redeem-message');
    const submitBtn = $('redeem-submit');
    if (submitBtn) submitBtn.disabled = true;
    let res;
    try {
      res = await B.redeemCode($('redeem-code').value, activeUserEmail || '');
    } catch (err) {
      res = { ok: false, error: err.message || String(err) };
    }
    if (submitBtn) submitBtn.disabled = false;
    if (!msg) return;
    if (!res.ok) {
      msg.textContent = res.error;
      msg.className = 'auth-error';
      return;
    }
    msg.textContent = t('billing.redeemOk', {
      date: B.formatDate(res.subscription.trialEndsAt),
    });
    msg.className = 'auth-success';
    $('redeem-code').value = '';
    bumpProfileStat('trialRedeems', 1);
    refreshBillingUi();
    if (lastResult) calculate();
    await notifyMail('subscription_trial_started', {
      plan: t('billing.tier.' + (res.subscription.tier || 'business')),
      name: (activeUserEmail || '').split('@')[0] || 'Kliencie',
    });
  });
  $('btn-cancel-subscription')?.addEventListener('click', () =>
    cancelSubscriptionFlow()
  );
  $('btn-stripe-portal')?.addEventListener('click', () => openPortalFlow());
  async function genCodes(n) {
    syncAdminActor();
    const B = billing();
    if (!B) return;
    if (!isOwnerSession()) {
      alert(t('billing.err.admin'));
      return;
    }
    const btn1 = $('btn-gen-code');
    const btn5 = $('btn-gen-codes-5');
    const prev1 = btn1 ? btn1.disabled : false;
    const prev5 = btn5 ? btn5.disabled : false;
    if (btn1) btn1.disabled = true;
    if (btn5) btn5.disabled = true;
    try {
      const created = await B.generateCodes(n);
      const box = $('admin-last-code');
      if (box && created[0]) {
        box.classList.remove('hidden');
        box.innerHTML = `<span>${esc(created[0].code)}</span><button type="button" class="quiet smallbtn" id="btn-copy-last">${t('billing.copy')}</button>`;
        $('btn-copy-last')?.addEventListener('click', async () => {
          try {
            await navigator.clipboard.writeText(created[0].code);
          } catch (_) {
            prompt('Code', created[0].code);
          }
        });
      }
      renderAdminCodes();
    } catch (err) {
      alert(err.message || String(err));
    } finally {
      if (btn1) btn1.disabled = prev1;
      if (btn5) btn5.disabled = prev5;
    }
  }
  $('btn-gen-code')?.addEventListener('click', () => genCodes(1));
  $('btn-gen-codes-5')?.addEventListener('click', () => genCodes(5));
  document.addEventListener('paletyzator:billing', () => refreshBillingUi());
  document.addEventListener('paletyzator:locale', () => refreshBillingUi());


  if (window.I18n) {
    window.I18n.init();
    document.addEventListener('paletyzator:locale', () => {
      refreshConfigNote();
      setAuthMode(authMode);
      renderAuthRank();
      if ($('view-user')?.classList.contains('active')) refreshUserSettingsUi();
      populateCalcDestCountry();
      if (lastResult) {
        renderResultHTML(lastResult);
        if (lastVariants.length) renderVariants(lastVariants, lastResult.strategy);
      } else if ($('result-status')) {
        // keep idle copy in sync when no result
        if (!lastResult) {
          const empty = $('result-content')?.querySelector('.empty');
          if (empty) empty.textContent = t('calc.resultEmpty');
          if (!lastResult && $('result-status') && !$('result-content')?.querySelector('.resultbox')) {
            $('result-status').textContent = t('calc.resultIdle');
          }
        }
      }
      if ($('user-mode-label') && activeUserId) {
        $('user-mode-label').textContent = demoMode
          ? t('auth.mode.demo')
          : t('auth.mode.user');
      }
      $('product-count') &&
        ($('product-count').textContent = t('products.count', {
          n: products.length,
        }));
      // rebuild SKU row chrome labels by re-seeding only if empty calc? skip — new rows use t()
      if (window.I18n) window.I18n.apply();
    });
  }

  applyLoginAds();
  bootstrapAuth();
  renderAuthRank();

  // Expose for optional console use / debugging
  window.PaletyzatorApp = {
    showView,
    calculate,
    demoLogin,
    supabaseReady,
    refreshBillingUi,
    renderAuthRank,
    refreshAuthRank,
    applyLoginAds,
    isClientBuild,
  };
})();
