/**
 * Paletyzator Pro — transakcyjne maile przez Edge Function `send-transactional-email`.
 * Wymaga sesji Supabase (JWT). Klucz Resend zostaje wyłącznie w secrets funkcji — nigdy w kliencie.
 */
(function (global) {
  'use strict';

  const FN = 'send-transactional-email';

  function authApi() {
    return global.PaletyzatorAuth || null;
  }

  /**
   * @param {'registration_welcome'|'password_changed'|'password_reset_notice'|'subscription_cancelled'|'subscription_trial_started'} type
   * @param {Record<string, string>} [meta]
   */
  async function sendTransactional(type, meta) {
    const Auth = authApi();
    if (!Auth || !Auth.isConfigured || !Auth.isConfigured()) {
      return { ok: false, skipped: true, reason: 'no-config' };
    }
    const client = Auth.getClient();
    if (!client) return { ok: false, skipped: true, reason: 'no-client' };

    let session = null;
    try {
      const { data, error } = await client.auth.getSession();
      if (error) throw error;
      session = data.session;
    } catch (_) {
      return { ok: false, skipped: true, reason: 'no-session' };
    }
    if (!session || !session.access_token) {
      return { ok: false, skipped: true, reason: 'no-session' };
    }

    const email = String(
      (meta && meta.email) || session.user?.email || ''
    ).trim();
    if (!email) return { ok: false, skipped: true, reason: 'no-email' };

    const payload = {
      type,
      email,
      meta: {
        name: String((meta && meta.name) || email.split('@')[0] || 'Kliencie'),
        plan: String((meta && meta.plan) || ''),
        when: String((meta && meta.when) || new Date().toISOString()),
        ...(meta || {}),
      },
    };

    try {
      if (typeof client.functions?.invoke === 'function') {
        const { data, error } = await client.functions.invoke(FN, {
          body: payload,
        });
        if (error) {
          return {
            ok: false,
            error: error.message || String(error),
            details: data,
          };
        }
        return { ok: true, id: data && data.id, data };
      }
    } catch (e) {
      /* fall through to fetch */
      if (!e) { /* */ }
    }

    // Fallback fetch (CORS + JWT)
    try {
      const { supabaseUrl, supabaseAnonKey } = Auth.getConfig();
      const res = await fetch(
        supabaseUrl.replace(/\/$/, '') + '/functions/v1/' + FN,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: 'Bearer ' + session.access_token,
            apikey: supabaseAnonKey,
          },
          body: JSON.stringify(payload),
        }
      );
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        return {
          ok: false,
          error: (data && data.error) || 'HTTP ' + res.status,
          details: data,
        };
      }
      return { ok: true, id: data.id, data };
    } catch (err) {
      return { ok: false, error: err.message || String(err) };
    }
  }

  global.PaletyzatorMail = {
    sendTransactional,
    TYPES: [
      'registration_welcome',
      'password_changed',
      'password_reset_notice',
      'subscription_cancelled',
      'subscription_trial_started',
    ],
  };
})(typeof window !== 'undefined' ? window : globalThis);
