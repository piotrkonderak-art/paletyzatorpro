/**
 * Paletyzator Pro — miesięczny ranking globalny (Supabase user_activity_monthly).
 * Źródło prawdy: tabela w projekcie ertfehgetuxkmbfzpeed.
 * Lokalny seed tylko jako fallback offline / gdy tabela niedostępna.
 */
(function (global) {
  'use strict';

  const STORE_KEY = 'pp_leaderboard_v1';
  const CACHE_KEY = 'pp_rank_remote_cache_v1';

  /** @type {{ month: string|null, users: array, source: 'supabase'|'fallback'|'loading'|'empty', error: string|null, fetchedAt: number }} */
  let remoteState = {
    month: null,
    users: [],
    source: 'loading',
    error: null,
    fetchedAt: 0,
  };

  function monthKey(d) {
    const x = d || new Date();
    return x.getUTCFullYear() + '-' + String(x.getUTCMonth() + 1).padStart(2, '0');
  }

  function t(key, vars) {
    if (global.I18n && typeof global.I18n.t === 'function') {
      return global.I18n.t(key, vars);
    }
    return key;
  }

  function getClient() {
    const Auth = global.PaletyzatorAuth;
    if (!Auth || !Auth.isConfigured || !Auth.isConfigured()) return null;
    return Auth.getClient();
  }

  function mapRow(r) {
    return {
      id: r.user_id ? 'sb-' + r.user_id : 'sb-unknown',
      userId: r.user_id || null,
      displayName: r.display_name || 'user',
      calcRuns: Math.max(0, Number(r.calc_runs) || 0),
      sessionSeconds: Math.max(0, Number(r.session_seconds) || 0),
      avatarUrl: r.avatar_url || null,
      avatarHue:
        (String(r.display_name || r.user_id || 'U')
          .split('')
          .reduce((a, c) => a + c.charCodeAt(0), 0) %
          360) || 210,
      source: 'supabase',
      updatedAt: r.updated_at ? Date.parse(r.updated_at) || Date.now() : Date.now(),
    };
  }

  function seedForMonth(month) {
    const salt = String(month)
      .split('')
      .reduce((a, c) => a + c.charCodeAt(0), 0);
    const names = [
      'Nova Logistics',
      'EuroPack Sp.',
      'Magazyn 24',
      'TransBaltic',
      'SKU Masters',
      'PalletLab',
      'Forklift Pro',
      'CMR Express',
    ];
    const hues = [210, 165, 25, 280, 340, 145, 40, 195];
    return names.map((name, i) => {
      const calc = 18 + ((salt * (i + 3)) % 90) + i * 4;
      const secs = 1800 + ((salt * (i + 5)) % 24000) + i * 900;
      return {
        id: 'seed-' + month + '-' + i,
        userId: null,
        displayName: name,
        calcRuns: calc,
        sessionSeconds: secs,
        avatarUrl: null,
        avatarHue: hues[i % hues.length],
        source: 'seed',
        updatedAt: Date.now() - i * 3600000,
      };
    });
  }

  function readDiskCache() {
    try {
      const v = JSON.parse(localStorage.getItem(CACHE_KEY));
      if (v && Array.isArray(v.users) && v.month) return v;
    } catch (_) { /* ignore */ }
    return null;
  }

  function writeDiskCache(month, users) {
    try {
      localStorage.setItem(
        CACHE_KEY,
        JSON.stringify({ month, users, savedAt: Date.now() })
      );
    } catch (_) { /* ignore */ }
  }

  function loadStore() {
    try {
      const v = JSON.parse(localStorage.getItem(STORE_KEY));
      return v && typeof v === 'object' ? v : { months: {} };
    } catch (_) {
      return { months: {} };
    }
  }

  function saveStore(store) {
    try {
      localStorage.setItem(STORE_KEY, JSON.stringify(store));
    } catch (_) { /* ignore */ }
  }

  /** Lokalny mirror własnych statystyk (nie źródło Top). */
  function upsertLocal(entry) {
    const month = entry.month || monthKey();
    const store = loadStore();
    if (!store.months[month]) store.months[month] = { users: [] };
    const users = store.months[month].users;
    if (!Array.isArray(users)) store.months[month].users = [];
    const list = store.months[month].users;
    const idx = list.findIndex((u) => u.id === entry.id);
    const prev = idx >= 0 ? list[idx] : null;
    const row = {
      id: entry.id,
      displayName: entry.displayName || entry.id,
      calcRuns: Math.max(0, Number(entry.calcRuns) || 0),
      sessionSeconds: Math.max(0, Number(entry.sessionSeconds) || 0),
      avatarUrl:
        entry.avatarUrl !== undefined
          ? entry.avatarUrl
          : (prev && prev.avatarUrl) || null,
      avatarHue:
        entry.avatarHue != null
          ? entry.avatarHue
          : (prev && prev.avatarHue) ||
            (entry.displayName || entry.id || 'U')
              .split('')
              .reduce((a, c) => a + c.charCodeAt(0), 0) % 360,
      source: entry.source || 'local',
      updatedAt: Date.now(),
    };
    if (idx >= 0) list[idx] = { ...list[idx], ...row };
    else list.push(row);
    saveStore(store);
    return row;
  }

  function listMonth(month) {
    const m = month || monthKey();
    if (remoteState.month === m && remoteState.users.length) {
      return remoteState.users.slice();
    }
    const disk = readDiskCache();
    if (disk && disk.month === m && disk.users.length) return disk.users.slice();
    return [];
  }

  function rankingUsers(month) {
    const m = month || monthKey();
    if (remoteState.month === m && remoteState.source === 'supabase') {
      return remoteState.users.slice();
    }
    if (remoteState.month === m && remoteState.source === 'empty') {
      return [];
    }
    if (remoteState.month === m && remoteState.source === 'fallback') {
      return remoteState.users.slice();
    }
    const disk = readDiskCache();
    if (disk && disk.month === m && disk.users.length) return disk.users.slice();
    return seedForMonth(m);
  }

  function topBy(metric, month, limit) {
    const n = limit || 3;
    const list = rankingUsers(month);
    const key = metric === 'time' ? 'sessionSeconds' : 'calcRuns';
    return list
      .slice()
      .sort(
        (a, b) =>
          (b[key] || 0) - (a[key] || 0) ||
          (b.updatedAt || 0) - (a.updatedAt || 0)
      )
      .slice(0, n);
  }

  function getSource(month) {
    const m = month || monthKey();
    if (remoteState.month === m) return remoteState.source;
    const disk = readDiskCache();
    if (disk && disk.month === m && disk.users.length) return 'supabase';
    return 'fallback';
  }

  /** Percentyl względem globalnego zbioru (Supabase) lub fallback. */
  function calcPercentile(myCalcs, month) {
    const list = rankingUsers(month);
    if (!list.length) return { percentile: 0, sample: 0 };
    const mine = Math.max(0, Number(myCalcs) || 0);
    let below = 0;
    list.forEach((u) => {
      if ((Number(u.calcRuns) || 0) < mine) below++;
    });
    const percentile = Math.min(99, Math.floor((below / list.length) * 100));
    return { percentile, sample: list.length, mine };
  }

  function formatDuration(sec) {
    const s = Math.max(0, Math.floor(Number(sec) || 0));
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    if (h > 0) return t('rank.durationHm', { h, m });
    if (m > 0) return t('rank.durationM', { m });
    return t('rank.durationS', { s });
  }

  function trophySvg(place) {
    const colors = {
      1: { cup: '#d4a017', stem: '#b8860b', base: '#8a6a10' },
      2: { cup: '#b0b7c3', stem: '#8e96a3', base: '#6f7682' },
      3: { cup: '#c47a3a', stem: '#a35f28', base: '#7a451c' },
    };
    const c = colors[place] || colors[3];
    return `<svg class="rank-trophy" viewBox="0 0 48 48" width="36" height="36" aria-hidden="true">
      <path fill="${c.cup}" d="M12 8h24v6c0 7.2-5.4 13-12 13S12 21.2 12 14V8z"/>
      <path fill="${c.stem}" d="M22 27h4v7h-4z"/>
      <rect fill="${c.base}" x="16" y="34" width="16" height="4" rx="1"/>
      <path fill="none" stroke="${c.stem}" stroke-width="2.5" d="M12 10H8c0 6 3 9 6 10M36 10h4c0 6-3 9-6 10"/>
      <circle cx="24" cy="16" r="3" fill="rgba(255,255,255,0.35)"/>
    </svg>`;
  }

  function initialOf(name) {
    const s = String(name || 'U').trim();
    const ch = s.charAt(0) || 'U';
    return /[a-zA-ZÀ-ÿ0-9]/.test(ch) ? ch.toUpperCase() : 'U';
  }

  function escAttr(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/"/g, '&quot;')
      .replace(/</g, '&lt;');
  }

  /** Okrągły avatar: zdjęcie (avatar_url: https lub data URL) albo inicjał. */
  function avatarHtml(user) {
    const name = (user && user.displayName) || 'U';
    const letter = initialOf(name);
    const hue = user && user.avatarHue != null ? Number(user.avatarHue) : 210;
    const url = user && user.avatarUrl ? String(user.avatarUrl).trim() : '';
    if (url && /^data:image\/[a-zA-Z0-9.+-]+;base64,/i.test(url)) {
      return `<span class="rank-avatar has-image" role="img" aria-label="${escAttr(letter)}"><img class="rank-avatar__img" src="${escAttr(url)}" alt="" loading="lazy" decoding="async"></span>`;
    }
    if (url && /^https?:\/\//i.test(url)) {
      return `<span class="rank-avatar has-image" role="img" aria-label="${escAttr(letter)}"><img class="rank-avatar__img" src="${escAttr(url)}" alt="" loading="lazy" decoding="async" referrerpolicy="no-referrer"></span>`;
    }
    return `<span class="rank-avatar" style="background:linear-gradient(145deg,hsl(${hue},62%,72%),hsl(${hue},55%,58%))" aria-hidden="true">${letter}</span>`;
  }

  /**
   * Pobierz Top miesiąca z Supabase (anon SELECT).
   * Przy błędzie/offline: cache dysku, potem seed z oznaczeniem fallback.
   */
  async function pullRemote(month) {
    const m = month || monthKey();
    remoteState = {
      month: m,
      users: remoteState.month === m ? remoteState.users : [],
      source: 'loading',
      error: null,
      fetchedAt: remoteState.fetchedAt,
    };
    const client = getClient();
    if (!client) {
      return applyFallback(m, 'no-client');
    }
    try {
      const { data, error } = await client
        .from('user_activity_monthly')
        .select(
          'user_id,display_name,calc_runs,session_seconds,avatar_url,updated_at,month'
        )
        .eq('month', m)
        .limit(200);
      if (error) {
        return applyFallback(m, error.message || 'query-error');
      }
      const users = (data || []).map(mapRow);
      if (!users.length) {
        remoteState = {
          month: m,
          users: [],
          source: 'empty',
          error: null,
          fetchedAt: Date.now(),
        };
        return { ok: true, users: [], source: 'empty', month: m };
      }
      remoteState = {
        month: m,
        users,
        source: 'supabase',
        error: null,
        fetchedAt: Date.now(),
      };
      writeDiskCache(m, users);
      return { ok: true, users, source: 'supabase', month: m };
    } catch (e) {
      return applyFallback(m, e.message || String(e));
    }
  }

  function applyFallback(month, errMsg) {
    const disk = readDiskCache();
    if (disk && disk.month === month && disk.users.length) {
      remoteState = {
        month,
        users: disk.users,
        source: 'supabase',
        error: errMsg || null,
        fetchedAt: disk.savedAt || Date.now(),
      };
      return {
        ok: true,
        users: disk.users,
        source: 'supabase',
        cached: true,
        month,
        error: errMsg,
      };
    }
    const users = seedForMonth(month);
    remoteState = {
      month,
      users,
      source: 'fallback',
      error: errMsg || 'offline',
      fetchedAt: Date.now(),
    };
    return {
      ok: false,
      users,
      source: 'fallback',
      month,
      error: errMsg,
    };
  }

  /** Upsert własnego wiersza (authenticated). Preferuj krótki https avatar_url. */
  async function syncRemote(entry) {
    try {
      const client = getClient();
      if (!client) return { ok: false, skipped: true };
      const { data: sess } = await client.auth.getSession();
      const user = sess?.session?.user;
      if (!user) return { ok: false, skipped: true };
      const month = entry.month || monthKey();
      let hasAvatarKey =
        entry && Object.prototype.hasOwnProperty.call(entry, 'avatarUrl');
      let avatarUrl = hasAvatarKey ? entry.avatarUrl : undefined;
      if (typeof avatarUrl === 'string') {
        avatarUrl = avatarUrl.trim() || null;
        // ogromny data-URL blokuje upsert — pomiń pole zamiast kasować istniejący URL
        if (avatarUrl && /^data:/i.test(avatarUrl) && avatarUrl.length > 48000) {
          avatarUrl = undefined;
          hasAvatarKey = false;
        }
      }
      const row = {
        user_id: user.id,
        month,
        display_name: entry.displayName || user.email || 'user',
        calc_runs: Math.max(0, Number(entry.calcRuns) || 0),
        session_seconds: Math.max(0, Number(entry.sessionSeconds) || 0),
        updated_at: new Date().toISOString(),
      };
      if (hasAvatarKey && avatarUrl !== undefined) {
        row.avatar_url = avatarUrl;
      }
      const { error } = await client.from('user_activity_monthly').upsert(row, {
        onConflict: 'user_id,month',
      });
      if (error) {
        if (row.avatar_url) {
          const without = { ...row };
          delete without.avatar_url;
          const retry = await client
            .from('user_activity_monthly')
            .upsert(without, { onConflict: 'user_id,month' });
          if (retry.error) return { ok: false, error: retry.error.message };
          return { ok: true, avatarSkipped: true, error: error.message };
        }
        return { ok: false, error: error.message };
      }
      const mapped = mapRow({
        user_id: user.id,
        display_name: row.display_name,
        calc_runs: row.calc_runs,
        session_seconds: row.session_seconds,
        avatar_url:
          row.avatar_url !== undefined
            ? row.avatar_url
            : (remoteState.users.find((u) => u.userId === user.id) || {}).avatarUrl ||
              null,
        updated_at: row.updated_at,
        month,
      });
      if (remoteState.month === month && remoteState.source === 'supabase') {
        const idx = remoteState.users.findIndex((u) => u.userId === user.id);
        if (idx >= 0) remoteState.users[idx] = { ...remoteState.users[idx], ...mapped };
        else remoteState.users.push(mapped);
        writeDiskCache(month, remoteState.users);
      } else if (remoteState.month === month && remoteState.source === 'empty') {
        remoteState = {
          month,
          users: [mapped],
          source: 'supabase',
          error: null,
          fetchedAt: Date.now(),
        };
        writeDiskCache(month, remoteState.users);
      }
      return { ok: true, avatarUrl: mapped.avatarUrl };
    } catch (e) {
      return { ok: false, error: e.message || String(e) };
    }
  }

  // Session timer + okresowy upsert do Supabase
  let sessionTick = null;
  let sessionUserId = null;
  let sessionAccum = 0;
  let sessionStarted = 0;
  let sessionSyncRemote = false;

  function startSessionTracking(userId, getStats, opts) {
    stopSessionTracking(true);
    sessionUserId = userId;
    sessionStarted = Date.now();
    sessionAccum = 0;
    sessionSyncRemote = !!(opts && opts.syncRemote);
    const flush = () => {
      if (!sessionUserId) return;
      const stats = typeof getStats === 'function' ? getStats() : {};
      const elapsed = sessionAccum + Math.floor((Date.now() - sessionStarted) / 1000);
      const payload = {
        id: sessionUserId,
        displayName: stats.displayName || sessionUserId,
        calcRuns: stats.calcRuns || 0,
        sessionSeconds: Math.max(Number(stats.sessionSeconds) || 0, elapsed),
        avatarUrl: stats.avatarUrl !== undefined ? stats.avatarUrl : null,
        source: stats.source || 'local',
      };
      upsertLocal(payload);
      if (sessionSyncRemote) {
        syncRemote({
          displayName: payload.displayName,
          calcRuns: payload.calcRuns,
          sessionSeconds: payload.sessionSeconds,
          avatarUrl: payload.avatarUrl,
        });
      }
    };
    sessionTick = setInterval(flush, 30000);
    document.addEventListener('visibilitychange', onVis);
    window.addEventListener('beforeunload', onUnload);
    function onVis() {
      if (document.hidden) {
        sessionAccum += Math.floor((Date.now() - sessionStarted) / 1000);
        sessionStarted = Date.now();
        flush();
      } else {
        sessionStarted = Date.now();
      }
    }
    function onUnload() {
      flush();
    }
    startSessionTracking._onVis = onVis;
    startSessionTracking._onUnload = onUnload;
    startSessionTracking._flush = flush;
  }

  function stopSessionTracking(skipFlush) {
    if (sessionTick) clearInterval(sessionTick);
    sessionTick = null;
    if (startSessionTracking._onVis) {
      document.removeEventListener('visibilitychange', startSessionTracking._onVis);
    }
    if (startSessionTracking._onUnload) {
      window.removeEventListener('beforeunload', startSessionTracking._onUnload);
    }
    if (!skipFlush && startSessionTracking._flush) startSessionTracking._flush();
    sessionUserId = null;
    sessionSyncRemote = false;
  }

  function getSessionSecondsTracked() {
    if (!sessionUserId) return 0;
    return sessionAccum + Math.floor((Date.now() - sessionStarted) / 1000);
  }

  global.PaletyzatorLeaderboard = {
    monthKey,
    listMonth,
    rankingUsers,
    topBy,
    getSource,
    getState: () => ({ ...remoteState, users: remoteState.users.slice() }),
    calcPercentile,
    upsertLocal,
    syncRemote,
    pullRemote,
    formatDuration,
    trophySvg,
    avatarHtml,
    initialOf,
    startSessionTracking,
    stopSessionTracking,
    getSessionSecondsTracked,
    seedForMonth,
  };
})(typeof window !== 'undefined' ? window : globalThis);
