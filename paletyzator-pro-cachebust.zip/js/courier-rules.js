/**
 * Paletyzator Pro — limity palet kurierskich wg kraju docelowego.
 *
 * Założenia (orientacyjne, NIE cennik live):
 * - Jednostki: masa kg, wysokość całkowita palety z ładunkiem w cm (jak w kalkulatorze).
 * - Limity oparte o typowe publiczne parametry usług paletowych / freight 2024–2025
 *   (DHL Freight/eCommerce, UPS Express Freight, FedEx IP Freight, DPD Classic/MAX,
 *   GLS Freight partners, InPost Paleta, DB Schenker System/Direct). Rzeczywiste
 *   oferty zależą od umowy, strefy, ADR, stackability i terminalu — zawsze weryfikuj
 *   u kuriera przed nadaniem.
 * - Ceny (PLN): pasma „od” dla typowej relacji PL → kraj UE / świat, 1 euro-paleta
 *   120×80, bez paliwa/opłat paliwowych/celnych. Tylko do porównania w UI.
 * - Kraj: limity „country” = typowy sufit usług kurierskich dostępnych do tego ISO
 *   (nie przepisy drogowe naczepy). Brak usługi = country.served=false.
 * - Base L×W: gdy kurier wymaga euro (120×80) lub UK (120×100), sprawdzamy też
 *   podstawę palety z wyniku (r.L × r.W).
 */
(function (global) {
  'use strict';

  const ASSUMPTIONS =
    'Limity i ceny orientacyjne (PL origin). Weryfikuj u kuriera. Wysokość = całkowita (paleta+ładunek) w cm.';

  /** Regiony → ISO alpha-2 (do resolveCountries). */
  const REGIONS = {
    eu: [
      'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU',
      'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE',
    ],
    eea: [
      'AT', 'BE', 'BG', 'HR', 'CY', 'CZ', 'DK', 'EE', 'FI', 'FR', 'DE', 'GR', 'HU',
      'IE', 'IT', 'LV', 'LT', 'LU', 'MT', 'NL', 'PL', 'PT', 'RO', 'SK', 'SI', 'ES', 'SE',
      'IS', 'LI', 'NO',
    ],
    pl_neighbors: ['DE', 'CZ', 'SK', 'LT', 'UA', 'BY', 'RU', 'SE', 'DK'],
    uk_ie: ['GB', 'IE'],
    dach: ['DE', 'AT', 'CH'],
  };

  /**
   * ISO 3166-1 alpha-2 + etykiety PL (i krótkie EN/DE).
   * regionHint: eu | eea | other — domyślne limity krajowe.
   */
  const COUNTRIES = [
    { code: 'AF', pl: 'Afganistan', en: 'Afghanistan', de: 'Afghanistan', region: 'other' },
    { code: 'AL', pl: 'Albania', en: 'Albania', de: 'Albanien', region: 'other' },
    { code: 'DZ', pl: 'Algieria', en: 'Algeria', de: 'Algerien', region: 'other' },
    { code: 'AD', pl: 'Andora', en: 'Andorra', de: 'Andorra', region: 'other' },
    { code: 'AO', pl: 'Angola', en: 'Angola', de: 'Angola', region: 'other' },
    { code: 'AG', pl: 'Antigua i Barbuda', en: 'Antigua and Barbuda', de: 'Antigua und Barbuda', region: 'other' },
    { code: 'SA', pl: 'Arabia Saudyjska', en: 'Saudi Arabia', de: 'Saudi-Arabien', region: 'other' },
    { code: 'AR', pl: 'Argentyna', en: 'Argentina', de: 'Argentinien', region: 'other' },
    { code: 'AM', pl: 'Armenia', en: 'Armenia', de: 'Armenien', region: 'other' },
    { code: 'AU', pl: 'Australia', en: 'Australia', de: 'Australien', region: 'other' },
    { code: 'AT', pl: 'Austria', en: 'Austria', de: 'Österreich', region: 'eu' },
    { code: 'AZ', pl: 'Azerbejdżan', en: 'Azerbaijan', de: 'Aserbaidschan', region: 'other' },
    { code: 'BS', pl: 'Bahamy', en: 'Bahamas', de: 'Bahamas', region: 'other' },
    { code: 'BH', pl: 'Bahrajn', en: 'Bahrain', de: 'Bahrain', region: 'other' },
    { code: 'BD', pl: 'Bangladesz', en: 'Bangladesh', de: 'Bangladesch', region: 'other' },
    { code: 'BB', pl: 'Barbados', en: 'Barbados', de: 'Barbados', region: 'other' },
    { code: 'BE', pl: 'Belgia', en: 'Belgium', de: 'Belgien', region: 'eu' },
    { code: 'BZ', pl: 'Belize', en: 'Belize', de: 'Belize', region: 'other' },
    { code: 'BJ', pl: 'Benin', en: 'Benin', de: 'Benin', region: 'other' },
    { code: 'BT', pl: 'Bhutan', en: 'Bhutan', de: 'Bhutan', region: 'other' },
    { code: 'BY', pl: 'Białoruś', en: 'Belarus', de: 'Belarus', region: 'other' },
    { code: 'BO', pl: 'Boliwia', en: 'Bolivia', de: 'Bolivien', region: 'other' },
    { code: 'BA', pl: 'Bośnia i Hercegowina', en: 'Bosnia and Herzegovina', de: 'Bosnien und Herzegowina', region: 'other' },
    { code: 'BW', pl: 'Botswana', en: 'Botswana', de: 'Botswana', region: 'other' },
    { code: 'BR', pl: 'Brazylia', en: 'Brazil', de: 'Brasilien', region: 'other' },
    { code: 'BN', pl: 'Brunei', en: 'Brunei', de: 'Brunei', region: 'other' },
    { code: 'BG', pl: 'Bułgaria', en: 'Bulgaria', de: 'Bulgarien', region: 'eu' },
    { code: 'BF', pl: 'Burkina Faso', en: 'Burkina Faso', de: 'Burkina Faso', region: 'other' },
    { code: 'BI', pl: 'Burundi', en: 'Burundi', de: 'Burundi', region: 'other' },
    { code: 'CL', pl: 'Chile', en: 'Chile', de: 'Chile', region: 'other' },
    { code: 'CN', pl: 'Chiny', en: 'China', de: 'China', region: 'other' },
    { code: 'HR', pl: 'Chorwacja', en: 'Croatia', de: 'Kroatien', region: 'eu' },
    { code: 'CY', pl: 'Cypr', en: 'Cyprus', de: 'Zypern', region: 'eu' },
    { code: 'TD', pl: 'Czad', en: 'Chad', de: 'Tschad', region: 'other' },
    { code: 'ME', pl: 'Czarnogóra', en: 'Montenegro', de: 'Montenegro', region: 'other' },
    { code: 'CZ', pl: 'Czechy', en: 'Czechia', de: 'Tschechien', region: 'eu' },
    { code: 'DK', pl: 'Dania', en: 'Denmark', de: 'Dänemark', region: 'eu' },
    { code: 'CD', pl: 'Demokratyczna Republika Konga', en: 'DR Congo', de: 'Demokratische Republik Kongo', region: 'other' },
    { code: 'DM', pl: 'Dominika', en: 'Dominica', de: 'Dominica', region: 'other' },
    { code: 'DO', pl: 'Dominikana', en: 'Dominican Republic', de: 'Dominikanische Republik', region: 'other' },
    { code: 'DJ', pl: 'Dżibuti', en: 'Djibouti', de: 'Dschibuti', region: 'other' },
    { code: 'EG', pl: 'Egipt', en: 'Egypt', de: 'Ägypten', region: 'other' },
    { code: 'EC', pl: 'Ekwador', en: 'Ecuador', de: 'Ecuador', region: 'other' },
    { code: 'ER', pl: 'Erytrea', en: 'Eritrea', de: 'Eritrea', region: 'other' },
    { code: 'EE', pl: 'Estonia', en: 'Estonia', de: 'Estland', region: 'eu' },
    { code: 'SZ', pl: 'Eswatini', en: 'Eswatini', de: 'Eswatini', region: 'other' },
    { code: 'ET', pl: 'Etiopia', en: 'Ethiopia', de: 'Äthiopien', region: 'other' },
    { code: 'FJ', pl: 'Fidżi', en: 'Fiji', de: 'Fidschi', region: 'other' },
    { code: 'PH', pl: 'Filipiny', en: 'Philippines', de: 'Philippinen', region: 'other' },
    { code: 'FI', pl: 'Finlandia', en: 'Finland', de: 'Finnland', region: 'eu' },
    { code: 'FR', pl: 'Francja', en: 'France', de: 'Frankreich', region: 'eu' },
    { code: 'GA', pl: 'Gabon', en: 'Gabon', de: 'Gabun', region: 'other' },
    { code: 'GM', pl: 'Gambia', en: 'Gambia', de: 'Gambia', region: 'other' },
    { code: 'GH', pl: 'Ghana', en: 'Ghana', de: 'Ghana', region: 'other' },
    { code: 'GR', pl: 'Grecja', en: 'Greece', de: 'Griechenland', region: 'eu' },
    { code: 'GD', pl: 'Grenada', en: 'Grenada', de: 'Grenada', region: 'other' },
    { code: 'GE', pl: 'Gruzja', en: 'Georgia', de: 'Georgien', region: 'other' },
    { code: 'GY', pl: 'Gujana', en: 'Guyana', de: 'Guyana', region: 'other' },
    { code: 'GT', pl: 'Gwatemala', en: 'Guatemala', de: 'Guatemala', region: 'other' },
    { code: 'GN', pl: 'Gwinea', en: 'Guinea', de: 'Guinea', region: 'other' },
    { code: 'GW', pl: 'Gwinea Bissau', en: 'Guinea-Bissau', de: 'Guinea-Bissau', region: 'other' },
    { code: 'GQ', pl: 'Gwinea Równikowa', en: 'Equatorial Guinea', de: 'Äquatorialguinea', region: 'other' },
    { code: 'HT', pl: 'Haiti', en: 'Haiti', de: 'Haiti', region: 'other' },
    { code: 'ES', pl: 'Hiszpania', en: 'Spain', de: 'Spanien', region: 'eu' },
    { code: 'NL', pl: 'Holandia', en: 'Netherlands', de: 'Niederlande', region: 'eu' },
    { code: 'HN', pl: 'Honduras', en: 'Honduras', de: 'Honduras', region: 'other' },
    { code: 'HK', pl: 'Hongkong', en: 'Hong Kong', de: 'Hongkong', region: 'other' },
    { code: 'IN', pl: 'Indie', en: 'India', de: 'Indien', region: 'other' },
    { code: 'ID', pl: 'Indonezja', en: 'Indonesia', de: 'Indonesien', region: 'other' },
    { code: 'IQ', pl: 'Irak', en: 'Iraq', de: 'Irak', region: 'other' },
    { code: 'IR', pl: 'Iran', en: 'Iran', de: 'Iran', region: 'other' },
    { code: 'IE', pl: 'Irlandia', en: 'Ireland', de: 'Irland', region: 'eu' },
    { code: 'IS', pl: 'Islandia', en: 'Iceland', de: 'Island', region: 'eea' },
    { code: 'IL', pl: 'Izrael', en: 'Israel', de: 'Israel', region: 'other' },
    { code: 'JM', pl: 'Jamajka', en: 'Jamaica', de: 'Jamaika', region: 'other' },
    { code: 'JP', pl: 'Japonia', en: 'Japan', de: 'Japan', region: 'other' },
    { code: 'YE', pl: 'Jemen', en: 'Yemen', de: 'Jemen', region: 'other' },
    { code: 'JO', pl: 'Jordania', en: 'Jordan', de: 'Jordanien', region: 'other' },
    { code: 'KH', pl: 'Kambodża', en: 'Cambodia', de: 'Kambodscha', region: 'other' },
    { code: 'CM', pl: 'Kamerun', en: 'Cameroon', de: 'Kamerun', region: 'other' },
    { code: 'CA', pl: 'Kanada', en: 'Canada', de: 'Kanada', region: 'other' },
    { code: 'QA', pl: 'Katar', en: 'Qatar', de: 'Katar', region: 'other' },
    { code: 'KZ', pl: 'Kazachstan', en: 'Kazakhstan', de: 'Kasachstan', region: 'other' },
    { code: 'KE', pl: 'Kenia', en: 'Kenya', de: 'Kenia', region: 'other' },
    { code: 'KG', pl: 'Kirgistan', en: 'Kyrgyzstan', de: 'Kirgisistan', region: 'other' },
    { code: 'KI', pl: 'Kiribati', en: 'Kiribati', de: 'Kiribati', region: 'other' },
    { code: 'CO', pl: 'Kolumbia', en: 'Colombia', de: 'Kolumbien', region: 'other' },
    { code: 'KM', pl: 'Komory', en: 'Comoros', de: 'Komoren', region: 'other' },
    { code: 'CG', pl: 'Kongo', en: 'Congo', de: 'Kongo', region: 'other' },
    { code: 'KR', pl: 'Korea Południowa', en: 'South Korea', de: 'Südkorea', region: 'other' },
    { code: 'KP', pl: 'Korea Północna', en: 'North Korea', de: 'Nordkorea', region: 'other' },
    { code: 'CR', pl: 'Kostaryka', en: 'Costa Rica', de: 'Costa Rica', region: 'other' },
    { code: 'CU', pl: 'Kuba', en: 'Cuba', de: 'Kuba', region: 'other' },
    { code: 'KW', pl: 'Kuwejt', en: 'Kuwait', de: 'Kuwait', region: 'other' },
    { code: 'LA', pl: 'Laos', en: 'Laos', de: 'Laos', region: 'other' },
    { code: 'LS', pl: 'Lesotho', en: 'Lesotho', de: 'Lesotho', region: 'other' },
    { code: 'LB', pl: 'Liban', en: 'Lebanon', de: 'Libanon', region: 'other' },
    { code: 'LR', pl: 'Liberia', en: 'Liberia', de: 'Liberia', region: 'other' },
    { code: 'LY', pl: 'Libia', en: 'Libya', de: 'Libyen', region: 'other' },
    { code: 'LI', pl: 'Liechtenstein', en: 'Liechtenstein', de: 'Liechtenstein', region: 'eea' },
    { code: 'LT', pl: 'Litwa', en: 'Lithuania', de: 'Litauen', region: 'eu' },
    { code: 'LU', pl: 'Luksemburg', en: 'Luxembourg', de: 'Luxemburg', region: 'eu' },
    { code: 'LV', pl: 'Łotwa', en: 'Latvia', de: 'Lettland', region: 'eu' },
    { code: 'MK', pl: 'Macedonia Północna', en: 'North Macedonia', de: 'Nordmazedonien', region: 'other' },
    { code: 'MG', pl: 'Madagaskar', en: 'Madagascar', de: 'Madagaskar', region: 'other' },
    { code: 'MW', pl: 'Malawi', en: 'Malawi', de: 'Malawi', region: 'other' },
    { code: 'MV', pl: 'Malediwy', en: 'Maldives', de: 'Malediven', region: 'other' },
    { code: 'MY', pl: 'Malezja', en: 'Malaysia', de: 'Malaysia', region: 'other' },
    { code: 'ML', pl: 'Mali', en: 'Mali', de: 'Mali', region: 'other' },
    { code: 'MT', pl: 'Malta', en: 'Malta', de: 'Malta', region: 'eu' },
    { code: 'MA', pl: 'Maroko', en: 'Morocco', de: 'Marokko', region: 'other' },
    { code: 'MR', pl: 'Mauretania', en: 'Mauritania', de: 'Mauretanien', region: 'other' },
    { code: 'MU', pl: 'Mauritius', en: 'Mauritius', de: 'Mauritius', region: 'other' },
    { code: 'MX', pl: 'Meksyk', en: 'Mexico', de: 'Mexiko', region: 'other' },
    { code: 'FM', pl: 'Mikronezja', en: 'Micronesia', de: 'Mikronesien', region: 'other' },
    { code: 'MM', pl: 'Mjanma', en: 'Myanmar', de: 'Myanmar', region: 'other' },
    { code: 'MD', pl: 'Mołdawia', en: 'Moldova', de: 'Moldau', region: 'other' },
    { code: 'MC', pl: 'Monako', en: 'Monaco', de: 'Monaco', region: 'other' },
    { code: 'MN', pl: 'Mongolia', en: 'Mongolia', de: 'Mongolei', region: 'other' },
    { code: 'MZ', pl: 'Mozambik', en: 'Mozambique', de: 'Mosambik', region: 'other' },
    { code: 'NA', pl: 'Namibia', en: 'Namibia', de: 'Namibia', region: 'other' },
    { code: 'NR', pl: 'Nauru', en: 'Nauru', de: 'Nauru', region: 'other' },
    { code: 'NP', pl: 'Nepal', en: 'Nepal', de: 'Nepal', region: 'other' },
    { code: 'DE', pl: 'Niemcy', en: 'Germany', de: 'Deutschland', region: 'eu' },
    { code: 'NE', pl: 'Niger', en: 'Niger', de: 'Niger', region: 'other' },
    { code: 'NG', pl: 'Nigeria', en: 'Nigeria', de: 'Nigeria', region: 'other' },
    { code: 'NI', pl: 'Nikaragua', en: 'Nicaragua', de: 'Nicaragua', region: 'other' },
    { code: 'NO', pl: 'Norwegia', en: 'Norway', de: 'Norwegen', region: 'eea' },
    { code: 'NZ', pl: 'Nowa Zelandia', en: 'New Zealand', de: 'Neuseeland', region: 'other' },
    { code: 'OM', pl: 'Oman', en: 'Oman', de: 'Oman', region: 'other' },
    { code: 'PK', pl: 'Pakistan', en: 'Pakistan', de: 'Pakistan', region: 'other' },
    { code: 'PW', pl: 'Palau', en: 'Palau', de: 'Palau', region: 'other' },
    { code: 'PA', pl: 'Panama', en: 'Panama', de: 'Panama', region: 'other' },
    { code: 'PG', pl: 'Papua-Nowa Gwinea', en: 'Papua New Guinea', de: 'Papua-Neuguinea', region: 'other' },
    { code: 'PY', pl: 'Paragwaj', en: 'Paraguay', de: 'Paraguay', region: 'other' },
    { code: 'PE', pl: 'Peru', en: 'Peru', de: 'Peru', region: 'other' },
    { code: 'PL', pl: 'Polska', en: 'Poland', de: 'Polen', region: 'eu' },
    { code: 'PT', pl: 'Portugalia', en: 'Portugal', de: 'Portugal', region: 'eu' },
    { code: 'ZA', pl: 'Republika Południowej Afryki', en: 'South Africa', de: 'Südafrika', region: 'other' },
    { code: 'CF', pl: 'Republika Środkowoafrykańska', en: 'Central African Republic', de: 'Zentralafrikanische Republik', region: 'other' },
    { code: 'CV', pl: 'Republika Zielonego Przylądka', en: 'Cabo Verde', de: 'Cabo Verde', region: 'other' },
    { code: 'RU', pl: 'Rosja', en: 'Russia', de: 'Russland', region: 'other' },
    { code: 'RO', pl: 'Rumunia', en: 'Romania', de: 'Rumänien', region: 'eu' },
    { code: 'RW', pl: 'Rwanda', en: 'Rwanda', de: 'Ruanda', region: 'other' },
    { code: 'KN', pl: 'Saint Kitts i Nevis', en: 'Saint Kitts and Nevis', de: 'St. Kitts und Nevis', region: 'other' },
    { code: 'LC', pl: 'Saint Lucia', en: 'Saint Lucia', de: 'St. Lucia', region: 'other' },
    { code: 'VC', pl: 'Saint Vincent i Grenadyny', en: 'Saint Vincent and the Grenadines', de: 'St. Vincent und die Grenadinen', region: 'other' },
    { code: 'SV', pl: 'Salwador', en: 'El Salvador', de: 'El Salvador', region: 'other' },
    { code: 'WS', pl: 'Samoa', en: 'Samoa', de: 'Samoa', region: 'other' },
    { code: 'SM', pl: 'San Marino', en: 'San Marino', de: 'San Marino', region: 'other' },
    { code: 'SN', pl: 'Senegal', en: 'Senegal', de: 'Senegal', region: 'other' },
    { code: 'RS', pl: 'Serbia', en: 'Serbia', de: 'Serbien', region: 'other' },
    { code: 'SC', pl: 'Seszele', en: 'Seychelles', de: 'Seychellen', region: 'other' },
    { code: 'SL', pl: 'Sierra Leone', en: 'Sierra Leone', de: 'Sierra Leone', region: 'other' },
    { code: 'SG', pl: 'Singapur', en: 'Singapore', de: 'Singapur', region: 'other' },
    { code: 'SK', pl: 'Słowacja', en: 'Slovakia', de: 'Slowakei', region: 'eu' },
    { code: 'SI', pl: 'Słowenia', en: 'Slovenia', de: 'Slowenien', region: 'eu' },
    { code: 'SO', pl: 'Somalia', en: 'Somalia', de: 'Somalia', region: 'other' },
    { code: 'LK', pl: 'Sri Lanka', en: 'Sri Lanka', de: 'Sri Lanka', region: 'other' },
    { code: 'US', pl: 'Stany Zjednoczone', en: 'United States', de: 'Vereinigte Staaten', region: 'other' },
    { code: 'SD', pl: 'Sudan', en: 'Sudan', de: 'Sudan', region: 'other' },
    { code: 'SS', pl: 'Sudan Południowy', en: 'South Sudan', de: 'Südsudan', region: 'other' },
    { code: 'SR', pl: 'Surinam', en: 'Suriname', de: 'Suriname', region: 'other' },
    { code: 'SY', pl: 'Syria', en: 'Syria', de: 'Syrien', region: 'other' },
    { code: 'CH', pl: 'Szwajcaria', en: 'Switzerland', de: 'Schweiz', region: 'other' },
    { code: 'SE', pl: 'Szwecja', en: 'Sweden', de: 'Schweden', region: 'eu' },
    { code: 'TJ', pl: 'Tadżykistan', en: 'Tajikistan', de: 'Tadschikistan', region: 'other' },
    { code: 'TH', pl: 'Tajlandia', en: 'Thailand', de: 'Thailand', region: 'other' },
    { code: 'TZ', pl: 'Tanzania', en: 'Tanzania', de: 'Tansania', region: 'other' },
    { code: 'TL', pl: 'Timor Wschodni', en: 'Timor-Leste', de: 'Osttimor', region: 'other' },
    { code: 'TG', pl: 'Togo', en: 'Togo', de: 'Togo', region: 'other' },
    { code: 'TO', pl: 'Tonga', en: 'Tonga', de: 'Tonga', region: 'other' },
    { code: 'TT', pl: 'Trynidad i Tobago', en: 'Trinidad and Tobago', de: 'Trinidad und Tobago', region: 'other' },
    { code: 'TN', pl: 'Tunezja', en: 'Tunisia', de: 'Tunesien', region: 'other' },
    { code: 'TR', pl: 'Turcja', en: 'Türkiye', de: 'Türkei', region: 'other' },
    { code: 'TM', pl: 'Turkmenistan', en: 'Turkmenistan', de: 'Turkmenistan', region: 'other' },
    { code: 'TV', pl: 'Tuvalu', en: 'Tuvalu', de: 'Tuvalu', region: 'other' },
    { code: 'UG', pl: 'Uganda', en: 'Uganda', de: 'Uganda', region: 'other' },
    { code: 'UA', pl: 'Ukraina', en: 'Ukraine', de: 'Ukraine', region: 'other' },
    { code: 'UY', pl: 'Urugwaj', en: 'Uruguay', de: 'Uruguay', region: 'other' },
    { code: 'UZ', pl: 'Uzbekistan', en: 'Uzbekistan', de: 'Usbekistan', region: 'other' },
    { code: 'VU', pl: 'Vanuatu', en: 'Vanuatu', de: 'Vanuatu', region: 'other' },
    { code: 'VA', pl: 'Watykan', en: 'Vatican City', de: 'Vatikanstadt', region: 'other' },
    { code: 'VE', pl: 'Wenezuela', en: 'Venezuela', de: 'Venezuela', region: 'other' },
    { code: 'HU', pl: 'Węgry', en: 'Hungary', de: 'Ungarn', region: 'eu' },
    { code: 'GB', pl: 'Wielka Brytania', en: 'United Kingdom', de: 'Vereinigtes Königreich', region: 'other' },
    { code: 'VN', pl: 'Wietnam', en: 'Vietnam', de: 'Vietnam', region: 'other' },
    { code: 'IT', pl: 'Włochy', en: 'Italy', de: 'Italien', region: 'eu' },
    { code: 'CI', pl: 'Wybrzeże Kości Słoniowej', en: "Côte d'Ivoire", de: 'Elfenbeinküste', region: 'other' },
    { code: 'BV', pl: 'Wyspa Bouveta', en: 'Bouvet Island', de: 'Bouvetinsel', region: 'other' },
    { code: 'CX', pl: 'Wyspa Bożego Narodzenia', en: 'Christmas Island', de: 'Weihnachtsinsel', region: 'other' },
    { code: 'NF', pl: 'Wyspa Norfolk', en: 'Norfolk Island', de: 'Norfolkinsel', region: 'other' },
    { code: 'SB', pl: 'Wyspy Salomona', en: 'Solomon Islands', de: 'Salomonen', region: 'other' },
    { code: 'ST', pl: 'Wyspy Świętego Tomasza i Książęca', en: 'Sao Tome and Principe', de: 'São Tomé und Príncipe', region: 'other' },
    { code: 'ZM', pl: 'Zambia', en: 'Zambia', de: 'Sambia', region: 'other' },
    { code: 'ZW', pl: 'Zimbabwe', en: 'Zimbabwe', de: 'Simbabwe', region: 'other' },
    { code: 'AE', pl: 'Zjednoczone Emiraty Arabskie', en: 'United Arab Emirates', de: 'Vereinigte Arabische Emirate', region: 'other' },
  ];

  /** Domyślne limity „krajowe” (sufit typowej usługi kurierskiej). */
  const REGION_DEFAULTS = {
    eu: { maxWeightKg: 1000, maxHeightCm: 220 },
    eea: { maxWeightKg: 1000, maxHeightCm: 220 },
    other: { maxWeightKg: 500, maxHeightCm: 160 },
  };

  /**
   * Kurierzy. countries: '*' | region key | ISO[]
   * pricingBands: orientacyjne PLN „od” (PL origin).
   */
  const COURIERS = [
    {
      id: 'inpost-paleta',
      name: 'InPost Paleta',
      maxWeightKg: 700,
      maxHeightCm: 180,
      maxLCm: 120,
      maxWCm: 80,
      countries: [
        'PL', 'DE', 'CZ', 'SK', 'LT', 'LV', 'EE', 'AT', 'BE', 'NL', 'LU', 'FR', 'IT',
        'ES', 'PT', 'HU', 'RO', 'BG', 'HR', 'SI', 'SE', 'DK', 'FI', 'IE', 'GB',
      ],
      pricingBands: [
        { label: '0–200 kg', priceFromPln: 89 },
        { label: '201–400 kg', priceFromPln: 129 },
        { label: '401–700 kg', priceFromPln: 179 },
      ],
      notePl: 'Głównie euro-paleta 120×80; wysokość do 180 cm łącznie.',
    },
    {
      id: 'dpd-pallet',
      name: 'DPD (paleta / MAX)',
      maxWeightKg: 700,
      maxHeightCm: 180,
      maxLCm: 120,
      maxWCm: 80,
      countries: 'eea',
      pricingBands: [
        { label: '0–200 kg', priceFromPln: 95 },
        { label: '201–400 kg', priceFromPln: 145 },
        { label: '401–700 kg', priceFromPln: 210 },
      ],
      notePl: 'Zasięg głównie EOG; limity zależą od produktu krajowego DPD.',
    },
    {
      id: 'gls-freight',
      name: 'GLS (Business Parcel / Freight)',
      maxWeightKg: 1000,
      maxHeightCm: 200,
      countries: 'eea',
      pricingBands: [
        { label: '0–200 kg', priceFromPln: 110 },
        { label: '201–500 kg', priceFromPln: 175 },
        { label: '501–1000 kg', priceFromPln: 260 },
      ],
      notePl: 'Usługi freight często przez partnerów GLS; sprawdź lokalną ofertę.',
    },
    {
      id: 'dhl-freight',
      name: 'DHL Freight / Eurapid',
      maxWeightKg: 1000,
      maxHeightCm: 220,
      countries: 'eea',
      pricingBands: [
        { label: '0–300 kg', priceFromPln: 140 },
        { label: '301–600 kg', priceFromPln: 220 },
        { label: '601–1000 kg', priceFromPln: 320 },
      ],
      notePl: 'Typowy LTL/groupage UE; wysokość do ~220 cm w wielu produktach.',
    },
    {
      id: 'dhl-express-pallet',
      name: 'DHL Express (Time Definite)',
      maxWeightKg: 300,
      maxHeightCm: 160,
      countries: '*',
      pricingBands: [
        { label: '0–70 kg', priceFromPln: 280 },
        { label: '71–150 kg', priceFromPln: 450 },
        { label: '151–300 kg', priceFromPln: 780 },
      ],
      notePl: 'Express światowy — niższe limity wysokości/masy niż Freight.',
    },
    {
      id: 'ups-freight',
      name: 'UPS Express Freight',
      maxWeightKg: 450,
      maxHeightCm: 178,
      countries: '*',
      pricingBands: [
        { label: '0–70 kg', priceFromPln: 260 },
        { label: '71–150 kg', priceFromPln: 420 },
        { label: '151–450 kg', priceFromPln: 720 },
      ],
      notePl: 'Express Freight; poza tym UPS Standard UE ma inne limity paczek.',
    },
    {
      id: 'fedex-ipf',
      name: 'FedEx International Priority Freight',
      maxWeightKg: 450,
      maxHeightCm: 178,
      countries: '*',
      pricingBands: [
        { label: '0–70 kg', priceFromPln: 270 },
        { label: '71–150 kg', priceFromPln: 440 },
        { label: '151–450 kg', priceFromPln: 750 },
      ],
      notePl: 'IP Freight — typowe limity ~178 cm / ~450 kg na paletę.',
    },
    {
      id: 'db-schenker',
      name: 'DB Schenker (System / Direct)',
      maxWeightKg: 1500,
      maxHeightCm: 250,
      countries: '*',
      pricingBands: [
        { label: '0–400 kg', priceFromPln: 160 },
        { label: '401–800 kg', priceFromPln: 280 },
        { label: '801–1500 kg', priceFromPln: 420 },
      ],
      notePl: 'Najszerszy zasięg LTL/FTL; limity zależą od produktu System vs Direct.',
    },
    {
      id: 'raben',
      name: 'Raben (groupage UE)',
      maxWeightKg: 1200,
      maxHeightCm: 220,
      countries: 'eu',
      pricingBands: [
        { label: '0–300 kg', priceFromPln: 120 },
        { label: '301–700 kg', priceFromPln: 200 },
        { label: '701–1200 kg', priceFromPln: 310 },
      ],
      notePl: 'Sieć groupage CEE/UE; popularna z PL.',
    },
    {
      id: 'geis',
      name: 'Geis (paleta / LTL)',
      maxWeightKg: 1000,
      maxHeightCm: 220,
      countries: ['PL', 'DE', 'CZ', 'SK', 'AT', 'HU', 'RO', 'BG', 'SI', 'HR', 'LT', 'LV', 'EE'],
      pricingBands: [
        { label: '0–300 kg', priceFromPln: 115 },
        { label: '301–600 kg', priceFromPln: 190 },
        { label: '601–1000 kg', priceFromPln: 290 },
      ],
      notePl: 'Silna obecność CEE; zasięg poza listą przez partnerów.',
    },
  ];

  const STORAGE_KEY = 'pp_dest_country';
  const EPS = 0.05;

  function countryLabel(c, locale) {
    if (!c) return '';
    if (locale === 'en') return c.en || c.pl;
    if (locale === 'de') return c.de || c.en || c.pl;
    return c.pl;
  }

  function getCountries(locale) {
    const loc = locale || (global.I18n && global.I18n.getLocale && global.I18n.getLocale()) || 'pl';
    return COUNTRIES.map((c) => ({
      code: c.code,
      name: countryLabel(c, loc),
      region: c.region,
      search: `${c.code} ${c.pl} ${c.en} ${c.de}`.toLowerCase(),
    })).sort((a, b) => a.name.localeCompare(b.name, loc === 'de' ? 'de' : loc === 'en' ? 'en' : 'pl'));
  }

  function findCountry(code) {
    const cc = String(code || '').toUpperCase();
    return COUNTRIES.find((c) => c.code === cc) || null;
  }

  function resolveCountrySet(spec) {
    if (spec === '*') return null; // all
    if (typeof spec === 'string' && REGIONS[spec]) {
      return new Set(REGIONS[spec]);
    }
    if (Array.isArray(spec)) return new Set(spec.map((x) => String(x).toUpperCase()));
    return new Set();
  }

  function courierServes(courier, countryCode) {
    const set = resolveCountrySet(courier.countries);
    if (set === null) return true;
    return set.has(String(countryCode).toUpperCase());
  }

  function countryLimits(country) {
    const def = REGION_DEFAULTS[country?.region] || REGION_DEFAULTS.other;
    return {
      maxWeightKg: def.maxWeightKg,
      maxHeightCm: def.maxHeightCm,
    };
  }

  function checkDims(limits, pallet) {
    const fails = [];
    const h = Number(pallet.heightCm);
    const w = Number(pallet.weightKg);
    const L = Number(pallet.L);
    const W = Number(pallet.W);

    if (limits.maxHeightCm != null && h > limits.maxHeightCm + EPS) fails.push('height');
    if (limits.maxWeightKg != null && w > limits.maxWeightKg + EPS) fails.push('weight');
    if (limits.maxLCm != null && limits.maxWCm != null && Number.isFinite(L) && Number.isFinite(W)) {
      const okEuro =
        (L <= limits.maxLCm + EPS && W <= limits.maxWCm + EPS) ||
        (W <= limits.maxLCm + EPS && L <= limits.maxWCm + EPS);
      if (!okEuro) fails.push('base');
    }
    return fails;
  }

  function priceForWeight(bands, weightKg) {
    if (!bands || !bands.length) return null;
    const w = Number(weightKg) || 0;
    // pick first band whose upper bound (parsed) covers weight, else last
    for (const b of bands) {
      const m = String(b.label).match(/(\d+)\s*[–-]\s*(\d+)/);
      if (m) {
        const hi = Number(m[2]);
        if (w <= hi + EPS) return b;
      }
    }
    return bands[bands.length - 1];
  }

  /**
   * @param {string} countryCode
   * @param {{ heightCm:number, weightKg:number, L?:number, W?:number }} pallet
   */
  function evaluate(countryCode, pallet) {
    const country = findCountry(countryCode);
    if (!country) {
      return {
        ok: false,
        country: null,
        limits: null,
        fails: ['country'],
        couriers: [],
        eligibleCount: 0,
        assumptions: ASSUMPTIONS,
      };
    }

    const limits = countryLimits(country);
    const countryFails = checkDims(limits, pallet);
    const serving = COURIERS.filter((c) => courierServes(c, country.code));

    const couriers = COURIERS.map((c) => {
      const serves = courierServes(c, country.code);
      const fails = [];
      if (!serves) fails.push('country');
      else fails.push(...checkDims(c, pallet));
      const band = priceForWeight(c.pricingBands, pallet.weightKg);
      return {
        id: c.id,
        name: c.name,
        maxWeightKg: c.maxWeightKg,
        maxHeightCm: c.maxHeightCm,
        maxLCm: c.maxLCm ?? null,
        maxWCm: c.maxWCm ?? null,
        pricingBands: c.pricingBands,
        priceBand: band,
        notePl: c.notePl || '',
        serves,
        ok: serves && fails.length === 0,
        fails,
      };
    }).sort((a, b) => {
      if (a.ok !== b.ok) return a.ok ? -1 : 1;
      if (a.serves !== b.serves) return a.serves ? -1 : 1;
      return a.name.localeCompare(b.name, 'pl');
    });

    const eligible = couriers.filter((c) => c.ok);
    // Kraj „spełnia” gdy ≥1 kurier obsługujący destynację przyjmie paletę.
    // Limity regionalne (limits / countryFails) to tylko kontekst porównawczy.
    const ok = eligible.length > 0;
    const verdictFails = ok
      ? []
      : countryFails.length
        ? countryFails
        : Array.from(
            new Set(
              couriers
                .filter((c) => c.serves)
                .flatMap((c) => c.fails.filter((f) => f !== 'country'))
            )
          );

    return {
      ok,
      country,
      limits,
      fails: verdictFails,
      regionFails: countryFails,
      couriers,
      servingCount: serving.length,
      eligibleCount: eligible.length,
      assumptions: ASSUMPTIONS,
    };
  }

  function getSavedCountry() {
    try {
      return localStorage.getItem(STORAGE_KEY) || 'PL';
    } catch (_) {
      return 'PL';
    }
  }

  function saveCountry(code) {
    try {
      localStorage.setItem(STORAGE_KEY, String(code || 'PL').toUpperCase());
    } catch (_) { /* ignore */ }
  }

  global.PaletyzatorCourierRules = {
    ASSUMPTIONS,
    STORAGE_KEY,
    getCountries,
    findCountry,
    countryLabel,
    evaluate,
    getSavedCountry,
    saveCountry,
    COURIERS,
    COUNTRIES,
  };
})(typeof window !== 'undefined' ? window : globalThis);
