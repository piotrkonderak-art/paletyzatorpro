/**
 * Paletyzator Pro — abonamenty + kody próbne.
 *
 * BEZPIECZEŃSTWO: płatne / trial / promo entitlements NIE pochodzą z localStorage ani
 * z publicznego setPlan. Źródło prawdy = tabela Supabase `subscriptions`
 * (zapis: stripe-webhook / redeem-trial-code / ensure_promo_business RPC / service role).
 * Cache w sessionStorage jest tylko odzwierciedleniem ostatniego syncu serwera
 * i jest wiązany z user_id — ręczna edycja nie odblokuje funkcji po syncu.
 *
 * Promo (tymczasowo): po udanym syncu zalogowanego usera, brak aktywnej subskrypcji
 * → RPC ensure_promo_business (Business, source=promo, bez końca). setSubscription
 * nadal no-op.
 */
(function (global) {
  'use strict';

  const CODES_KEY = 'pp_trial_codes_v1'; // lokalny podgląd admina (UI); autorytatywne = trial_codes
  const SUB_UI_KEY = 'pp_subscription_ui_v1'; // tylko etykiety UI, NIE gate funkcji
  const ENTITLEMENT_KEY = 'pp_entitlement_v2';
  const TRIAL_DAYS = 7;
  const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const CACHE_MAX_AGE_MS = 6 * 60 * 60 * 1000;

  let _adminActorEmail = '';
  /** @type {null | { userId: string, tier: string, source: string, status?: string, trialEndsAt?: number|null, currentPeriodEnd?: number|null, stripeCustomerId?: string|null, stripeSubscriptionId?: string|null, stripePriceId?: string|null, syncedAt: number }} */
  let _entitlement = null;

  /**
   * Tier matrix (Stripe test: 1 / 2 / 3 PLN):
   * Starter — mix calc + live alerts (light: height/weight/partial; no courier).
   * Pro — 3D, CSV/Excel import, packing variants, country/courier, PDF offer.
   * Business — CMR, VIES, full limits, all exports.
   */
  const TIERS = {
    starter: {
      id: 'starter',
      rank: 1,
      maxSkuRows: 5,
      maxProducts: 10,
      features: {
        mixCalc: true,
        resultTable: true,
        liveAlerts: true,
        viewer3d: false,
        cmr: false,
        vies: false,
        singleCalc: false,
        skuBaseWrite: true,
        history: true,
        exportData: false,
        offerPdf: false,
        skuImport: false,
        packingVariants: false,
        courierChecks: false,
        tolerance: false,
      },
    },
    pro: {
      id: 'pro',
      rank: 2,
      maxSkuRows: 20,
      maxProducts: 200,
      features: {
        mixCalc: true,
        resultTable: true,
        liveAlerts: true,
        viewer3d: true,
        cmr: false,
        vies: false,
        singleCalc: true,
        skuBaseWrite: true,
        history: true,
        exportData: true,
        offerPdf: true,
        skuImport: true,
        packingVariants: true,
        courierChecks: true,
        tolerance: true,
      },
    },
    business: {
      id: 'business',
      rank: 3,
      maxSkuRows: 40,
      maxProducts: 5000,
      features: {
        mixCalc: true,
        resultTable: true,
        liveAlerts: true,
        viewer3d: true,
        cmr: true,
        vies: true,
        singleCalc: true,
        skuBaseWrite: true,
        history: true,
        exportData: true,
        offerPdf: true,
        skuImport: true,
        packingVariants: true,
        courierChecks: true,
        tolerance: true,
      },
    },
  };

  const HIGHEST = 'business';

  function t(key, vars) {
    if (global.I18n && typeof global.I18n.t === 'function') {
      return global.I18n.t(key, vars);
    }
    return key;
  }

  function isClientBuild() {
    const c = global.PALETYZATOR_CONFIG || {};
    return c.clientBuild === true || c.clientBuild === 'true' || c.clientBuild === 1;
  }

  function ownerEmails() {
    if (isClientBuild()) return [];
    const c = global.PALETYZATOR_CONFIG || {};
    const raw = c.ownerEmails;
    if (Array.isArray(raw)) {
      return raw
        .map((e) => String(e || '').trim().toLowerCase())
        .filter((e) => e.includes('@'));
    }
    if (c.ownerEmail) {
      const one = String(c.ownerEmail || '')
        .trim()
        .toLowerCase();
      return one.includes('@') ? [one] : [];
    }
    return [];
  }

  function isOwnerEmail(email) {
    if (isClientBuild()) return false;
    const e = String(email || '')
      .trim()
      .toLowerCase();
    if (!e.includes('@')) return false;
    return ownerEmails().includes(e);
  }

  function setAdminActor(email) {
    _adminActorEmail = String(email || '')
      .trim()
      .toLowerCase();
  }

  function getAdminActor() {
    return _adminActorEmail;
  }

  function loadJson(key, fallback, store) {
    try {
      const s = store || localStorage;
      const v = JSON.parse(s.getItem(key));
      return v ?? fallback;
    } catch (_) {
      return fallback;
    }
  }

  function saveJson(key, val, store) {
    (store || localStorage).setItem(key, JSON.stringify(val));
  }

  function now() {
    return Date.now();
  }

  function defaultSub() {
    return {
      tier: 'starter',
      source: 'default',
      status: 'inactive',
      trialEndsAt: null,
      code: null,
    };
  }

  function readEntitlementCache() {
    const raw = loadJson(ENTITLEMENT_KEY, null, sessionStorage);
    if (!raw || typeof raw !== 'object') return null;
    if (!raw.userId || !TIERS[raw.tier]) return null;
    if (!raw.syncedAt || now() - Number(raw.syncedAt) > CACHE_MAX_AGE_MS) {
      return null;
    }
    if (
      raw.source === 'trial' &&
      raw.trialEndsAt &&
      now() > Number(raw.trialEndsAt)
    ) {
      return null;
    }
    return raw;
  }

  function writeEntitlement(ent) {
    _entitlement = ent;
    if (!ent) {
      try {
        sessionStorage.removeItem(ENTITLEMENT_KEY);
      } catch (_) {
        /* ignore */
      }
      return;
    }
    saveJson(ENTITLEMENT_KEY, ent, sessionStorage);
    // UI mirror only — never read for feature gates
    saveJson(
      SUB_UI_KEY,
      {
        tier: ent.tier,
        source: ent.source,
        status: ent.status || null,
        trialEndsAt: ent.trialEndsAt || null,
        currentPeriodEnd: ent.currentPeriodEnd || null,
        updatedAt: now(),
      },
      localStorage
    );
    try {
      document.dispatchEvent(
        new CustomEvent('paletyzator:billing', { detail: { sub: getSubscription() } })
      );
    } catch (_) {
      /* ignore */
    }
  }

  function currentUserId() {
    try {
      const Auth = global.PaletyzatorAuth;
      const client = Auth && Auth.getClient && Auth.getClient();
      // sync path usually has session; best-effort from cached entitlement user
      return (_entitlement && _entitlement.userId) || null;
    } catch (_) {
      return null;
    }
  }

  /**
   * Jedyna ścieżka odczytu planu do gate'ów.
   * Bez zweryfikowanego entitlementu z serwera → zawsze Starter (default).
   */
  function getSubscription() {
    const ent = _entitlement || readEntitlementCache();
    if (ent) {
      _entitlement = ent;
      if (
        ent.source === 'trial' &&
        ent.trialEndsAt &&
        now() > Number(ent.trialEndsAt)
      ) {
        writeEntitlement(null);
        return defaultSub();
      }
      return {
        tier: ent.tier,
        source: ent.source,
        status: ent.status || 'active',
        trialEndsAt: ent.trialEndsAt || null,
        code: ent.code || null,
        currentPeriodEnd: ent.currentPeriodEnd || null,
        stripeCustomerId: ent.stripeCustomerId || null,
        stripeSubscriptionId: ent.stripeSubscriptionId || null,
        stripePriceId: ent.stripePriceId || null,
        verified: true,
      };
    }
    return defaultSub();
  }

  /** @deprecated Nie używać z konsoli — no-op dla bezpieczeństwa. */
  function setSubscription(_sub) {
    console.warn(
      '[PaletyzatorBilling] setSubscription jest zablokowane. Plan ustawiają tylko Stripe webhook / redeem-trial-code.'
    );
    return getSubscription();
  }

  function getTier() {
    return TIERS[getSubscription().tier] || TIERS.starter;
  }

  function hasFeature(name) {
    const f = getTier().features || {};
    return !!f[name];
  }

  function maxSkuRows() {
    return getTier().maxSkuRows || 5;
  }

  function maxProducts() {
    return getTier().maxProducts || 10;
  }

  function isAdminUnlocked() {
    if (isClientBuild()) return false;
    return isOwnerEmail(_adminActorEmail);
  }

  function unlockAdmin(_pin) {
    return false;
  }

  function lockAdmin() {
    /* e-mail gate */
  }

  function listCodes() {
    const list = loadJson(CODES_KEY, []);
    return Array.isArray(list) ? list : [];
  }

  function saveCodes(list) {
    saveJson(CODES_KEY, list);
  }

  function randomChunk(len) {
    let s = '';
    for (let i = 0; i < len; i++) {
      s += CODE_ALPHABET[(Math.random() * CODE_ALPHABET.length) | 0];
    }
    return s;
  }

  function normalizeCode(raw) {
    return String(raw || '')
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, '')
      .replace(/^(.{4})(.{4})$/, '$1-$2')
      .slice(0, 9);
  }

  function formatCodeBody() {
    return randomChunk(4) + '-' + randomChunk(4);
  }

  function stripeConfig() {
    const c = global.PALETYZATOR_CONFIG || {};
    return {
      publishableKey: String(c.stripePublishableKey || '').trim(),
      priceIds: c.stripePriceIds || {},
      display: c.stripePricesDisplay || {},
    };
  }

  function priceIdForTier(tierId) {
    const ids = stripeConfig().priceIds || {};
    return String(ids[tierId] || '').trim();
  }

  function displayPrice(tierId) {
    const d = (stripeConfig().display || {})[tierId];
    if (!d || d.amount == null) return null;
    return {
      amount: Number(d.amount),
      currency: String(d.currency || 'PLN'),
      interval: String(d.interval || 'month'),
    };
  }

  function formatPriceLabel(tierId) {
    const p = displayPrice(tierId);
    if (!p) return '';
    const n = Number(p.amount);
    const amount = Number.isInteger(n)
      ? String(n)
      : n.toFixed(2).replace('.', ',');
    const cur = p.currency === 'PLN' ? 'zł' : p.currency;
    const per =
      p.interval === 'month' ? t('billing.price.perMonth') : '/' + p.interval;
    return amount + ' ' + cur + ' ' + per;
  }

  async function readFunctionsErrorBody(error) {
    try {
      const ctx = error && error.context;
      if (!ctx) return null;
      if (typeof ctx.json === 'function') {
        return await ctx.json();
      }
      if (typeof ctx.text === 'function') {
        const raw = await ctx.text();
        try {
          return JSON.parse(raw);
        } catch (_) {
          return raw ? { error: raw } : null;
        }
      }
    } catch (_) {
      /* ignore */
    }
    return null;
  }

  /**
   * Wywołanie Edge Function z JWT użytkownika.
   * Preferujemy zwykły fetch (czytelne błędy CORS / body),
   * z fallbackiem na client.functions.invoke.
   */
  async function invokeEdge(fnName, body) {
    const Auth = global.PaletyzatorAuth;
    if (!Auth || !Auth.isConfigured || !Auth.isConfigured()) {
      return { ok: false, error: t('billing.err.loginRequired') };
    }
    const client = Auth.getClient && Auth.getClient();
    if (!client) return { ok: false, error: t('billing.err.loginRequired') };
    let session = null;
    try {
      const { data } = await client.auth.getSession();
      session = data?.session || null;
    } catch (_) {
      /* ignore */
    }
    if (!session?.access_token) {
      return { ok: false, error: t('billing.err.loginRequired') };
    }

    const cfg = Auth.getConfig();
    const url =
      cfg.supabaseUrl.replace(/\/$/, '') + '/functions/v1/' + fnName;
    const payload = body || {};

    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          Authorization: 'Bearer ' + session.access_token,
          apikey: cfg.supabaseAnonKey,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        return {
          ok: false,
          error:
            data.error ||
            data.hint ||
            t('billing.err.edgeHttp', { status: res.status }),
          details: data,
        };
      }
      if (data && data.error && !data.ok && !data.url && !data.created) {
        return { ok: false, error: data.error, details: data };
      }
      return { ok: true, url: data && data.url, data };
    } catch (fetchErr) {
      // Fallback: supabase-js (czasem lepszy przy nietypowych sieciach)
      try {
        if (typeof client.functions?.invoke === 'function') {
          const { data, error } = await client.functions.invoke(fnName, {
            body: payload,
          });
          if (error) {
            const fromBody = await readFunctionsErrorBody(error);
            const msg =
              (fromBody && (fromBody.error || fromBody.hint)) ||
              (data && (data.error || data.hint)) ||
              error.message ||
              String(error);
            return { ok: false, error: msg, details: fromBody || data };
          }
          if (data && data.error && !data.ok && !data.url && !data.created) {
            return { ok: false, error: data.error, details: data };
          }
          return { ok: true, url: data && data.url, data };
        }
      } catch (_) {
        /* ignore */
      }
      return {
        ok: false,
        error:
          (fetchErr && fetchErr.message) ||
          t('billing.err.edgeNetwork'),
      };
    }
  }

  function normalizeSource(raw) {
    const s = String(raw || '').toLowerCase();
    if (s === 'trial') return 'trial';
    if (s === 'stripe') return 'stripe';
    if (s === 'promo' || s === 'admin_grant') return s;
    return s || 'stripe';
  }

  function rowIsActiveEntitlement(data) {
    if (!data || !TIERS[data.tier]) return false;
    const status = String(data.status || '');
    return status === 'active' || status === 'trialing' || status === 'past_due';
  }

  function applyRemoteRow(userId, data) {
    if (rowIsActiveEntitlement(data)) {
      writeEntitlement({
        userId,
        tier: data.tier,
        source: normalizeSource(data.source),
        status: String(data.status || 'active'),
        trialEndsAt: data.trial_ends_at
          ? new Date(data.trial_ends_at).getTime()
          : null,
        currentPeriodEnd: data.current_period_end
          ? new Date(data.current_period_end).getTime()
          : null,
        stripeCustomerId: data.stripe_customer_id || null,
        stripeSubscriptionId: data.stripe_subscription_id || null,
        stripePriceId: data.stripe_price_id || null,
        syncedAt: now(),
      });
      return { ok: true, subscription: getSubscription() };
    }
    // canceled / inactive → clear paid entitlement (caller may re-grant promo)
    writeEntitlement(null);
    return { ok: true, empty: true, subscription: getSubscription() };
  }

  /** Fallback when RPC unavailable: verified Business after real session sync. */
  function applyPromoBusinessFallback(userId) {
    writeEntitlement({
      userId,
      tier: HIGHEST,
      source: 'promo',
      status: 'active',
      trialEndsAt: null,
      currentPeriodEnd: null,
      stripeCustomerId: null,
      stripeSubscriptionId: null,
      stripePriceId: null,
      syncedAt: now(),
    });
    return { ok: true, subscription: getSubscription(), granted: 'fallback' };
  }

  /**
   * RPC SECURITY DEFINER — upsert Business (source=promo) for auth.uid().
   * Nie nadpisuje aktywnego Stripe/trial.
   */
  async function ensurePromoBusinessRemote(client) {
    try {
      const { data, error } = await client.rpc('ensure_promo_business');
      if (error) return { ok: false, error: error.message || String(error) };
      return { ok: true, data };
    } catch (e) {
      return { ok: false, error: (e && e.message) || String(e) };
    }
  }

  async function fetchSubscriptionRow(client, userId) {
    const { data, error } = await client
      .from('subscriptions')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();
    if (error) return { ok: false, error: error.message || String(error) };
    return { ok: true, data: data || null };
  }

  async function syncRemoteSubscription() {
    const Auth = global.PaletyzatorAuth;
    if (!Auth || !Auth.isConfigured || !Auth.isConfigured()) {
      writeEntitlement(null);
      return { ok: false, reason: 'no-config' };
    }
    const client = Auth.getClient && Auth.getClient();
    if (!client) {
      writeEntitlement(null);
      return { ok: false, reason: 'no-client' };
    }
    let userId = null;
    try {
      const { data } = await client.auth.getSession();
      userId = data?.session?.user?.id || null;
    } catch (_) {
      writeEntitlement(null);
      return { ok: false, reason: 'no-session' };
    }
    if (!userId) {
      writeEntitlement(null);
      return { ok: false, reason: 'no-session' };
    }

    let fetched = await fetchSubscriptionRow(client, userId);
    if (!fetched.ok) return { ok: false, error: fetched.error };

    if (rowIsActiveEntitlement(fetched.data)) {
      return applyRemoteRow(userId, fetched.data);
    }

    // Brak aktywnej sub → grant Business (promo) po stronie serwera
    const granted = await ensurePromoBusinessRemote(client);
    if (granted.ok && granted.data) {
      const row = Array.isArray(granted.data) ? granted.data[0] : granted.data;
      if (rowIsActiveEntitlement(row)) {
        return applyRemoteRow(userId, row);
      }
    }

    fetched = await fetchSubscriptionRow(client, userId);
    if (fetched.ok && rowIsActiveEntitlement(fetched.data)) {
      return applyRemoteRow(userId, fetched.data);
    }

    // RPC / RLS jeszcze nie wdrożone — tymczasowy verified Business po syncu sesji
    return applyPromoBusinessFallback(userId);
  }

  async function startCheckout(tierId) {
    const id = String(tierId || '').toLowerCase();
    const priceId = priceIdForTier(id);
    if (!priceId) {
      return { ok: false, error: t('billing.err.noPrice') };
    }
    return invokeEdge('create-checkout-session', { tier: id, priceId });
  }

  async function openCustomerPortal() {
    return invokeEdge('create-portal-session', {});
  }

  /**
   * Po powrocie z Checkout — NIE ufaj ?plan= z URL.
   * Polling syncRemoteSubscription aż webhook zapisze wiersz.
   */
  async function confirmCheckoutFromServer(opts) {
    const attempts = (opts && opts.attempts) || 8;
    const delayMs = (opts && opts.delayMs) || 900;
    let last = { ok: false };
    for (let i = 0; i < attempts; i++) {
      last = await syncRemoteSubscription();
      if (last.ok && last.subscription && last.subscription.verified) {
        const src = last.subscription.source;
        if (src === 'stripe' || src === 'trial' || src === 'promo' || src === 'admin_grant') {
          return last;
        }
      }
      await new Promise((r) => setTimeout(r, delayMs));
    }
    return last;
  }

  /** Generowanie kodów — tylko owner, zapis w Supabase trial_codes. */
  async function generateCodes(count) {
    if (isClientBuild()) {
      throw new Error(t('billing.err.admin'));
    }
    if (!isAdminUnlocked()) {
      throw new Error(t('billing.err.admin'));
    }
    const n = Math.min(50, Math.max(1, Number(count) || 1));
    const res = await invokeEdge('generate-trial-codes', { count: n });
    if (!res.ok) {
      const hint =
        res.details && (res.details.hint || res.details.error);
      throw new Error(
        [res.error || t('billing.err.genFailed'), hint]
          .filter(Boolean)
          .filter((v, i, a) => a.indexOf(v) === i)
          .join(' — ')
      );
    }
    const created = (res.data && res.data.created) || [];
    if (!created.length) {
      throw new Error(t('billing.err.genEmpty'));
    }
    // lokalny podgląd tabeli admina (autorytatywne = trial_codes w Supabase)
    const list = listCodes();
    created.forEach((row) => {
      list.unshift({
        code: row.code,
        status: 'unused',
        createdAt: now(),
        usedAt: null,
        usedBy: null,
        trialEndsAt: null,
        tier: row.tier || HIGHEST,
        days: row.days || TRIAL_DAYS,
      });
    });
    saveCodes(list);
    return created.map((c) => ({
      code: c.code,
      status: 'unused',
      tier: c.tier || HIGHEST,
      days: c.days || TRIAL_DAYS,
      createdAt: now(),
    }));
  }

  /** Redeem — tylko Edge Function → subscriptions. Lokalny forge nie działa. */
  async function redeemCode(rawCode, _userLabel) {
    const code = normalizeCode(rawCode);
    if (!/^[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(code)) {
      return { ok: false, error: t('billing.err.codeFormat') };
    }
    const res = await invokeEdge('redeem-trial-code', { code });
    if (!res.ok) {
      const err = res.error || t('billing.err.codeMissing');
      if (/wykorzystany|used|409/i.test(err)) {
        return { ok: false, error: t('billing.err.codeUsed') };
      }
      if (/nie znaleziono|not found|404/i.test(err)) {
        return { ok: false, error: t('billing.err.codeMissing') };
      }
      return { ok: false, error: err };
    }
    const sub = res.data && res.data.subscription;
    // natychmiastowy sync z DB
    const synced = await syncRemoteSubscription();
    if (synced.ok && synced.subscription && synced.subscription.verified) {
      return { ok: true, subscription: synced.subscription, code };
    }
    // fallback: użyj odpowiedzi edge jeśli RLS opóźnione
    if (sub && TIERS[sub.tier]) {
      const Auth = global.PaletyzatorAuth;
      let userId = 'unknown';
      try {
        const { data } = await Auth.getClient().auth.getSession();
        userId = data?.session?.user?.id || userId;
      } catch (_) {
        /* ignore */
      }
      writeEntitlement({
        userId,
        tier: sub.tier,
        source: 'trial',
        status: 'trialing',
        trialEndsAt: sub.trialEndsAt
          ? new Date(sub.trialEndsAt).getTime()
          : null,
        code,
        syncedAt: now(),
      });
      return { ok: true, subscription: getSubscription(), code };
    }
    return { ok: false, error: t('billing.err.checkout') };
  }

  function canCancelSubscription() {
    const sub = getSubscription();
    if (!sub || !sub.verified) return false;
    // Promo / admin_grant: wszyscy mają Business — bez rezygnacji do Starter
    if (sub.source === 'stripe' || sub.source === 'trial') return true;
    return false;
  }

  /** Ukryj Kup gdy user ma już Business (promo / trial / Stripe). */
  function isBusinessEntitled() {
    const sub = getSubscription();
    return !!(
      sub &&
      sub.verified &&
      sub.tier === HIGHEST &&
      (sub.status === 'active' ||
        sub.status === 'trialing' ||
        sub.status === 'past_due' ||
        !sub.status)
    );
  }

  function canOpenPortal() {
    const sub = getSubscription();
    return !!(sub && sub.verified && sub.source === 'stripe' && sub.stripeCustomerId);
  }

  /**
   * Lokalna rezygnacja UI — dla Stripe zalecany portal.
   * Czyści tylko cache; webhook / portal finalizuje po stronie Stripe.
   */
  function cancelSubscription() {
    const prev = getSubscription();
    if (!canCancelSubscription()) {
      return { ok: false, error: t('billing.cancel.none') };
    }
    const previousTier = prev.tier;
    writeEntitlement(null);
    saveJson(
      SUB_UI_KEY,
      {
        tier: 'starter',
        source: 'cancelled',
        previousTier,
        cancelledAt: now(),
      },
      localStorage
    );
    return {
      ok: true,
      subscription: defaultSub(),
      previousTier,
      note: prev.source === 'stripe' ? 'prefer-portal' : null,
    };
  }

  function clearEntitlement() {
    writeEntitlement(null);
  }

  const remote = {
    async syncCodes() {
      return listCodes();
    },
    async pushCode() {
      return { ok: false, reason: 'use-generate-trial-codes' };
    },
    syncSubscription: syncRemoteSubscription,
  };

  function formatDate(ts) {
    if (!ts) return '—';
    try {
      return new Date(ts).toLocaleString();
    } catch (_) {
      return String(ts);
    }
  }

  function statusLabel(sub) {
    sub = sub || getSubscription();
    if (sub.source === 'trial' && sub.trialEndsAt) {
      const days = Math.max(
        0,
        Math.ceil((Number(sub.trialEndsAt) - now()) / (24 * 60 * 60 * 1000))
      );
      return t('billing.status.trial', {
        days,
        tier: t('billing.tier.' + sub.tier),
      });
    }
    if (sub.source === 'expired') {
      return t('billing.status.expired');
    }
    if (sub.source === 'cancelled') {
      return t('billing.status.cancelled', {
        tier: t('billing.tier.' + (sub.previousTier || 'business')),
      });
    }
    if (sub.source === 'stripe') {
      let label = t('billing.status.paid', {
        tier: t('billing.tier.' + sub.tier),
      });
      if (sub.currentPeriodEnd) {
        label +=
          ' · ' +
          t('billing.status.until', { date: formatDate(sub.currentPeriodEnd) });
      }
      return label;
    }
    if (sub.source === 'promo' || sub.source === 'admin_grant') {
      return t('billing.status.promo', {
        tier: t('billing.tier.' + (sub.tier || 'business')),
      });
    }
    return t('billing.status.plan', { tier: t('billing.tier.' + sub.tier) });
  }

  // Hydrate cache on load (session only)
  _entitlement = readEntitlementCache();

  global.PaletyzatorBilling = {
    TIERS,
    HIGHEST,
    TRIAL_DAYS,
    getSubscription,
    /** Zablokowane — celowo zostawione jako no-op ostrzegający. */
    setSubscription,
    getTier,
    hasFeature,
    maxSkuRows,
    maxProducts,
    listCodes,
    generateCodes,
    redeemCode,
    cancelSubscription,
    canCancelSubscription,
    canOpenPortal,
    isBusinessEntitled,
    startCheckout,
    openCustomerPortal,
    syncRemoteSubscription,
    confirmCheckoutFromServer,
    clearEntitlement,
    priceIdForTier,
    displayPrice,
    formatPriceLabel,
    normalizeCode,
    unlockAdmin,
    lockAdmin,
    isAdminUnlocked,
    isClientBuild,
    isOwnerEmail,
    ownerEmails,
    setAdminActor,
    getAdminActor,
    ownerPinHint: () => '',
    statusLabel,
    formatDate,
    remote,
  };
})(typeof window !== 'undefined' ? window : globalThis);
