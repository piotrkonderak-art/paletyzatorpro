/**
 * Paletyzator Pro — konfiguracja (przykład).
 *
 * 1. Skopiuj ten plik jako `js/config.js`
 * 2. Wklej URL i klucz anon z Supabase → Project Settings → API
 * 3. Ustaw siteUrl na publiczny adres HTTPS aplikacji (wymagany dla linków e-mail)
 *
 * NIE commituj prawdziwych kluczy service_role. Klucz anon jest publiczny
 * (trafia do przeglądarki), ale i tak trzymaj config.js poza repozytorium.
 */
window.PALETYZATOR_CONFIG = {
  /** np. https://xxxx.supabase.co */
  supabaseUrl: 'https://YOUR_PROJECT_REF.supabase.co',
  /** klucz anon / publishable (sb_publishable_… albo klasyczny JWT anon) */
  supabaseAnonKey: 'YOUR_SUPABASE_ANON_KEY',
  /**
   * Publiczny URL aplikacji (bez końcowego /).
   * Linki potwierdzenia i resetu hasła wracają tutaj.
   * Na telefonie / produkcji: https://twoja-domena.pl
   * Lokalnie (test): http://localhost:8080
   * file:// NIE działa z e-mailami Auth — potrzebny hosting lub tunnel.
   */
  siteUrl: 'http://localhost:8080',
  /**
   * true = paczka klienta (bez generatora kodów / panelu właściciela).
   * false = pełna wersja z panelem admina (gate po ownerEmails).
   */
  clientBuild: false,
  /**
   * Konta z dostępem admin (generator kodów). Case-insensitive.
   * W buildzie klienta usuwane.
   */
  ownerEmails: ['owner@example.com'],
  /**
   * Stripe Checkout — tylko publishable key + price IDs (publiczne).
   * Secret key wyłącznie w Supabase Edge Secrets (STRIPE_SECRET_KEY).
   */
  stripePublishableKey: 'pk_test_…',
  stripePriceIds: {
    starter: 'price_…', // 1 PLN / mies.
    pro: 'price_…', // 2 PLN / mies.
    business: 'price_…', // 3 PLN / mies.
  },
  stripePricesDisplay: {
    starter: { amount: 1, currency: 'PLN', interval: 'month' },
    pro: { amount: 2, currency: 'PLN', interval: 'month' },
    business: { amount: 3, currency: 'PLN', interval: 'month' },
  },
  /**
   * Sloty reklam / sponsoringu na loginie (1–4: 2 lewo + 2 prawo).
   * Wstaw imageUrl (https) i href, albo zostaw puste pod placeholder.
   */
  loginAds: [
    { slot: 1, enabled: true, href: '', imageUrl: '', label: '' },
    { slot: 2, enabled: true, href: '', imageUrl: '', label: '' },
    { slot: 3, enabled: true, href: '', imageUrl: '', label: '' },
    { slot: 4, enabled: true, href: '', imageUrl: '', label: '' },
  ],
};
