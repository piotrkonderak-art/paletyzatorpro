/**
 * Paletyzator Pro — VIES (sprawdzanie VAT UE) + PDF potwierdzenia.
 * Oficjalny REST KE (gdy CORS pozwala) → fallback vatcomply (dane VIES, bez klucza).
 */
(function (global) {
  'use strict';

  const EU_COUNTRIES = [
    'AT', 'BE', 'BG', 'CY', 'CZ', 'DE', 'DK', 'EE', 'EL', 'ES', 'FI', 'FR',
    'HR', 'HU', 'IE', 'IT', 'LT', 'LU', 'LV', 'MT', 'NL', 'PL', 'PT', 'RO',
    'SE', 'SI', 'SK', 'XI',
  ];
  const COUNTRY_ALIASES = { GR: 'EL' };

  function t(key, vars) {
    if (global.I18n && typeof global.I18n.t === 'function') {
      return global.I18n.t(key, vars);
    }
    return key;
  }

  function esc(s) {
    return String(s ?? '').replace(
      /[&<>"']/g,
      (c) =>
        ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[
          c
        ])
    );
  }

  function normalizeVat(raw) {
    let s = String(raw || '')
      .toUpperCase()
      .replace(/[\s.\-_/]/g, '');
    if (!s) return { error: t('vies.err.empty') };
    let country = '';
    let number = s;
    if (/^[A-Z]{2}/.test(s)) {
      country = s.slice(0, 2);
      number = s.slice(2);
    }
    country = COUNTRY_ALIASES[country] || country;
    if (!country || !EU_COUNTRIES.includes(country)) {
      return { error: t('vies.err.country') };
    }
    if (!/^[A-Z0-9]{2,12}$/.test(number)) {
      return { error: t('vies.err.number') };
    }
    return { country, number, full: country + number };
  }

  function makeLocalRef() {
    const d = new Date();
    const p =
      d.getUTCFullYear().toString() +
      String(d.getUTCMonth() + 1).padStart(2, '0') +
      String(d.getUTCDate()).padStart(2, '0') +
      '-' +
      Math.random().toString(36).slice(2, 8).toUpperCase();
    return 'PP-VIES-' + p;
  }

  function formatDateTime(iso) {
    try {
      const d = iso ? new Date(iso) : new Date();
      const utc = d.toISOString().replace('T', ' ').replace(/\.\d{3}Z$/, ' UTC');
      const local = d.toLocaleString(undefined, {
        dateStyle: 'medium',
        timeStyle: 'medium',
        timeZoneName: 'short',
      });
      return { utc, local, iso: d.toISOString() };
    } catch (_) {
      const now = new Date().toISOString();
      return { utc: now, local: now, iso: now };
    }
  }

  async function fetchJson(url, opts) {
    const res = await fetch(url, opts);
    if (!res.ok) {
      const err = new Error('HTTP ' + res.status);
      err.status = res.status;
      throw err;
    }
    return res.json();
  }

  function mapResult(data, country, number, source) {
    const valid = !!(
      data.valid === true ||
      data.isValid === true ||
      data.userError === 'VALID'
    );
    const name =
      data.name && data.name !== '---' ? String(data.name).trim() : '';
    const address =
      data.address && data.address !== '---'
        ? String(data.address).trim()
        : '';
    const requestIdentifier = String(
      data.requestIdentifier || data.consultationNumber || ''
    ).trim();
    const requestDate = data.requestDate || new Date().toISOString();
    const localRef = makeLocalRef();
    return {
      valid,
      country: data.countryCode || data.country_code || country,
      vatNumber: data.vatNumber || data.vat_number || number,
      fullVat:
        (data.countryCode || data.country_code || country) +
        (data.vatNumber || data.vat_number || number),
      name,
      address,
      requestIdentifier,
      requestDate,
      localRef,
      source,
      raw: data,
    };
  }

  /** Oficjalny REST VIES (POST check-vat-number). */
  async function checkOfficial(country, number) {
    const url =
      'https://ec.europa.eu/taxation_customs/vies/rest-api/check-vat-number';
    const data = await fetchJson(url, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ countryCode: country, vatNumber: number }),
    });
    return mapResult(data, country, number, 'vies-eu');
  }

  /** Fallback CORS — dane z VIES, bez klucza API. */
  async function checkVatComply(country, number) {
    const url =
      'https://api.vatcomply.com/vat?vat_number=' +
      encodeURIComponent(country + number);
    const data = await fetchJson(url, {
      method: 'GET',
      headers: { Accept: 'application/json' },
    });
    return mapResult(data, country, number, 'vies-vatcomply');
  }

  async function checkVat(rawVat, countryHint) {
    let input = rawVat;
    if (countryHint && !/^[A-Za-z]{2}/.test(String(rawVat || '').trim())) {
      input = String(countryHint) + String(rawVat || '');
    }
    const parsed = normalizeVat(input);
    if (parsed.error) return { ok: false, error: parsed.error };

    const errors = [];
    try {
      const r = await checkOfficial(parsed.country, parsed.number);
      return { ok: true, result: r, fallback: false };
    } catch (e) {
      errors.push('official:' + (e.message || e));
    }
    try {
      const r = await checkVatComply(parsed.country, parsed.number);
      return { ok: true, result: r, fallback: true };
    } catch (e) {
      errors.push('vatcomply:' + (e.message || e));
    }
    return {
      ok: false,
      error: t('vies.err.network'),
      detail: errors.join('; '),
    };
  }

  async function resolveLogoSrc() {
    if (global.__PALETYZATOR_LOGO__) return global.__PALETYZATOR_LOGO__;
    if (global.PaletyzatorCMR && global.PaletyzatorCMR.logoAsDataUrl) {
      try {
        return await global.PaletyzatorCMR.logoAsDataUrl();
      } catch (_) { /* ignore */ }
    }
    try {
      const res = await fetch('assets/logo-paletyzator-pro.png');
      const blob = await res.blob();
      return await new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(r.result);
        r.onerror = reject;
        r.readAsDataURL(blob);
      });
    } catch (_) {
      return '';
    }
  }

  function sourceLabel(source) {
    if (source === 'vies-eu') return t('vies.source.eu');
    return t('vies.source.fallback');
  }

  function buildConfirmationHtml(result, opts = {}) {
    const logoSrc = opts.logoSrc || '';
    const dt = formatDateTime(result.requestDate);
    const viesRef = result.requestIdentifier || '';
    const exportRef = result.localRef || makeLocalRef();
    const validText = result.valid ? t('vies.valid') : t('vies.invalid');
    const validClass = result.valid ? 'ok' : 'bad';

    return `<!DOCTYPE html>
<html lang="${esc((global.I18n && global.I18n.getLocale && global.I18n.getLocale()) || 'pl')}">
<head>
<meta charset="UTF-8">
<title>${esc(t('vies.pdf.title'))} — ${esc(result.fullVat)}</title>
<style>
  @page { size: A4; margin: 16mm; }
  * { box-sizing: border-box; }
  body {
    margin: 0; padding: 24px;
    font-family: "Source Sans 3", "Segoe UI", Arial, sans-serif;
    color: #121a28; background: #e8eef5;
    -webkit-print-color-adjust: exact; print-color-adjust: exact;
  }
  .toolbar {
    display: flex; gap: 8px; margin-bottom: 16px;
  }
  .toolbar button {
    border: 0; border-radius: 8px; padding: 10px 16px;
    font: inherit; font-weight: 650; cursor: pointer;
    background: #245eea; color: #fff;
  }
  .toolbar .secondary { background: #e8eef5; color: #121a28; border: 1px solid #c8d3e0; }
  .sheet {
    max-width: 210mm; margin: 0 auto; background: #fff;
    border: 1px solid #c8d3e0; border-radius: 4px;
    padding: 22px 26px 28px;
    box-shadow: 0 8px 28px rgba(11,18,30,0.08);
  }
  .brand {
    display: flex; align-items: center; gap: 12px;
    border-bottom: 2px solid #0b121e; padding-bottom: 12px; margin-bottom: 16px;
  }
  .brand img {
    width: 36px; height: 36px; object-fit: contain; border-radius: 8px;
    border: 1px solid #dde5ef;
  }
  .brand h1 {
    margin: 0; font-size: 18px; letter-spacing: -0.02em; color: #0b121e;
  }
  .brand p {
    margin: 2px 0 0; font-size: 11px; color: #5a6a7e; text-transform: uppercase;
    letter-spacing: 0.08em; font-weight: 650;
  }
  h2 {
    margin: 0 0 6px; font-size: 16px; color: #0b121e;
  }
  .doc-id {
    font-size: 12px; color: #5a6a7e; margin-bottom: 14px;
  }
  table.meta {
    width: 100%; border-collapse: collapse; margin: 12px 0 16px;
    font-size: 13px;
  }
  table.meta th, table.meta td {
    border: 1px solid #c8d3e0; padding: 8px 10px; text-align: left;
    vertical-align: top;
  }
  table.meta th {
    width: 34%; background: #f4f7fb; color: #2a3548; font-weight: 650;
  }
  .badge {
    display: inline-block; padding: 4px 10px; border-radius: 999px;
    font-weight: 700; font-size: 12px; letter-spacing: 0.04em;
  }
  .badge.ok { background: #eaf8f1; color: #177a56; border: 1px solid #c6eedb; }
  .badge.bad { background: #fff0f1; color: #b22b3b; border: 1px solid #ffd5d9; }
  .box {
    border: 1px solid #c8d3e0; border-radius: 4px; padding: 12px 14px;
    margin: 12px 0; background: #fbfcfe; white-space: pre-wrap;
    font-size: 13px; line-height: 1.45;
  }
  .disclaimer {
    margin-top: 18px; padding-top: 12px; border-top: 1px solid #dde5ef;
    font-size: 11px; color: #5a6a7e; line-height: 1.5;
  }
  .foot {
    margin-top: 14px; font-size: 11px; color: #8590a4;
  }
  @media print {
    body { background: #fff; padding: 0; }
    .toolbar { display: none !important; }
    .sheet { box-shadow: none; border: 0; max-width: none; }
  }
</style>
</head>
<body>
  <div class="toolbar no-print">
    <button type="button" onclick="window.print()">${esc(t('vies.pdf.print'))}</button>
    <button type="button" class="secondary" onclick="window.close()">${esc(t('vies.pdf.close'))}</button>
  </div>
  <article class="sheet">
    <header class="brand">
      ${logoSrc ? `<img src="${esc(logoSrc)}" alt="Paletyzator Pro" width="36" height="36">` : ''}
      <div>
        <p>Paletyzator Pro</p>
        <h1>${esc(t('vies.pdf.heading'))}</h1>
      </div>
    </header>

    <h2>${esc(t('vies.pdf.subtitle'))}</h2>
    <p class="doc-id">${esc(t('vies.pdf.exportRef'))}: <strong>${esc(exportRef)}</strong></p>

    <table class="meta">
      <tr><th>${esc(t('vies.pdf.queryAt'))}</th>
        <td>${esc(dt.local)}<br><span style="color:#5a6a7e">${esc(dt.utc)}</span></td></tr>
      <tr><th>${esc(t('vies.pdf.viesRef'))}</th>
        <td>${viesRef ? `<strong>${esc(viesRef)}</strong>` : `<em>${esc(t('vies.pdf.viesRefMissing'))}</em>`}</td></tr>
      <tr><th>${esc(t('vies.pdf.vat'))}</th>
        <td><strong>${esc(result.fullVat)}</strong> (${esc(result.country)})</td></tr>
      <tr><th>${esc(t('vies.pdf.result'))}</th>
        <td><span class="badge ${validClass}">${esc(validText)}</span></td></tr>
      <tr><th>${esc(t('vies.pdf.name'))}</th>
        <td>${esc(result.name || '—')}</td></tr>
      <tr><th>${esc(t('vies.pdf.address'))}</th>
        <td>${esc(result.address || '—')}</td></tr>
      <tr><th>${esc(t('vies.pdf.source'))}</th>
        <td>${esc(sourceLabel(result.source))}</td></tr>
      <tr><th>${esc(t('vies.pdf.issuer'))}</th>
        <td>Paletyzator Pro — ${esc(t('vies.pdf.issuerRole'))}</td></tr>
    </table>

    <div class="box"><strong>${esc(t('vies.pdf.identity'))}</strong><br>${esc(t('vies.pdf.identityBody'))}</div>

    <div class="disclaimer">${esc(t('vies.pdf.disclaimer'))}</div>
    <p class="foot">${esc(t('vies.pdf.footer'))}</p>
  </article>
  <script>window.onload=function(){ /* ready for print */ };<\/script>
</body>
</html>`;
  }

  async function openConfirmationPdf(result) {
    const logoSrc = await resolveLogoSrc();
    const html = buildConfirmationHtml(result, { logoSrc });
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const w = window.open(url, '_blank');
    if (!w) {
      // popup blocked — download HTML as fallback
      const a = document.createElement('a');
      a.href = url;
      a.download = 'vies-confirmation-' + (result.fullVat || 'vat') + '.html';
      a.click();
    }
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    return true;
  }

  global.PaletyzatorVies = {
    EU_COUNTRIES,
    normalizeVat,
    checkVat,
    buildConfirmationHtml,
    openConfirmationPdf,
    formatDateTime,
    sourceLabel,
  };
})(typeof window !== 'undefined' ? window : globalThis);
