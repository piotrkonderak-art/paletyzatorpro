/**
 * Paletyzator Pro — wizualizacja 3D (Three.js).
 * Realistyczniejsza paleta EUR, tektura z brandingiem.
 * Jednostki sceny = centymetry.
 */
(function (global) {
  'use strict';

  const KRAFT_TINTS = [
    '#c4a574', '#b8956a', '#d2b48c', '#a89068', '#c9ab7a', '#bba06e', '#d0b896',
    '#ad9a6c',
  ];

  /**
   * Wytnij tło logo (ciemna płytka) i przytnij do ikony.
   * Jasny środek ikony → chłodny błękit (nie „biała naklejka”).
   */
  function knockOutLogoBackground(source) {
    const w = source.naturalWidth || source.width || 150;
    const h = source.naturalHeight || source.height || 150;
    const src = document.createElement('canvas');
    src.width = w;
    src.height = h;
    const sctx = src.getContext('2d');
    sctx.clearRect(0, 0, w, h);
    sctx.drawImage(source, 0, 0, w, h);
    const id = sctx.getImageData(0, 0, w, h);
    const d = id.data;
    let minX = w;
    let minY = h;
    let maxX = 0;
    let maxY = 0;
    for (let i = 0; i < d.length; i += 4) {
      const r = d[i];
      const g = d[i + 1];
      const b = d[i + 2];
      const a = d[i + 3];
      if (a < 8) {
        d[i + 3] = 0;
        continue;
      }
      const mx = Math.max(r, g, b);
      const mn = Math.min(r, g, b);
      const sat = mx - mn;
      const lum = 0.299 * r + 0.587 * g + 0.114 * b;
      // Ciemna / navy płytka tła
      const isDarkPlate = lum < 92 && sat < 70 && !(b > 130 && sat > 35);
      // Czysty biały pad (nie część ikony z lekkim błękitem)
      const isWhitePad = lum > 248 && sat < 10;
      if (isDarkPlate || isWhitePad) {
        d[i] = 0;
        d[i + 1] = 0;
        d[i + 2] = 0;
        d[i + 3] = 0;
        continue;
      }
      // Białawy środek ikony → miękki brand (nie wygląda jak papierowa płytka)
      if (lum > 215 && sat < 40) {
        d[i] = 214;
        d[i + 1] = 228;
        d[i + 2] = 248;
      }
      const px = (i / 4) % w;
      const py = ((i / 4) / w) | 0;
      if (px < minX) minX = px;
      if (py < minY) minY = py;
      if (px > maxX) maxX = px;
      if (py > maxY) maxY = py;
    }
    sctx.putImageData(id, 0, 0);
    if (maxX <= minX || maxY <= minY) return src;
    const pad = 2;
    minX = Math.max(0, minX - pad);
    minY = Math.max(0, minY - pad);
    maxX = Math.min(w - 1, maxX + pad);
    maxY = Math.min(h - 1, maxY + pad);
    const cw = maxX - minX + 1;
    const ch = maxY - minY + 1;
    const out = document.createElement('canvas');
    // Kwadratowy canvas — bez rozciągania ikony
    const side = Math.max(cw, ch);
    out.width = side;
    out.height = side;
    const octx = out.getContext('2d');
    octx.clearRect(0, 0, side, side);
    octx.drawImage(src, minX, minY, cw, ch, (side - cw) / 2, (side - ch) / 2, cw, ch);
    return out;
  }

  /** Logo ładowane raz — ikona bez płytki tła; mobile: __PALETYZATOR_LOGO__. */
  let _logoImagePromise = null;
  function loadLogoImageOnce() {
    if (_logoImagePromise) return _logoImagePromise;
    _logoImagePromise = new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => resolve(knockOutLogoBackground(img));
      img.onerror = () => {
        // Fallback: sama ikona sześcianu, bez płytki
        const c = document.createElement('canvas');
        c.width = c.height = 256;
        const ctx = c.getContext('2d');
        ctx.clearRect(0, 0, 256, 256);
        ctx.fillStyle = '#3b7aef';
        ctx.beginPath();
        ctx.moveTo(128, 40);
        ctx.lineTo(210, 88);
        ctx.lineTo(210, 168);
        ctx.lineTo(128, 216);
        ctx.lineTo(46, 168);
        ctx.lineTo(46, 88);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#5b9cff';
        ctx.beginPath();
        ctx.moveTo(128, 40);
        ctx.lineTo(210, 88);
        ctx.lineTo(128, 136);
        ctx.lineTo(46, 88);
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#e8eef8';
        ctx.fillRect(104, 104, 48, 48);
        resolve(c);
      };
      const inline =
        typeof global !== 'undefined' && global.__PALETYZATOR_LOGO__
          ? global.__PALETYZATOR_LOGO__
          : typeof window !== 'undefined' && window.__PALETYZATOR_LOGO__
            ? window.__PALETYZATOR_LOGO__
            : '';
      img.src = inline || 'assets/logo-paletyzator-pro.png';
    });
    return _logoImagePromise;
  }

  class PalletViewer3D {
    constructor(container) {
      this.container = container;
      this.scene = null;
      this.camera = null;
      this.renderer = null;
      this.controls = null;
      this.group = null;
      this.animId = null;
      this._resizeObs = null;
      this._ready = false;
      this._pendingResult = null;
      this._tex = null;
      this._sharedMats = [];
      this._renderGen = 0;
      /** Cache materiałów ścianek (klucz: w×h×tint) — aspect-correct branding */
      this._faceMatCache = Object.create(null);
      this._decalTex = null;
      this._plainMats = [];
    }

    async init() {
      if (this._ready) return;
      const THREE = await import('three');
      const { OrbitControls } = await import(
        'three/addons/controls/OrbitControls.js'
      );
      this.THREE = THREE;

      const w = Math.max(this.container.clientWidth, 320);
      const h = Math.max(this.container.clientHeight, 280);

      this.scene = new THREE.Scene();
      this.scene.background = new THREE.Color(0xdde5ee);
      this.scene.fog = new THREE.Fog(0xdde5ee, 380, 1100);

      this.camera = new THREE.PerspectiveCamera(40, w / h, 1, 2500);
      this.camera.position.set(220, 150, 240);

      this.renderer = new THREE.WebGLRenderer({
        antialias: true,
        alpha: false,
        powerPreference: 'high-performance',
        preserveDrawingBuffer: true,
      });
      this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      this.renderer.setSize(w, h);
      this.renderer.shadowMap.enabled = true;
      this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      this.renderer.outputColorSpace = THREE.SRGBColorSpace;
      this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
      this.renderer.toneMappingExposure = 1.05;
      this.container.innerHTML = '';
      this.container.appendChild(this.renderer.domElement);

      this.controls = new OrbitControls(this.camera, this.renderer.domElement);
      this.controls.enableDamping = true;
      this.controls.dampingFactor = 0.07;
      this.controls.minDistance = 50;
      this.controls.maxDistance = 700;
      this.controls.maxPolarAngle = Math.PI * 0.48;
      this.controls.target.set(70, 50, 40);

      const hemi = new THREE.HemisphereLight(0xf4f7fb, 0x8a9188, 0.55);
      this.scene.add(hemi);

      const key = new THREE.DirectionalLight(0xfff4e6, 1.35);
      key.position.set(160, 280, 120);
      key.castShadow = true;
      key.shadow.mapSize.set(2048, 2048);
      key.shadow.camera.near = 20;
      key.shadow.camera.far = 800;
      key.shadow.camera.left = -280;
      key.shadow.camera.right = 280;
      key.shadow.camera.top = 280;
      key.shadow.camera.bottom = -280;
      key.shadow.bias = -0.00025;
      key.shadow.normalBias = 0.04;
      this.scene.add(key);

      const fill = new THREE.DirectionalLight(0xb8c8e8, 0.45);
      fill.position.set(-140, 90, -100);
      this.scene.add(fill);

      const rim = new THREE.DirectionalLight(0xffe2b8, 0.35);
      rim.position.set(40, 60, 200);
      this.scene.add(rim);

      const lamp = new THREE.PointLight(0xfff0d8, 0.35, 500, 2);
      lamp.position.set(60, 220, 40);
      this.scene.add(lamp);

      await this._buildTextures();

      const floor = new THREE.Mesh(
        new THREE.PlaneGeometry(1000, 1000),
        this._tex.floorMat
      );
      floor.rotation.x = -Math.PI / 2;
      floor.position.y = -0.2;
      floor.receiveShadow = true;
      this.scene.add(floor);

      const grid = new THREE.GridHelper(500, 50, 0x9aabbc, 0xb8c4d0);
      grid.position.y = 0.05;
      grid.material.transparent = true;
      grid.material.opacity = 0.45;
      this.scene.add(grid);

      this.group = new THREE.Group();
      this.scene.add(this.group);

      this._resizeObs = new ResizeObserver(() => this._onResize());
      this._resizeObs.observe(this.container);

      this._ready = true;
      this._animate();

      if (this._pendingResult) {
        this.renderResult(this._pendingResult);
        this._pendingResult = null;
      } else {
        this.renderEmpty();
      }
    }

    _canvasTex(draw, size = 512) {
      const THREE = this.THREE;
      const c = document.createElement('canvas');
      c.width = c.height = size;
      const ctx = c.getContext('2d');
      draw(ctx, size);
      const tex = new THREE.CanvasTexture(c);
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = Math.min(
        8,
        this.renderer?.capabilities?.getMaxAnisotropy?.() || 4
      );
      tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
      tex.needsUpdate = true;
      return tex;
    }

    _drawWood(ctx, size, opts = {}) {
      const base = opts.base || '#c9a86c';
      const dark = opts.dark || '#7a5410';
      const light = opts.light || '#e8d4a0';
      ctx.fillStyle = base;
      ctx.fillRect(0, 0, size, size);

      for (let i = 0; i < 110; i++) {
        const y = (i / 110) * size + Math.sin(i * 0.55) * 4;
        ctx.strokeStyle = i % 4 === 0 ? dark : light;
        ctx.globalAlpha = 0.07 + (i % 6) * 0.012;
        ctx.lineWidth = 0.8 + (i % 5) * 0.35;
        ctx.beginPath();
        ctx.moveTo(0, y);
        for (let x = 0; x <= size; x += 6) {
          ctx.lineTo(
            x,
            y + Math.sin(x * 0.035 + i) * 2.8 + Math.sin(x * 0.012) * 5
          );
        }
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      for (let k = 0; k < 7; k++) {
        const kx = 30 + Math.random() * (size - 60);
        const ky = 30 + Math.random() * (size - 60);
        const r = 5 + Math.random() * 12;
        const g = ctx.createRadialGradient(kx, ky, 0.5, kx, ky, r);
        g.addColorStop(0, 'rgba(70,40,12,0.65)');
        g.addColorStop(0.45, 'rgba(110,70,25,0.28)');
        g.addColorStop(1, 'rgba(110,70,25,0)');
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.ellipse(
          kx,
          ky,
          r * 1.5,
          r * 0.65,
          Math.random() * Math.PI,
          0,
          Math.PI * 2
        );
        ctx.fill();
      }

      ctx.globalAlpha = 0.1;
      for (let i = 0; i < 28; i++) {
        ctx.strokeStyle = '#4a3010c';
        ctx.lineWidth = 0.7 + Math.random();
        const y = Math.random() * size;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.bezierCurveTo(
          size * 0.3,
          y + (Math.random() - 0.5) * 12,
          size * 0.7,
          y + (Math.random() - 0.5) * 12,
          size,
          y + (Math.random() - 0.5) * 8
        );
        ctx.stroke();
      }
      ctx.globalAlpha = 1;

      const edge = ctx.createLinearGradient(0, 0, 0, size);
      edge.addColorStop(0, 'rgba(40,25,8,0.18)');
      edge.addColorStop(0.08, 'rgba(40,25,8,0)');
      edge.addColorStop(0.92, 'rgba(40,25,8,0)');
      edge.addColorStop(1, 'rgba(40,25,8,0.22)');
      ctx.fillStyle = edge;
      ctx.fillRect(0, 0, size, size);
    }

    _drawCardboard(ctx, size, tint) {
      this._drawCardboardRect(ctx, size, size, tint);
    }

    /** Realistyczna tektura falista na prostokątnej ściance. */
    _drawCardboardRect(ctx, fw, fh, tint) {
      const base = tint || '#c4a574';
      ctx.fillStyle = base;
      ctx.fillRect(0, 0, fw, fh);

      // Gradient „grubości” tektury
      const g = ctx.createLinearGradient(0, 0, fw, fh);
      g.addColorStop(0, 'rgba(255,245,220,0.22)');
      g.addColorStop(0.45, 'rgba(255,245,220,0)');
      g.addColorStop(1, 'rgba(70,42,16,0.18)');
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, fw, fh);

      // Fale tektury (flute)
      const step = Math.max(2.5, Math.min(fw, fh) * 0.018);
      for (let x = 0; x < fw; x += step) {
        const dark = Math.floor(x / step) % 2 === 0;
        ctx.fillStyle = dark
          ? 'rgba(75,48,20,0.13)'
          : 'rgba(255,236,200,0.1)';
        ctx.fillRect(x, 0, Math.max(1, step * 0.55), fh);
      }

      // Włókna / ziarno
      const fibers = Math.floor((fw * fh) / 900);
      for (let i = 0; i < fibers; i++) {
        ctx.strokeStyle = `rgba(70,40,15,${0.03 + Math.random() * 0.05})`;
        ctx.lineWidth = 0.7 + Math.random();
        const y = Math.random() * fh;
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(fw, y + (Math.random() - 0.5) * 10);
        ctx.stroke();
      }

      // Szew środkowy / sklejka
      ctx.strokeStyle = 'rgba(55,32,12,0.28)';
      ctx.lineWidth = Math.max(1.2, Math.min(fw, fh) * 0.008);
      ctx.beginPath();
      ctx.moveTo(fw * 0.5, fh * 0.04);
      ctx.lineTo(fw * 0.5, fh * 0.96);
      ctx.stroke();

      // Krawędzie — przyciemnienie (kartonowe kantowanie)
      const edge = Math.max(4, Math.min(fw, fh) * 0.045);
      const eg = ctx.createLinearGradient(0, 0, 0, edge);
      eg.addColorStop(0, 'rgba(40,24,8,0.28)');
      eg.addColorStop(1, 'rgba(40,24,8,0)');
      ctx.fillStyle = eg;
      ctx.fillRect(0, 0, fw, edge);
      const eg2 = ctx.createLinearGradient(0, fh, 0, fh - edge);
      eg2.addColorStop(0, 'rgba(40,24,8,0.32)');
      eg2.addColorStop(1, 'rgba(40,24,8,0)');
      ctx.fillStyle = eg2;
      ctx.fillRect(0, fh - edge, fw, edge);
      const eg3 = ctx.createLinearGradient(0, 0, edge, 0);
      eg3.addColorStop(0, 'rgba(40,24,8,0.22)');
      eg3.addColorStop(1, 'rgba(40,24,8,0)');
      ctx.fillStyle = eg3;
      ctx.fillRect(0, 0, edge, fh);
      const eg4 = ctx.createLinearGradient(fw, 0, fw - edge, 0);
      eg4.addColorStop(0, 'rgba(40,24,8,0.22)');
      eg4.addColorStop(1, 'rgba(40,24,8,0)');
      ctx.fillStyle = eg4;
      ctx.fillRect(fw - edge, 0, edge, fh);

      // Obrys wewnętrzny
      ctx.strokeStyle = 'rgba(55,32,12,0.2)';
      ctx.lineWidth = 1.5;
      ctx.strokeRect(edge * 0.6, edge * 0.6, fw - edge * 1.2, fh - edge * 1.2);
    }

    /**
     * Branding na ściance o proporcjach fw×fh (px canvas).
     * Logo bez białego tła + „Paletyzator Pro” — skalowane do krótszego boku.
     */
    _drawBrandFaceRect(ctx, fw, fh, logoImg, tint) {
      this._drawCardboardRect(ctx, fw, fh, tint);

      const short = Math.min(fw, fh);
      const long = Math.max(fw, fh);
      // Na wąskich ściankach mniejsze logo, na kwadratowych większe
      const slim = short / long;
      const logoFrac = slim < 0.55 ? 0.3 : slim < 0.75 ? 0.34 : 0.38;
      const logoSize = short * logoFrac;
      const textTarget = short * (slim < 0.55 ? 0.085 : 0.1);
      const gap = short * 0.035;
      const blockH = logoSize + gap + textTarget;
      const blockY = Math.max(fh * 0.08, (fh - blockH) / 2 - short * 0.02);
      const logoX = (fw - logoSize) / 2;

      if (logoImg) {
        // Delikatny cień pod logo (nie białe tło)
        ctx.save();
        ctx.globalAlpha = 0.18;
        ctx.fillStyle = '#1a1208';
        ctx.beginPath();
        ctx.ellipse(
          fw / 2,
          blockY + logoSize * 0.92,
          logoSize * 0.42,
          logoSize * 0.08,
          0,
          0,
          Math.PI * 2
        );
        ctx.fill();
        ctx.restore();
        ctx.drawImage(logoImg, logoX, blockY, logoSize, logoSize);
      }

      const label = 'Paletyzator Pro';
      let fontSize = textTarget;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      ctx.font = `700 ${Math.round(fontSize)}px "Sora","Segoe UI",system-ui,sans-serif`;
      const maxTextW = fw * 0.9;
      while (ctx.measureText(label).width > maxTextW && fontSize > 7) {
        fontSize *= 0.92;
        ctx.font = `700 ${Math.round(fontSize)}px "Sora","Segoe UI",system-ui,sans-serif`;
      }
      const textY = blockY + logoSize + gap;
      // Lekki cień tekstu (bez jasnego „sticker” halo)
      ctx.fillStyle = 'rgba(30, 18, 8, 0.28)';
      ctx.fillText(label, fw / 2 + 1, textY + 1);
      ctx.fillStyle = '#152033';
      ctx.fillText(label, fw / 2, textY);

      // Akcent marki pod napisem
      const accentY = textY + fontSize + short * 0.025;
      ctx.strokeStyle = '#3b7aef';
      ctx.lineWidth = Math.max(2, short * 0.012);
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(fw * 0.28, accentY);
      ctx.lineTo(fw * 0.72, accentY);
      ctx.stroke();
    }

    /** Kompatybilność ze starym atlasem kwadratowym. */
    _drawBrandFace(ctx, size, logoImg, tint) {
      this._drawBrandFaceRect(ctx, size, size, logoImg, tint);
    }

    _canvasTexRect(draw, widthCm, heightCm, maxPx = 512) {
      const THREE = this.THREE;
      const aspect = Math.max(0.05, widthCm) / Math.max(0.05, heightCm);
      let cw;
      let ch;
      if (aspect >= 1) {
        cw = maxPx;
        ch = Math.max(48, Math.round(maxPx / aspect));
      } else {
        ch = maxPx;
        cw = Math.max(48, Math.round(maxPx * aspect));
      }
      const c = document.createElement('canvas');
      c.width = cw;
      c.height = ch;
      const ctx = c.getContext('2d');
      draw(ctx, cw, ch);
      const tex = new THREE.CanvasTexture(c);
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.anisotropy = Math.min(
        8,
        this.renderer?.capabilities?.getMaxAnisotropy?.() || 4
      );
      tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
      tex.needsUpdate = true;
      return tex;
    }

    /** Materiał ścianki z brandingiem dopasowanym do proporcji (cm). */
    _faceMaterial(faceWcm, faceHcm, colorIndex) {
      const THREE = this.THREE;
      const idx = (colorIndex ?? 0) % KRAFT_TINTS.length;
      const key =
        Math.round(faceWcm * 5) +
        'x' +
        Math.round(faceHcm * 5) +
        ':' +
        idx;
      if (this._faceMatCache[key]) return this._faceMatCache[key];
      const tint = KRAFT_TINTS[idx];
      const logoImg = this._tex && this._tex.logoImg;
      const map = this._canvasTexRect(
        (ctx, cw, ch) => this._drawBrandFaceRect(ctx, cw, ch, logoImg, tint),
        faceWcm,
        faceHcm,
        512
      );
      const mat = new THREE.MeshStandardMaterial({
        map,
        color: 0xffffff,
        roughness: 0.88,
        metalness: 0.02,
      });
      mat.userData.shared = true;
      mat.userData.faceCacheKey = key;
      this._faceMatCache[key] = mat;
      return mat;
    }

    _clearFaceMatCache() {
      Object.keys(this._faceMatCache).forEach((k) => {
        const m = this._faceMatCache[k];
        if (m.map) m.map.dispose();
        m.dispose();
        delete this._faceMatCache[k];
      });
    }

    _drawFloor(ctx, size) {
      ctx.fillStyle = '#c5ccd6';
      ctx.fillRect(0, 0, size, size);
      for (let i = 0; i < 400; i++) {
        const x = Math.random() * size;
        const y = Math.random() * size;
        const c = 100 + Math.random() * 40;
        ctx.fillStyle = `rgba(${c},${c + 8},${c + 16},${0.04 + Math.random() * 0.08})`;
        ctx.fillRect(x, y, 2 + Math.random() * 6, 1 + Math.random() * 2);
      }
      ctx.strokeStyle = 'rgba(80,90,100,0.12)';
      ctx.lineWidth = 2;
      for (let i = 0; i < 4; i++) {
        ctx.beginPath();
        ctx.moveTo((i / 4) * size, 0);
        ctx.lineTo((i / 4) * size, size);
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(0, (i / 4) * size);
        ctx.lineTo(size, (i / 4) * size);
        ctx.stroke();
      }
    }

    _buildBrandMaps(logoImg) {
      const THREE = this.THREE;
      return KRAFT_TINTS.map((tint) => {
        const tex = this._canvasTex(
          (ctx, s) => this._drawBrandFace(ctx, s, logoImg, tint),
          512
        );
        tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
        tex.userData = tex.userData || {};
        tex.userData.brandAtlas = true;
        return tex;
      });
    }

    /**
     * Upewnij się, że atlas brandingu jest gotowy przed rysowaniem kartonów.
     * Wywoływane przy każdym renderResult — logo nigdy nie znika po Przelicz.
     */
    async _ensureBrandTextures() {
      const logoImg = await loadLogoImageOnce();
      if (!this._tex) return logoImg;
      const needsRebuild =
        !this._tex.brandMaps ||
        !this._tex.brandMaps.length ||
        !this._tex.logoImg ||
        this._tex.logoImg !== logoImg ||
        !this._decalTex;
      if (needsRebuild) {
        // Zwolnij stare mapy brandingu (nie drewno/podłoga)
        if (this._tex.brandMaps) {
          this._tex.brandMaps.forEach((t) => t.dispose?.());
        }
        if (this._decalTex && this._decalTex !== this._tex.decalTex) {
          this._decalTex.dispose?.();
        }
        this._clearFaceMatCache();
        this._tex.logoImg = logoImg;
        this._tex.brandMaps = this._buildBrandMaps(logoImg);
        this._decalTex = this._buildDecalTexture(logoImg);
        this._tex.decalTex = this._decalTex;
        if (this._decalMat) {
          this._decalMat.map = this._decalTex;
          this._decalMat.needsUpdate = true;
        }
      }
      return logoImg;
    }

    async _buildTextures() {
      const THREE = this.THREE;
      const logoImg = await loadLogoImageOnce();

      const woodTop = this._canvasTex((ctx, s) => this._drawWood(ctx, s), 512);
      woodTop.repeat.set(2.2, 1.1);
      const woodSide = this._canvasTex(
        (ctx, s) =>
          this._drawWood(ctx, s, {
            base: '#b89555',
            dark: '#5e4010',
            light: '#d8bc78',
          }),
        512
      );
      woodSide.repeat.set(1.2, 0.5);

      const woodBlock = this._canvasTex(
        (ctx, s) =>
          this._drawWood(ctx, s, {
            base: '#9a7340',
            dark: '#4e320c',
            light: '#c4a060',
          }),
        256
      );

      const floorMap = this._canvasTex((ctx, s) => this._drawFloor(ctx, s), 512);
      floorMap.repeat.set(12, 12);

      const brandMaps = this._buildBrandMaps(logoImg);

      const plainMaps = KRAFT_TINTS.map((tint) => {
        const tex = this._canvasTex(
          (ctx, s) => this._drawCardboard(ctx, s, tint),
          256
        );
        tex.repeat.set(1, 1);
        return tex;
      });

      const plainMats = plainMaps.map(
        (map) =>
          new THREE.MeshStandardMaterial({
            map,
            color: 0xffffff,
            roughness: 0.9,
            metalness: 0.02,
            polygonOffset: true,
            polygonOffsetFactor: 1,
            polygonOffsetUnits: 1,
          })
      );
      plainMats.forEach((m) => {
        m.userData.shared = true;
      });

      const woodMatTop = new THREE.MeshStandardMaterial({
        map: woodTop,
        roughness: 0.82,
        metalness: 0.03,
      });
      woodMatTop.userData.shared = true;
      const woodMatSide = new THREE.MeshStandardMaterial({
        map: woodSide,
        roughness: 0.88,
        metalness: 0.02,
      });
      woodMatSide.userData.shared = true;
      const woodMatBlock = new THREE.MeshStandardMaterial({
        map: woodBlock,
        roughness: 0.9,
        metalness: 0.02,
      });
      woodMatBlock.userData.shared = true;
      const floorMat = new THREE.MeshStandardMaterial({
        map: floorMap,
        roughness: 0.95,
        metalness: 0.05,
      });
      floorMat.userData.shared = true;

      this._decalTex = this._buildDecalTexture(logoImg);
      this._plainMats = plainMats;

      this._tex = {
        woodTop,
        woodSide,
        woodBlock,
        brandMaps,
        plainMaps,
        plainMats,
        woodMatTop,
        woodMatSide,
        woodMatBlock,
        floorMat,
        logoImg,
        decalTex: this._decalTex,
      };
      this._sharedMats = [
        woodMatTop,
        woodMatSide,
        woodMatBlock,
        floorMat,
        ...plainMats,
      ];
    }

    /** Przezroczysta tekstura: logo + „Paletyzator Pro” (zero płytki / białego tła). */
    _buildDecalTexture(logoImg) {
      const THREE = this.THREE;
      const size = 512;
      const c = document.createElement('canvas');
      c.width = c.height = size;
      const ctx = c.getContext('2d', { alpha: true, willReadFrequently: true });
      ctx.clearRect(0, 0, size, size);

      const logoSize = size * 0.52;
      const logoX = (size - logoSize) / 2;
      const logoY = size * 0.1;
      if (logoImg) {
        ctx.drawImage(logoImg, logoX, logoY, logoSize, logoSize);
      }

      const label = 'Paletyzator Pro';
      let fontSize = size * 0.072;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      ctx.font = `700 ${Math.round(fontSize)}px "Sora","Segoe UI",system-ui,sans-serif`;
      while (ctx.measureText(label).width > size * 0.88 && fontSize > 10) {
        fontSize *= 0.92;
        ctx.font = `700 ${Math.round(fontSize)}px "Sora","Segoe UI",system-ui,sans-serif`;
      }
      const textY = logoY + logoSize + size * 0.03;
      // Cień tekstu — ciemny, bez jasnego halo
      ctx.fillStyle = 'rgba(20, 14, 8, 0.35)';
      ctx.fillText(label, size / 2 + 1, textY + 1);
      ctx.fillStyle = '#152033';
      ctx.fillText(label, size / 2, textY);

      ctx.strokeStyle = '#3b7aef';
      ctx.lineWidth = Math.max(3, size * 0.01);
      ctx.lineCap = 'round';
      const ay = textY + fontSize + size * 0.028;
      ctx.beginPath();
      ctx.moveTo(size * 0.3, ay);
      ctx.lineTo(size * 0.7, ay);
      ctx.stroke();

      // Wymuś czystą przezroczystość poza inką (usuń półprzezroczyste „mleko”)
      const id = ctx.getImageData(0, 0, size, size);
      const d = id.data;
      for (let i = 0; i < d.length; i += 4) {
        const a = d[i + 3];
        if (a < 18) {
          d[i] = 0;
          d[i + 1] = 0;
          d[i + 2] = 0;
          d[i + 3] = 0;
          continue;
        }
        // Jasne / białe piksele tła (nie część niebieskiej ikony)
        const r = d[i];
        const g = d[i + 1];
        const b = d[i + 2];
        const mx = Math.max(r, g, b);
        const mn = Math.min(r, g, b);
        const sat = mx - mn;
        const lum = 0.299 * r + 0.587 * g + 0.114 * b;
        if (lum > 235 && sat < 28) {
          d[i] = 0;
          d[i + 1] = 0;
          d[i + 2] = 0;
          d[i + 3] = 0;
        }
      }
      ctx.putImageData(id, 0, 0);

      const tex = new THREE.CanvasTexture(c);
      tex.colorSpace = THREE.SRGBColorSpace;
      tex.premultiplyAlpha = false;
      tex.needsUpdate = true;
      return tex;
    }

    _getDecalMaterial() {
      const THREE = this.THREE;
      if (this._decalMat) return this._decalMat;
      const map = this._decalTex || (this._tex && this._tex.decalTex);
      // Basic — bez oświetlenia rozjaśniającego przezroczyste piksele do bieli
      this._decalMat = new THREE.MeshBasicMaterial({
        map: map || null,
        transparent: true,
        opacity: 1,
        alphaTest: 0.35,
        depthWrite: false,
        side: THREE.DoubleSide,
        toneMapped: false,
        polygonOffset: true,
        polygonOffsetFactor: -2,
        polygonOffsetUnits: -2,
      });
      this._decalMat.userData.shared = true;
      this._sharedMats.push(this._decalMat);
      return this._decalMat;
    }

    /**
     * Dekal brandingu na ściance — zawsze kwadratowy w przestrzeni świata
     * (brak UV-stretch logo na wąskich pudłach).
     * boxSx/Sy/Sz = wymiary pudła; axis = 'x'|'y'|'z'; sign = ±1.
     */
    _addBrandDecal(group, cx, cy, cz, boxSx, boxSy, boxSz, axis, sign) {
      const THREE = this.THREE;
      let faceW;
      let faceH;
      let offset;
      if (axis === 'x') {
        faceW = boxSz;
        faceH = boxSy;
        offset = boxSx / 2;
      } else if (axis === 'z') {
        faceW = boxSx;
        faceH = boxSy;
        offset = boxSz / 2;
      } else {
        faceW = boxSx;
        faceH = boxSz;
        offset = boxSy / 2;
      }
      const short = Math.min(faceW, faceH);
      const decal = short * 0.58;
      if (decal < 2.5) return;
      const geo = new THREE.PlaneGeometry(decal, decal);
      const mesh = new THREE.Mesh(geo, this._getDecalMaterial());
      const lift = 0.08;
      if (axis === 'x') {
        mesh.position.set(cx + sign * (offset + lift), cy, cz);
        mesh.rotation.y = sign > 0 ? Math.PI / 2 : -Math.PI / 2;
      } else if (axis === 'z') {
        mesh.position.set(cx, cy, cz + sign * (offset + lift));
        if (sign < 0) mesh.rotation.y = Math.PI;
      } else if (axis === 'y') {
        mesh.position.set(cx, cy + sign * (offset + lift), cz);
        mesh.rotation.x = sign > 0 ? -Math.PI / 2 : Math.PI / 2;
      }
      mesh.renderOrder = 2;
      group.add(mesh);
    }

    _onResize() {
      if (!this.renderer || !this.camera) return;
      const w = Math.max(this.container.clientWidth, 1);
      const h = Math.max(this.container.clientHeight, 1);
      this.camera.aspect = w / h;
      this.camera.updateProjectionMatrix();
      this.renderer.setSize(w, h);
    }

    _animate() {
      this.animId = requestAnimationFrame(() => this._animate());
      if (this.controls) this.controls.update();
      if (this.renderer && this.scene && this.camera) {
        this.renderer.render(this.scene, this.camera);
      }
    }

    dispose() {
      if (this.animId) cancelAnimationFrame(this.animId);
      if (this._resizeObs) this._resizeObs.disconnect();
      if (this.renderer) {
        this.renderer.dispose();
        this.renderer.domElement.remove();
      }
      this._ready = false;
    }

    clearGroup() {
      if (!this.group || !this.THREE) return;
      const shared = new Set(this._sharedMats);
      while (this.group.children.length) {
        const child = this.group.children[0];
        this.group.remove(child);
        child.traverse?.((obj) => {
          if (obj.geometry) obj.geometry.dispose();
          if (obj.material) {
            const mats = Array.isArray(obj.material)
              ? obj.material
              : [obj.material];
            mats.forEach((m) => {
              // Nie zwalniaj shared (drewno/podłoga) ani cache ścianek brandingu
              if (!shared.has(m) && !m.userData?.shared) {
                m.map = null;
                m.dispose();
              }
            });
          }
        });
      }
    }

    renderEmpty() {
      if (!this._ready) return;
      this.clearGroup();
      this._buildPallet(120, 80, 14);
      this._fitCamera(120, 80, 90);
    }

    renderResult(result) {
      if (!this._ready) {
        this._pendingResult = result;
        return;
      }
      // Async path: odśwież branding przed przebudową meshy
      this._renderResultAsync(result);
    }

    async _renderResultAsync(result) {
      const gen = ++this._renderGen;
      try {
        await this._ensureBrandTextures();
      } catch (_) {
        /* branding fallback już w loadLogoImageOnce */
      }
      // Pomiń przestarzały przebieg, jeśli w międzyczasie było kolejne Przelicz
      if (!this._ready || gen !== this._renderGen) return;
      this.clearGroup();
      if (!result || result.error) {
        this.renderEmpty();
        return;
      }

      const { L, W, ph, placements = [], loadHeight } = result;
      const tol = Math.max(0, Number(result.tol) || 0);
      this._buildPallet(L, W, ph);

      for (const p of placements) {
        this.group.add(this._createCarton(p, ph));
      }

      const THREE = this.THREE;

      // Faktyczny AABB ładunku (może lekko wystawać gdy tol > 0)
      let minX = 0;
      let minY = 0;
      let maxX = L;
      let maxY = W;
      for (const p of placements) {
        minX = Math.min(minX, p.x);
        minY = Math.min(minY, p.y);
        maxX = Math.max(maxX, p.x + p.l);
        maxY = Math.max(maxY, p.y + p.w);
      }
      const loadL = maxX - minX;
      const loadW = maxY - minY;
      const hasOverhang =
        minX < -0.05 || minY < -0.05 || maxX > L + 0.05 || maxY > W + 0.05;

      if (tol > 0 && hasOverhang) {
        // Obrys rzeczywistego zwisu (nie sztucznie rozszerzonej palety)
        const pad = new THREE.LineSegments(
          new THREE.EdgesGeometry(new THREE.BoxGeometry(loadL, 0.4, loadW)),
          new THREE.LineDashedMaterial({
            color: 0x7a93b0,
            dashSize: 4,
            gapSize: 3,
            transparent: true,
            opacity: 0.55,
          })
        );
        pad.computeLineDistances();
        pad.position.set((minX + maxX) / 2, ph + 0.3, (minY + maxY) / 2);
        this.group.add(pad);
      }

      if (result.maxH > ph) {
        const maxLoad = result.maxH - ph;
        const outline = new THREE.LineSegments(
          new THREE.EdgesGeometry(new THREE.BoxGeometry(L, maxLoad, W)),
          new THREE.LineDashedMaterial({
            color: 0x3b7aef,
            dashSize: 5,
            gapSize: 3,
            transparent: true,
            opacity: 0.38,
          })
        );
        outline.computeLineDistances();
        outline.position.set(L / 2, ph + maxLoad / 2, W / 2);
        this.group.add(outline);
      }

      this._fitCamera(Math.max(L, loadL), Math.max(W, loadW), ph + (loadHeight || 40));
    }

    _createCarton(p, ph) {
      const THREE = this.THREE;
      const idx = (p.colorIndex ?? 0) % KRAFT_TINTS.length;
      // Minimalny luz wizualny (0.5 mm) — pozycje z packingu bez overlapów / dużych szczelin
      const gap = 0.05;
      const sx = Math.max(0.05, Number(p.l) - gap);
      const sy = Math.max(0.05, Number(p.h) - gap);
      const sz = Math.max(0.05, Number(p.w) - gap);

      const plainMats =
        this._plainMats ||
        (this._tex && this._tex.plainMats) ||
        [];
      const bodyMat =
        plainMats[idx] ||
        this._faceMaterial(Math.max(sx, sz), sy, idx);

      const geo = new THREE.BoxGeometry(sx, sy, sz);
      const mesh = new THREE.Mesh(geo, bodyMat);
      // Środek pudła dokładnie jak w wyniku packingu (x,y podłoga; z wysokość warstwy)
      const z0 = Number(p.z) || 0;
      const cx = Number(p.x) + Number(p.l) / 2;
      const cy = ph + z0 + Number(p.h) / 2;
      const cz = Number(p.y) + Number(p.w) / 2;
      mesh.position.set(cx, cy, cz);
      mesh.castShadow = true;
      mesh.receiveShadow = true;

      const g = new THREE.Group();
      g.add(mesh);

      // Logo jako przezroczyste dekalе (bez białej płytki / UV-stretch)
      this._addBrandDecal(g, cx, cy, cz, sx, sy, sz, 'x', 1);
      this._addBrandDecal(g, cx, cy, cz, sx, sy, sz, 'x', -1);
      this._addBrandDecal(g, cx, cy, cz, sx, sy, sz, 'z', 1);
      this._addBrandDecal(g, cx, cy, cz, sx, sy, sz, 'z', -1);

      // Taśma klejąca na górnej ściance (szew)
      const tape = new THREE.Mesh(
        new THREE.BoxGeometry(sx * 0.92, 0.12, Math.min(1.1, sz * 0.12)),
        new THREE.MeshStandardMaterial({
          color: 0xb8923a,
          roughness: 0.65,
          metalness: 0.08,
        })
      );
      tape.position.set(cx, cy + sy / 2 + 0.06, cz);
      tape.castShadow = true;
      g.add(tape);

      return g;
    }

    _buildPallet(L, W, ph) {
      const { woodMatTop, woodMatSide, woodMatBlock } = this._tex;
      const THREE = this.THREE;

      const deckH = Math.max(ph * 0.22, 2.0);
      const blockH = Math.max(ph - deckH * 2, 6);
      const bottomH = deckH;

      const blockSize = Math.min(14, W * 0.14, L * 0.1);
      const xPos = [blockSize / 2 + 1, L / 2, L - blockSize / 2 - 1];
      const zPos = [blockSize / 2 + 1, W / 2, W - blockSize / 2 - 1];

      for (const x of xPos) {
        for (const z of zPos) {
          const block = new THREE.Mesh(
            new THREE.BoxGeometry(blockSize, blockH, blockSize),
            woodMatBlock
          );
          block.position.set(x, bottomH + blockH / 2, z);
          block.castShadow = true;
          block.receiveShadow = true;
          this.group.add(block);
        }
      }

      const bottomBoardW = Math.min(14, W * 0.16);
      for (const z of zPos) {
        const board = new THREE.Mesh(
          new THREE.BoxGeometry(L * 0.98, bottomH, bottomBoardW),
          [
            woodMatSide,
            woodMatSide,
            woodMatTop,
            woodMatTop,
            woodMatSide,
            woodMatSide,
          ]
        );
        board.position.set(L / 2, bottomH / 2, z);
        board.castShadow = true;
        board.receiveShadow = true;
        this.group.add(board);
      }

      const topCount = L >= 110 ? 7 : L >= 80 ? 5 : 3;
      const gap = 1.5;
      const boardLen = (L - gap * (topCount - 1)) / topCount;
      const topY = bottomH + blockH + deckH / 2;

      for (let i = 0; i < topCount; i++) {
        const x = gap / 2 + boardLen / 2 + i * (boardLen + gap);
        const bw = i === 0 || i === topCount - 1 ? boardLen : boardLen * 0.92;
        const board = new THREE.Mesh(
          new THREE.BoxGeometry(bw, deckH, W * 0.97),
          [
            woodMatSide,
            woodMatSide,
            woodMatTop,
            woodMatTop,
            woodMatSide,
            woodMatSide,
          ]
        );
        board.position.set(x, topY, W / 2);
        board.castShadow = true;
        board.receiveShadow = true;
        this.group.add(board);
      }

      const stringerH = Math.max(deckH * 0.7, 1.5);
      for (const z of [W * 0.08, W * 0.5, W * 0.92]) {
        const s = new THREE.Mesh(
          new THREE.BoxGeometry(L * 0.96, stringerH, Math.min(8, W * 0.08)),
          woodMatSide
        );
        s.position.set(L / 2, bottomH + blockH + stringerH / 2, z);
        s.castShadow = true;
        s.receiveShadow = true;
        this.group.add(s);
      }
    }

    _fitCamera(L, W, H) {
      // Ramka: sama paleta + ładunek
      const cx = L / 2;
      const cy = Math.max(H, 40) * 0.45;
      const cz = W / 2;
      this.controls.target.set(cx, Math.min(cy, 70), cz);
      const dist = Math.max(L, W, H, 100) * 1.45 + 40;
      this.camera.position.set(
        cx + dist * 0.82,
        Math.max(70, H * 0.55) + dist * 0.18,
        cz + dist * 0.68
      );
      this.controls.update();
    }

    resetCamera() {
      if (!this._ready) return;
      const box = new this.THREE.Box3().setFromObject(this.group);
      if (box.isEmpty()) {
        this._fitCamera(120, 80, 90);
        return;
      }
      const size = new this.THREE.Vector3();
      const center = new this.THREE.Vector3();
      box.getSize(size);
      box.getCenter(center);
      this.controls.target.copy(center);
      const dist = Math.max(size.x, size.y, size.z) * 1.75 + 40;
      this.camera.position.set(
        center.x + dist * 0.78,
        center.y + dist * 0.42,
        center.z + dist * 0.72
      );
      this.controls.update();
    }
  }

  function roundRect(ctx, x, y, w, h, r) {
    const rr = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + rr, y);
    ctx.arcTo(x + w, y, x + w, y + h, rr);
    ctx.arcTo(x + w, y + h, x, y + h, rr);
    ctx.arcTo(x, y + h, x, y, rr);
    ctx.arcTo(x, y, x + w, y, rr);
    ctx.closePath();
  }

  global.PalletViewer3D = PalletViewer3D;
  global.PalletViewer3D.KRAFT_TINTS = KRAFT_TINTS;
})(typeof window !== 'undefined' ? window : globalThis);
