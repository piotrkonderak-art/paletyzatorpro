/**
 * Paletyzator Pro — lokalna konfiguracja (projekt Supabase: Paletyzator Pro).
 * Klucz anon / publishable jest publiczny (client-side). Nie wklejaj service_role.
 *
 * Redirect Auth: przy hostingu http(s) runtime używa location (origin + ścieżka pliku).
 * siteUrl poniżej to fallback na file:// / lokalny serwer.
 */
window.PALETYZATOR_CONFIG = {
  supabaseUrl: 'https://ertfehgetuxkmbfzpeed.supabase.co',
  /** Legacy anon JWT (zalecany przez supabase-js) */
  supabaseAnonKey:
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImVydGZlaGdldHV4a21iZnpwZWVkIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI2Njk1NTksImV4cCI6MjEwODI0NTU1OX0.Oq8c7JEyL_fMIvO4UgMfgougN2MGsMn2XMnxM8LBySg',
  /** Alternatywa publishable (nieużywana bezpośrednio — zostawiona jako dokumentacja) */
  supabasePublishableKey: 'sb_publishable__c-nPRGnj6CBlTukE84aqw_-4q2R_w5',
  /**
   * Fallback Site URL gdy brak http(s) (np. otwarcie z dysku).
   * W Dashboard → Authentication → URL Configuration dodaj też realne hosty:
   * - http://localhost:8080/**
   * - https://litter.catbox.moe/**
   * - własna domena HTTPS/**
   */
  siteUrl: 'https://paletyzatorpro.pl',
  /**
   * Pełna wersja (Mr Mango): false — panel właściciela / generator kodów w kodzie,
   * ale widoczny tylko dla ownerEmails po zalogowaniu.
   * Build klienta ustawia true i usuwa UI admina (patrz scripts/build-client.py).
   */
  clientBuild: false,
  /**
   * E-maile z pełnym dostępem admin (generator kodów, panel właściciela).
   * Porównanie case-insensitive. Demo / inni userzy — zero dostępu.
   * Nie trafia do paczki klienta.
   */
  ownerEmails: ['piotrkonderak@gmail.com'],
  /**
   * Stripe (test / sandbox). Publishable key jest publiczny — NIE wklejaj secret key.
   * Price ID z Dashboard / MCP (produkty Paletyzator Pro — Pro / Business, PLN miesięcznie).
   * Po przejściu na live: pk_live_… + nowe price_… z konta produkcyjnego.
   */
  stripePublishableKey: 'pk_test_REPLACE_ME',
  stripePriceIds: {
    /** 1 PLN / mies. — plan Starter (test) */
    starter: 'price_1UTNqUJES83aCOz3MZeF5tbF',
    /** 2 PLN / mies. — plan Pro (test) */
    pro: 'price_1UTNqUJES83aCOz3oFbip6EO',
    /** 3 PLN / mies. — plan Business (test) */
    business: 'price_1UTNqVJES83aCOz3kr8C5lwM',
  },
  /** Wyświetlane ceny (UI); muszą zgadzać się z Stripe Prices. */
  stripePricesDisplay: {
    starter: { amount: 1, currency: 'PLN', interval: 'month' },
    pro: { amount: 2, currency: 'PLN', interval: 'month' },
    business: { amount: 3, currency: 'PLN', interval: 'month' },
  },
  /**
   * Sloty reklam / sponsoringu na stronie logowania (1–4).
   * imageUrl + href → żywy baner; puste → placeholder „Reklama / Sponsoring”.
   */
  loginAds: [
    { slot: 1, enabled: true, href: '', imageUrl: '', label: '' },
    { slot: 2, enabled: true, href: '', imageUrl: '', label: '' },
    { slot: 3, enabled: true, href: '', imageUrl: '', label: '' },
    { slot: 4, enabled: true, href: '', imageUrl: '', label: '' },
  ],
};
