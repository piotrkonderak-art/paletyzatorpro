/**
 * Paletyzator Pro — PDF oferty paletyzacji (HTML → druk / Zapisz PDF).
 * Układ i logo jak potwierdzenie VIES / CMR.
 */
(function (global) {
  'use strict';

  function t(key, vars) {
    if (global.I18n && typeof global.I18n.t === 'function') {
      return global.I18n.t(key, vars);
    }
    return key;
  }

  function esc(s) {
    return String(s ?? '').replace(
      /[&<>"']/g,
      (c) =>
        ({
          '&': '&amp;',
          '<': '&lt;',
          '>': '&gt;',
          '"': '&quot;',
          "'": '&#39;',
        })[c]
    );
  }

  async function resolveLogoSrc() {
    if (global.__PALETYZATOR_LOGO__) return global.__PALETYZATOR_LOGO__;
    if (global.PaletyzatorCMR && global.PaletyzatorCMR.logoAsDataUrl) {
      try {
        return await global.PaletyzatorCMR.logoAsDataUrl();
      } catch (_) {
        /* ignore */
      }
    }
    try {
      const res = await fetch('assets/logo-paletyzator-pro.png');
      const blob = await res.blob();
      return await new Promise((resolve, reject) => {
        const r = new FileReader();
        r.onload = () => resolve(r.result);
        r.onerror = reject;
        r.readAsDataURL(blob);
      });
    } catch (_) {
      return '';
    }
  }

  function failLabel(code) {
    const map = {
      height: t('courier.failHeight'),
      weight: t('courier.failWeight'),
      base: t('courier.failBase'),
      country: t('courier.failCountry'),
    };
    return map[code] || code;
  }

  function buildOfferHtml(result, opts = {}) {
    const logoSrc = opts.logoSrc || '';
    const countryCode = opts.countryCode || '';
    const CR = global.PaletyzatorCourierRules;
    const evalResult =
      opts.evalResult ||
      (CR && countryCode
        ? CR.evaluate(countryCode, {
            heightCm: result.height,
            weightKg: result.weight,
            L: result.L,
            W: result.W,
          })
        : null);

    const countryMeta =
      evalResult && evalResult.country
        ? CR.countryLabel(evalResult.country)
        : countryCode || '—';

    const skuRows = (result.boxes || [])
      .map(
        (b) => `<tr>
        <td>${esc((b.sku || 'SKU').replace(/\s*—\s*.*$/, '') || 'SKU')}</td>
        <td class="c">${esc(b.count)}</td>
        <td class="c">${esc(b.l)}×${esc(b.w)}×${esc(b.h)}</td>
        <td class="r">${esc(Number(b.weight || 0).toFixed(2))}</td>
        <td class="r">${esc((Number(b.count) * Number(b.weight || 0)).toFixed(2))}</td>
      </tr>`
      )
      .join('');

    const courierRows = (evalResult && evalResult.couriers
      ? evalResult.couriers.filter((c) => c.serves).slice(0, 12)
      : []
    )
      .map((c) => {
        const status = c.ok
          ? `<span class="badge ok">${esc(t('courier.eligible'))}</span>`
          : `<span class="badge bad">${esc(t('courier.ineligible'))}</span>`;
        const price = c.priceBand
          ? `${esc(c.priceBand.label)} — ${esc(t('courier.priceFrom', { n: c.priceBand.priceFromPln }))}`
          : '—';
        const why = c.fails && c.fails.length
          ? esc(c.fails.map(failLabel).join(', '))
          : '—';
        return `<tr>
          <td>${esc(c.name)}</td>
          <td>${status}</td>
          <td>≤ ${esc(c.maxWeightKg)} kg · ≤ ${esc(c.maxHeightCm)} cm</td>
          <td>${price}</td>
          <td>${why}</td>
        </tr>`;
      })
      .join('');

    const strategyLabel = result.strategy
      ? t('variants.name.' + result.strategy)
      : t('variants.name.balanced');

    const locale =
      (global.I18n && global.I18n.getLocale && global.I18n.getLocale()) || 'pl';
    const today = new Date().toLocaleString(
      locale === 'de' ? 'de-DE' : locale === 'en' ? 'en-GB' : 'pl-PL'
    );

    return `<!DOCTYPE html>
<html lang="${esc(locale)}">
<head>
<meta charset="UTF-8">
<title>${esc(t('offer.pdf.title'))} — Paletyzator Pro</title>
<style>
  @page { size: A4; margin: 14mm; }
  * { box-sizing: border-box; }
  body {
    margin: 0; padding: 24px;
    font-family: "Source Sans 3", "Segoe UI", Arial, sans-serif;
    color: #121a28; background: #e8eef5;
    -webkit-print-color-adjust: exact; print-color-adjust: exact;
  }
  .toolbar { display: flex; gap: 8px; margin-bottom: 16px; }
  .toolbar button {
    border: 0; border-radius: 8px; padding: 10px 16px;
    font: inherit; font-weight: 650; cursor: pointer;
    background: #245eea; color: #fff;
  }
  .toolbar .secondary { background: #e8eef5; color: #121a28; border: 1px solid #c8d3e0; }
  .sheet {
    max-width: 210mm; margin: 0 auto; background: #fff;
    border: 1px solid #c8d3e0; border-radius: 4px;
    padding: 22px 26px 28px;
    box-shadow: 0 8px 28px rgba(11,18,30,0.08);
  }
  .brand {
    display: flex; align-items: center; gap: 12px;
    border-bottom: 2px solid #0b121e; padding-bottom: 12px; margin-bottom: 16px;
  }
  .brand img {
    width: 36px; height: 36px; object-fit: contain; border-radius: 8px;
    border: 1px solid #dde5ef;
  }
  .brand h1 { margin: 0; font-size: 18px; letter-spacing: -0.02em; color: #0b121e; }
  .brand p {
    margin: 2px 0 0; font-size: 11px; color: #5a6a7e; text-transform: uppercase;
    letter-spacing: 0.08em; font-weight: 650;
  }
  h2 { margin: 18px 0 8px; font-size: 14px; color: #0b121e; }
  .doc-id { font-size: 12px; color: #5a6a7e; margin: 0 0 12px; }
  .kpis {
    display: grid; grid-template-columns: repeat(3, 1fr); gap: 8px; margin: 12px 0 8px;
  }
  .kpi {
    border: 1px solid #c8d3e0; border-radius: 6px; padding: 10px 12px; background: #f4f7fb;
  }
  .kpi small { display: block; font-size: 10px; color: #5a6a7e; font-weight: 650; margin-bottom: 4px; }
  .kpi strong { font-size: 15px; color: #0b121e; }
  table.data {
    width: 100%; border-collapse: collapse; margin: 8px 0 4px; font-size: 12px;
  }
  table.data th, table.data td {
    border: 1px solid #c8d3e0; padding: 6px 8px; text-align: left; vertical-align: top;
  }
  table.data th { background: #f4f7fb; color: #2a3548; font-weight: 650; }
  table.data .c { text-align: center; }
  table.data .r { text-align: right; }
  .badge {
    display: inline-block; padding: 2px 8px; border-radius: 999px;
    font-weight: 700; font-size: 11px;
  }
  .badge.ok { background: #eaf8f1; color: #177a56; border: 1px solid #c6eedb; }
  .badge.bad { background: #fff0f1; color: #b22b3b; border: 1px solid #ffd5d9; }
  .disclaimer {
    margin-top: 16px; padding-top: 12px; border-top: 1px solid #dde5ef;
    font-size: 11px; color: #5a6a7e; line-height: 1.5;
  }
  .foot { margin-top: 10px; font-size: 11px; color: #8590a4; }
  @media print {
    body { background: #fff; padding: 0; }
    .toolbar { display: none !important; }
    .sheet { box-shadow: none; border: 0; max-width: none; }
  }
</style>
</head>
<body>
  <div class="toolbar no-print">
    <button type="button" onclick="window.print()">${esc(t('offer.pdf.print'))}</button>
    <button type="button" class="secondary" onclick="window.close()">${esc(t('offer.pdf.close'))}</button>
  </div>
  <article class="sheet">
    <header class="brand">
      ${logoSrc ? `<img src="${esc(logoSrc)}" alt="Paletyzator Pro" width="36" height="36">` : ''}
      <div>
        <p>Paletyzator Pro</p>
        <h1>${esc(t('offer.pdf.heading'))}</h1>
      </div>
    </header>

    <p class="doc-id">${esc(t('offer.pdf.generated'))}: <strong>${esc(today)}</strong>
      · ${esc(t('offer.pdf.strategy'))}: <strong>${esc(strategyLabel)}</strong>
      ${countryCode ? ` · ${esc(t('courier.country'))}: <strong>${esc(countryMeta)} (${esc(countryCode)})</strong>` : ''}
    </p>

    <div class="kpis">
      <div class="kpi"><small>${esc(t('calc.base'))}</small><strong>${esc(result.L)} × ${esc(result.W)} cm</strong></div>
      <div class="kpi"><small>${esc(t('calc.totalH'))}</small><strong>${esc(Number(result.height).toFixed(1))} cm</strong></div>
      <div class="kpi"><small>${esc(t('calc.loadedW'))}</small><strong>${esc(Number(result.weight).toFixed(2))} kg</strong></div>
      <div class="kpi"><small>${esc(t('calc.loaded'))}</small><strong>${esc(result.loadedBoxes)} / ${esc(result.totalBoxes)}</strong></div>
      <div class="kpi"><small>${esc(t('calc.layers'))}</small><strong>${esc(result.layers)}</strong></div>
      <div class="kpi"><small>${esc(t('calc.ph'))}</small><strong>${esc(Number(result.ph).toFixed(1))} cm</strong></div>
    </div>

    <h2>${esc(t('offer.pdf.skuTitle'))}</h2>
    <table class="data">
      <thead>
        <tr>
          <th>SKU</th>
          <th class="c">${esc(t('calc.colQty'))}</th>
          <th class="c">${esc(t('calc.colDims'))}</th>
          <th class="r">${esc(t('calc.colWeight'))} (kg)</th>
          <th class="r">${esc(t('offer.pdf.lineWeight'))}</th>
        </tr>
      </thead>
      <tbody>${skuRows || `<tr><td colspan="5">—</td></tr>`}</tbody>
    </table>

    ${
      evalResult
        ? `<h2>${esc(t('offer.pdf.courierTitle'))}</h2>
    <p class="doc-id">${esc(
      t('courier.eligibleCount', {
        n: evalResult.eligibleCount,
        total: evalResult.servingCount,
      })
    )}</p>
    <table class="data">
      <thead>
        <tr>
          <th>${esc(t('offer.pdf.courier'))}</th>
          <th>${esc(t('offer.pdf.status'))}</th>
          <th>${esc(t('courier.criteria'))}</th>
          <th>${esc(t('offer.pdf.price'))}</th>
          <th>${esc(t('courier.why'))}</th>
        </tr>
      </thead>
      <tbody>${courierRows || `<tr><td colspan="5">—</td></tr>`}</tbody>
    </table>
    <p class="doc-id">${esc(evalResult.assumptions || (CR && CR.ASSUMPTIONS) || '')}</p>`
        : `<p class="doc-id">${esc(t('offer.pdf.noCountry'))}</p>`
    }

    <div class="disclaimer">${esc(t('offer.pdf.disclaimer'))}</div>
    <p class="foot">${esc(t('offer.pdf.footer'))}</p>
  </article>
  <script>window.onload=function(){ /* ready for print */ };<\/script>
</body>
</html>`;
  }

  async function openOfferPdf(result, opts = {}) {
    if (!result || result.error) return false;
    const logoSrc = await resolveLogoSrc();
    const html = buildOfferHtml(result, { ...opts, logoSrc });
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const w = window.open(url, '_blank');
    if (!w) {
      const a = document.createElement('a');
      a.href = url;
      a.download =
        'paletyzator-oferta-' +
        (result.L || '') +
        'x' +
        (result.W || '') +
        '.html';
      a.click();
    }
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    return true;
  }

  global.PaletyzatorOfferPdf = {
    buildOfferHtml,
    openOfferPdf,
    resolveLogoSrc,
  };
})(typeof window !== 'undefined' ? window : globalThis);
