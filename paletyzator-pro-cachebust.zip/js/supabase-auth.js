/**
 * Paletyzator Pro — klient Supabase Auth (e-mail + hasło).
 * Wymaga: @supabase/supabase-js (CDN) oraz window.PALETYZATOR_CONFIG.
 */
(function (global) {
  'use strict';

  const PLACEHOLDER_RE =
    /YOUR_PROJECT_REF|YOUR_SUPABASE_ANON_KEY|your-project/i;

  function getConfig() {
    const c = global.PALETYZATOR_CONFIG || {};
    return {
      supabaseUrl: String(c.supabaseUrl || '').trim(),
      supabaseAnonKey: String(c.supabaseAnonKey || '').trim(),
      siteUrl: String(c.siteUrl || '').trim().replace(/\/$/, ''),
    };
  }

  function isConfigured() {
    const { supabaseUrl, supabaseAnonKey } = getConfig();
    if (!supabaseUrl || !supabaseAnonKey) return false;
    if (PLACEHOLDER_RE.test(supabaseUrl) || PLACEHOLDER_RE.test(supabaseAnonKey)) {
      return false;
    }
    return /^https?:\/\//i.test(supabaseUrl);
  }

  /**
   * Baza redirectów Auth.
   * Preferuj bieżący origin+katalog gdy aplikacja jest hostowana (http/https),
   * żeby litterbox / podkatalog nie gubił ścieżki. siteUrl z config to fallback
   * (localhost / file://).
   */
  function getRedirectBase() {
    try {
      if (typeof location !== 'undefined' && /^https?:$/i.test(location.protocol)) {
        const path = location.pathname || '/';
        const dir = path.endsWith('/')
          ? path
          : path.replace(/\/[^/]*$/, '/');
        return (location.origin + dir).replace(/\/$/, '');
      }
    } catch (_) { /* ignore */ }
    const { siteUrl } = getConfig();
    if (siteUrl) return siteUrl.replace(/\/$/, '');
    return '';
  }

  /** Pełny URL powrotu z e-maila (ta sama strona + opcjonalny hash UI). */
  function getEmailRedirectTo(hashPath) {
    const hash =
      hashPath && !hashPath.startsWith('#') ? '#' + hashPath : hashPath || '';
    try {
      if (typeof location !== 'undefined' && /^https?:$/i.test(location.protocol)) {
        const u = new URL(location.href);
        u.search = '';
        u.hash = hash ? hash.replace(/^#/, '') : '';
        // URL.hash setter wants without #; keep leading #
        const out = u.origin + u.pathname + (hash || '');
        return out;
      }
    } catch (_) { /* ignore */ }
    const base = getRedirectBase();
    if (!base) return undefined;
    return base + '/index.html' + hash;
  }

  let _client = null;

  function getClient() {
    if (!isConfigured()) return null;
    if (_client) return _client;
    const lib = global.supabase;
    if (!lib || typeof lib.createClient !== 'function') {
      console.warn('[PaletyzatorAuth] Brak @supabase/supabase-js — dołącz skrypt CDN.');
      return null;
    }
    const { supabaseUrl, supabaseAnonKey } = getConfig();
    _client = lib.createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
        detectSessionInUrl: true,
        flowType: 'implicit',
      },
    });
    return _client;
  }

  function tLocal(key, fallback) {
    if (global.I18n && typeof global.I18n.t === 'function') {
      const v = global.I18n.t(key);
      if (v && v !== key) return v;
    }
    return fallback || key;
  }

  function plError(err) {
    if (!err) return tLocal('auth.err.unknown', 'Wystąpił nieznany błąd.');
    const msg = String(
      err.message || err.error_description || err.msg || err.error_code || err
    );
    const code = String(err.error_code || err.code || '');
    if (
      /over_email_send_rate_limit/i.test(msg) ||
      /over_email_send_rate_limit/i.test(code) ||
      /Email rate limit/i.test(msg)
    ) {
      return tLocal(
        'auth.err.rateLimit',
        'Limit e-maili Auth (Supabase) — poczekaj ok. 1 godzinę albo włącz Custom SMTP Resend (docs/resend-dns-smtp.md).'
      );
    }
    const map = [
      [/Invalid login credentials/i, 'auth.err.credentials', 'Nieprawidłowy e-mail lub hasło.'],
      [/Email not confirmed/i, 'auth.err.notConfirmed', 'Potwierdź adres e-mail — sprawdź skrzynkę (i spam).'],
      [/User already registered/i, 'auth.err.exists', 'Konto z tym e-mailem już istnieje. Zaloguj się lub zresetuj hasło.'],
      [/Password should be at least/i, 'auth.err.short', 'Hasło jest za krótkie (min. 6–8 znaków wg ustawień Auth).'],
      [/Unable to validate email/i, 'auth.err.email', 'Nieprawidłowy adres e-mail.'],
      [/email_address_invalid|Email address .* is invalid/i, 'auth.err.emailInvalid', 'Nieprawidłowy lub zablokowany adres e-mail.'],
      [/For security purposes/i, 'auth.err.securityWait', 'Ze względów bezpieczeństwa poczekaj chwilę i spróbuj ponownie.'],
      [/NetworkError|Failed to fetch/i, 'auth.err.network', 'Brak połączenia z Supabase. Sprawdź internet i URL projektu.'],
      [/Signup requires a valid password/i, 'auth.err.short', 'Podaj prawidłowe hasło.'],
      [/new password should be different/i, 'auth.err.passwordSame', 'Nowe hasło musi różnić się od poprzedniego.'],
    ];
    for (const [re, key, fallback] of map) {
      if (re.test(msg)) return tLocal(key, fallback);
    }
    return msg;
  }

  async function signUp(email, password) {
    const client = getClient();
    if (!client) throw new Error('Brak konfiguracji Supabase (js/config.js).');
    const emailRedirectTo = getEmailRedirectTo('#auth=verified');
    const { data, error } = await client.auth.signUp({
      email,
      password,
      options: emailRedirectTo ? { emailRedirectTo } : undefined,
    });
    if (error) throw Object.assign(error, { plMessage: plError(error) });
    return data;
  }

  async function signIn(email, password) {
    const client = getClient();
    if (!client) throw new Error('Brak konfiguracji Supabase (js/config.js).');
    const { data, error } = await client.auth.signInWithPassword({ email, password });
    if (error) throw Object.assign(error, { plMessage: plError(error) });
    return data;
  }

  async function signOut() {
    const client = getClient();
    if (!client) return;
    const { error } = await client.auth.signOut();
    if (error) throw Object.assign(error, { plMessage: plError(error) });
  }

  async function resetPasswordForEmail(email) {
    const client = getClient();
    if (!client) throw new Error('Brak konfiguracji Supabase (js/config.js).');
    const redirectTo = getEmailRedirectTo('#auth=reset');
    const { data, error } = await client.auth.resetPasswordForEmail(email, {
      redirectTo,
    });
    if (error) throw Object.assign(error, { plMessage: plError(error) });
    return data;
  }

  async function updatePassword(newPassword) {
    const client = getClient();
    if (!client) throw new Error('Brak konfiguracji Supabase (js/config.js).');
    const { data, error } = await client.auth.updateUser({ password: newPassword });
    if (error) throw Object.assign(error, { plMessage: plError(error) });
    return data;
  }

  async function resendConfirmation(email) {
    const client = getClient();
    if (!client) throw new Error('Brak konfiguracji Supabase (js/config.js).');
    const emailRedirectTo = getEmailRedirectTo('#auth=verified');
    const { data, error } = await client.auth.resend({
      type: 'signup',
      email,
      options: emailRedirectTo ? { emailRedirectTo } : undefined,
    });
    if (error) throw Object.assign(error, { plMessage: plError(error) });
    return data;
  }

  async function getSession() {
    const client = getClient();
    if (!client) return null;
    const { data, error } = await client.auth.getSession();
    if (error) throw Object.assign(error, { plMessage: plError(error) });
    return data.session || null;
  }

  function onAuthStateChange(cb) {
    const client = getClient();
    if (!client) return { data: { subscription: { unsubscribe() {} } } };
    return client.auth.onAuthStateChange(cb);
  }

  /** Odczytaj typ zdarzenia z hash/query (recovery / signup). */
  function peekAuthUrlHints() {
    const out = { type: null, hasTokens: false };
    try {
      const hash = (location.hash || '').replace(/^#/, '');
      const params = new URLSearchParams(hash);
      const q = new URLSearchParams(location.search || '');
      const type = params.get('type') || q.get('type');
      if (type) out.type = type;
      if (params.get('access_token') || params.get('refresh_token')) out.hasTokens = true;
      const h = location.hash || '';
      if (h.includes('auth=reset')) out.ui = 'reset';
      if (h.includes('auth=verified')) out.ui = 'verified';
    } catch (_) { /* ignore */ }
    return out;
  }

  function clearAuthHash() {
    try {
      if (location.hash && /access_token|refresh_token|auth=/.test(location.hash)) {
        history.replaceState(null, '', location.pathname + location.search);
      }
    } catch (_) { /* ignore */ }
  }

  global.PaletyzatorAuth = {
    getConfig,
    isConfigured,
    getClient,
    getEmailRedirectTo,
    getRedirectBase,
    plError,
    signUp,
    signIn,
    signOut,
    resetPasswordForEmail,
    updatePassword,
    resendConfirmation,
    getSession,
    onAuthStateChange,
    peekAuthUrlHints,
    clearAuthHash,
  };
})(typeof window !== 'undefined' ? window : globalThis);
