/**
 * Paletyzator Pro — międzynarodowy list przewozowy CMR (układ klasyczny 1–24).
 * 4 egzemplarze (3 oryginały + 1 kopia), HTML do druku, dane z paletyzacji.
 */
(function (global) {
  'use strict';

  const COPIES = [
    {
      n: 1,
      pl: 'Egzemplarz 1/4 — dla nadawcy',
      de: 'Ausfertigung 1 — für den Absender',
      en: 'Copy 1 — for the sender',
      tint: '#fff0f0',
      ink: '#8b1a1a',
    },
    {
      n: 2,
      pl: 'Egzemplarz 2/4 — dla odbiorcy',
      de: 'Ausfertigung 2 — für den Empfänger',
      en: 'Copy 2 — for the consignee',
      tint: '#eef4ff',
      ink: '#1a3a8b',
    },
    {
      n: 3,
      pl: 'Egzemplarz 3/4 — dla przewoźnika',
      de: 'Ausfertigung 3 — für den Frachtführer',
      en: 'Copy 3 — for the carrier',
      tint: '#eef8ee',
      ink: '#1a5c1a',
    },
    {
      n: 4,
      pl: 'Egzemplarz 4/4 — kopia',
      de: 'Ausfertigung 4 — Kopie',
      en: 'Copy 4 — copy',
      tint: '#ffffff',
      ink: '#111111',
    },
  ];

  function esc(s) {
    return String(s ?? '').replace(
      /[&<>"']/g,
      (c) =>
        ({
          '&': '&amp;',
          '<': '&lt;',
          '>': '&gt;',
          '"': '&quot;',
          "'": '&#39;',
        })[c]
    );
  }

  function nl(s) {
    return esc(s).replace(/\n/g, '<br>');
  }

  function defaultParties(overrides = {}) {
    return {
      sender:
        overrides.sender ||
        'Firma Demo Sp. z o.o.\nul. Logistyczna 1\n00-001 Warszawa\nPolska',
      consignee:
        overrides.consignee ||
        'Odbiorca Demo S.A.\nul. Magazynowa 12\n30-001 Kraków\nPolska',
      deliveryPlace:
        overrides.deliveryPlace ||
        'Magazyn Kraków — ul. Magazynowa 12, 30-001 Kraków',
      takeOverPlace:
        overrides.takeOverPlace ||
        'Magazyn Warszawa — ul. Logistyczna 1, 00-001 Warszawa',
      carrier:
        overrides.carrier ||
        'Przewoźnik Demo Sp. z o.o.\nul. Transportowa 5\n00-100 Warszawa\nPolska',
      senderInstructions:
        overrides.senderInstructions ||
        'Ładunek na palecie EUR. Chronić przed wilgocią. Nie sztaplować powyżej limitu wysokości.',
      ...overrides,
    };
  }

  function goodsFromResult(result) {
    const boxes = result.boxes || [];
    const lines = boxes.map((b) => {
      const label = (b.sku || 'SKU').replace(/\s*—\s*.*$/, '') || 'SKU';
      const name = (b.sku || '').includes('—')
        ? b.sku.split('—').slice(1).join('—').trim()
        : label;
      return {
        marks: label,
        packages: b.count,
        packing: 'Karton tekturowy',
        nature: `${name || label} · ${b.l}×${b.w}×${b.h} cm`,
        weight: (b.count * (b.weight || 0)).toFixed(2),
        volume: (((b.l * b.w * b.h) / 1e6) * b.count).toFixed(3),
      };
    });

    const totalPackages =
      result.loadedBoxes ?? boxes.reduce((s, b) => s + b.count, 0);
    const totalWeight = Number(result.weight || 0).toFixed(2);
    const totalVolume = lines
      .reduce((s, l) => s + Number(l.volume), 0)
      .toFixed(3);

    const palletNote = `Paleta: ${result.pallet || `${result.L}×${result.W} cm`} · warstw: ${result.layers ?? '—'} · wys. całkowita: ${Number(result.height || 0).toFixed(1)} cm · ułożono ${result.loadedBoxes}/${result.totalBoxes} kart.`;

    return { lines, totalPackages, totalWeight, totalVolume, palletNote };
  }

  function trilabel(pl, de, en) {
    return `<span class="lbl"><b>${esc(pl)}</b><br>${esc(de)}<br>${esc(en)}</span>`;
  }

  function emptyGoodsRows(count) {
    let html = '';
    for (let i = 0; i < count; i++) {
      html += `<tr class="goods-blank">
        <td contenteditable="true">&nbsp;</td>
        <td contenteditable="true">&nbsp;</td>
        <td contenteditable="true">&nbsp;</td>
        <td contenteditable="true">&nbsp;</td>
        <td contenteditable="true">&nbsp;</td>
        <td contenteditable="true">&nbsp;</td>
        <td contenteditable="true">&nbsp;</td>
      </tr>`;
    }
    return html;
  }

  function buildSheet(copy, result, parties, opts) {
    const p = parties;
    const g = goodsFromResult(result);
    const today = opts.today;
    const docNo = opts.docNo;
    const logoSrc = opts.logoSrc;

    const goodsRows = g.lines
      .map(
        (l) => `<tr>
        <td contenteditable="true">${esc(l.marks)}</td>
        <td class="c" contenteditable="true">${esc(l.packages)}</td>
        <td contenteditable="true">${esc(l.packing)}</td>
        <td contenteditable="true">${esc(l.nature)}</td>
        <td contenteditable="true">—</td>
        <td class="r" contenteditable="true">${esc(l.weight)}</td>
        <td class="r" contenteditable="true">${esc(l.volume)}</td>
      </tr>`
      )
      .join('');

    const blanks = Math.max(0, 2 - g.lines.length);

    return `
<article class="sheet" id="copy-${copy.n}" data-copy="${copy.n}" style="--tint:${copy.tint};--ink:${copy.ink}">
  <div class="sheet-outer">
    <div class="copy-banner" aria-label="${esc(copy.pl)}">
      <span class="copy-n">${copy.n}</span>
      <span class="copy-meta">
        <strong>${esc(copy.pl)}</strong>
        <em>${esc(copy.de)}</em>
        <em>${esc(copy.en)}</em>
      </span>
    </div>

    <div class="form">
      <div class="form-main">
        <header class="cmr-head">
          <div class="head-titles">
            <div class="t-pl">MIĘDZYNARODOWY SAMOCHODOWY LIST PRZEWOZOWY NR <span contenteditable="true">${esc(docNo)}</span></div>
            <div class="t-de">INTERNATIONALER FRACHTBRIEF NR</div>
            <div class="t-en">INTERNATIONAL CONSIGNMENT NOTE</div>
            <div class="oval-row">
              <div class="head-brand">
                <img src="${esc(logoSrc)}" alt="Paletyzator Pro" class="brand-logo">
                <div class="brand-txt">
                  <strong>Paletyzator Pro</strong>
                  <span>Wzór roboczy · edytowalny</span>
                </div>
              </div>
              <div class="cmr-oval" title="CMR">CMR</div>
            </div>
            <div class="conv">
              Konwencja o umowie międzynarodowego przewozu drogowego towarów<br>
              Übereinkommen über den Beförderungsvertrag im internationalen Straßengüterverkehr<br>
              Convention on the Contract for the International Carriage of Goods by Road
            </div>
          </div>
        </header>

        <div class="top-grid">
          <div class="col-left">
            <section class="box b1">
              <span class="num">1</span>
              ${trilabel('Nadawca (nazwa, adres, kraj)', 'Absender (Name, Anschrift, Land)', 'Sender (name, address, country)')}
              <div class="val" contenteditable="true">${nl(p.sender)}</div>
            </section>
            <section class="box b2">
              <span class="num">2</span>
              ${trilabel('Odbiorca (nazwa, adres, kraj)', 'Empfänger (Name, Anschrift, Land)', 'Consignee (name, address, country)')}
              <div class="val" contenteditable="true">${nl(p.consignee)}</div>
            </section>
            <section class="box b3">
              <span class="num">3</span>
              ${trilabel('Miejsce przeznaczenia towaru (miejsce, kraj)', 'Auslieferungsort der Güter (Ort, Land)', 'Place of delivery of the goods (place, country)')}
              <div class="val" contenteditable="true">${nl(p.deliveryPlace)}</div>
            </section>
            <section class="box b4">
              <span class="num">4</span>
              ${trilabel('Miejsce i data załadowania towaru (miejsce, kraj, data)', 'Ort und Tag der Übernahme des Gutes (Ort, Land, Tag)', 'Place and date of taking over the goods (place, country, date)')}
              <div class="val" contenteditable="true">${nl(p.takeOverPlace)}<br>${esc(today)}</div>
            </section>
            <section class="box b5">
              <span class="num">5</span>
              ${trilabel('Załączone dokumenty', 'Beigefügte Dokumente', 'Documents attached')}
              <div class="val" contenteditable="true">Wydruk obliczenia paletyzacji · ${esc(g.palletNote)}</div>
            </section>
          </div>

          <div class="col-right">
            <section class="box b16">
              <span class="num">16</span>
              ${trilabel('Przewoźnik (nazwa, adres, kraj)', 'Frachtführer (Name, Anschrift, Land)', 'Carrier (name, address, country)')}
              <div class="val" contenteditable="true">${nl(p.carrier)}</div>
            </section>
            <section class="box b17">
              <span class="num">17</span>
              ${trilabel('Kolejni przewoźnicy (nazwa, adres, kraj)', 'Nachfolgende Frachtführer (Name, Anschrift, Land)', 'Successive carriers (name, address, country)')}
              <div class="val" contenteditable="true">—</div>
            </section>
            <section class="box b18">
              <span class="num">18</span>
              ${trilabel('Zastrzeżenia i uwagi przewoźnika', 'Vorbehalte und Bemerkungen des Frachtführers', "Carrier's reservations and observations")}
              <div class="val" contenteditable="true">—</div>
            </section>
          </div>
        </div>

        <table class="goods">
          <thead>
            <tr>
              <th class="c6"><span class="num">6</span> Cechy i numery<br>Zeichen und Nummern<br>Marks and Nos</th>
              <th class="c7"><span class="num">7</span> Liczba sztuk<br>Anzahl der Packstücke<br>Number of packages</th>
              <th class="c8"><span class="num">8</span> Sposób opakowania<br>Art der Verpackung<br>Method of packing</th>
              <th class="c9"><span class="num">9</span> Rodzaj towaru<br>Bezeichnung des Gutes<br>Nature of the goods</th>
              <th class="c10"><span class="num">10</span> Nr statystyczny<br>Statistiknummer<br>Statistical number</th>
              <th class="c11"><span class="num">11</span> Waga brutto kg<br>Bruttogewicht in kg<br>Gross weight in kg</th>
              <th class="c12"><span class="num">12</span> Objętość m³<br>Volumen in m³<br>Volume in m³</th>
            </tr>
          </thead>
          <tbody>
            ${goodsRows}
            ${emptyGoodsRows(blanks)}
            <tr class="totals">
              <td colspan="5" class="tot-lbl">Razem / Zusammen / Total — szt. (7): <strong contenteditable="true">${esc(g.totalPackages)}</strong></td>
              <td class="r" contenteditable="true"><strong>${esc(g.totalWeight)}</strong></td>
              <td class="r" contenteditable="true"><strong>${esc(g.totalVolume)}</strong></td>
            </tr>
          </tbody>
        </table>

        <div class="adr-row">
          <span class="adr-title">Klasa · Klasse · Class</span>
          <span class="adr-field" contenteditable="true">&nbsp;</span>
          <span class="adr-title">Cyfra · Ziffer · Number</span>
          <span class="adr-field" contenteditable="true">&nbsp;</span>
          <span class="adr-title">Litera · Buchstabe · Letter</span>
          <span class="adr-field" contenteditable="true">&nbsp;</span>
          <span class="adr-title">(ADR)</span>
          <span class="adr-field wide" contenteditable="true">&nbsp;</span>
        </div>

        <div class="mid-grid">
          <div class="mid-left">
            <section class="box b13">
              <span class="num">13</span>
              ${trilabel('Instrukcje nadawcy', 'Anweisungen des Absenders', "Sender's instructions")}
              <div class="val" contenteditable="true">${nl(p.senderInstructions)}</div>
            </section>
            <section class="box b14">
              <span class="num">14</span>
              ${trilabel('Postanowienia odnośnie przewoźnego', 'Vorschriften betr. der Frachtzahlung', 'Instructions as to payment for carriage')}
              <div class="val checks">
                <label><input type="checkbox"> Opłacone / franko / Carriage paid</label>
                <label><input type="checkbox" checked> Nieopłacone / unfrei / Carriage forward</label>
              </div>
            </section>
          </div>
          <div class="mid-right">
            <section class="box b19">
              <span class="num">19</span>
              ${trilabel('Postanowienia specjalne', 'Besondere Vereinbarungen', 'Special agreements')}
              <div class="val" contenteditable="true">Ładunek zgodny z obliczeniem Paletyzator Pro.</div>
            </section>
          </div>
        </div>

        <div class="pay-grid">
          <div class="pay-left">
            <section class="box b21">
              <span class="num">21</span>
              ${trilabel('Wystawiono w / dnia', 'Ausgefertigt in / am', 'Established in / on')}
              <div class="val" contenteditable="true">Warszawa, ${esc(today)}</div>
            </section>
          </div>
          <div class="pay-right">
            <section class="box b20">
              <span class="num">20</span>
              ${trilabel('Do zapłacenia przez', 'Zu zahlen von', 'To be paid by')}
              <table class="pay-table">
                <thead>
                  <tr>
                    <th></th>
                    <th>Nadawca<br>Absender<br>Sender</th>
                    <th>Waluta<br>Währung<br>Currency</th>
                    <th>Odbiorca<br>Empfänger<br>Consignee</th>
                  </tr>
                </thead>
                <tbody>
                  <tr><td>Przewoźne / Fracht / Carriage charges</td><td contenteditable="true"></td><td contenteditable="true">PLN</td><td contenteditable="true"></td></tr>
                  <tr><td>Zniżki / Ermäßigungen / Reductions</td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td></tr>
                  <tr><td>Saldo / Saldo / Balance</td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td></tr>
                  <tr><td>Dopłaty / Zuschläge / Supplements</td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td></tr>
                  <tr><td>Różne / Nebenspesen / Miscellaneous</td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td></tr>
                  <tr><td><strong>Razem / Gesamt / Total</strong></td><td contenteditable="true"></td><td contenteditable="true"></td><td contenteditable="true"></td></tr>
                </tbody>
              </table>
            </section>
            <section class="box b15">
              <span class="num">15</span>
              ${trilabel('Pobranie (COD)', 'Nachnahme', 'Cash on delivery')}
              <div class="val lines" contenteditable="true"><br><br></div>
            </section>
          </div>
        </div>

        <div class="sig-grid">
          <section class="box b22">
            <span class="num">22</span>
            ${trilabel('Podpis i stempel nadawcy', 'Unterschrift und Stempel des Absenders', 'Signature and stamp of the sender')}
            <div class="val sig" contenteditable="true"><br><br><br></div>
          </section>
          <section class="box b23">
            <span class="num">23</span>
            ${trilabel('Podpis i stempel przewoźnika', 'Unterschrift und Stempel des Frachtführers', 'Signature and stamp of the carrier')}
            <div class="val sig" contenteditable="true"><br><br><br></div>
          </section>
          <section class="box b24">
            <span class="num">24</span>
            ${trilabel('Przesyłkę otrzymano — miejsce, data, podpis i stempel odbiorcy', 'Güter empfangen — Ort, Datum, Unterschrift und Stempel des Empfängers', 'Goods received — place, date, signature and stamp of the consignee')}
            <div class="val sig" contenteditable="true"><br><br><br></div>
          </section>
        </div>

        <footer class="form-foot">
          <span class="foot-legal">
            Niniejszy przewóz podlega Konwencji CMR / This carriage is subject to the CMR Convention /
            Dieser Transport unterliegt dem CMR-Übereinkommen.
          </span>
          Dokument wygenerowany przez <strong>Paletyzator Pro</strong> · układ pól 1–24 ·
          ${esc(copy.pl)} · wzór roboczy do druku — zweryfikuj dane przed użyciem.
        </footer>
      </div>
    </div>
  </div>
</article>`;
  }

  function cmrStyles() {
    return `
  @page { size: A4 portrait; margin: 0; }
  * { box-sizing: border-box; }
  html { scroll-behavior: smooth; }
  body {
    margin: 0;
    font-family: "Times New Roman", Times, "Liberation Serif", Georgia, serif;
    font-size: 8px;
    color: #000;
    background: #c8cdd4;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }
  .toolbar {
    position: sticky; top: 0; z-index: 20;
    display: flex; gap: 8px; align-items: center; flex-wrap: wrap;
    padding: 10px 14px;
    background: #0b121e; color: #fff;
    font-family: system-ui, sans-serif; font-size: 13px;
  }
  .toolbar strong { margin-right: 4px; }
  .toolbar button, .toolbar a.tab {
    border: 0; border-radius: 8px; padding: 7px 12px; font-weight: 650;
    cursor: pointer; text-decoration: none; color: inherit; font: inherit;
    background: #e8edf5; color: #0b121e;
  }
  .toolbar .print { background: #245eea; color: #fff; }
  .toolbar .tab.active { background: #fff; outline: 2px solid #245eea; }
  .toolbar .hint { opacity: 0.8; font-size: 12px; margin-left: auto; }
  .sheets { padding: 14px 10px 40px; display: flex; flex-direction: column; align-items: center; gap: 18px; }

  /* Screen: one A4-sized card; print locks size below */
  .sheet {
    width: 210mm;
    min-height: 297mm;
    color: #000;
    background: #fff;
    box-shadow: 0 10px 32px rgba(0,0,0,.22);
    border: 1px solid #888;
    overflow: hidden;
  }
  .sheet-outer {
    position: relative;
    padding: 3mm 4mm 3mm 4mm;
    height: 100%;
  }
  .copy-banner {
    display: flex; align-items: center; gap: 8px;
    margin-bottom: 2mm;
    padding: 1mm 2mm;
    border: 1.2px solid #000;
    color: var(--ink, #111);
  }
  .copy-n {
    font-size: 22px; font-weight: 800; line-height: 1;
    font-family: Arial, Helvetica, sans-serif;
    min-width: 8mm; text-align: center;
  }
  .copy-meta {
    display: flex; flex-wrap: wrap; gap: 2px 10px;
    font-size: 7.5px; line-height: 1.25;
  }
  .copy-meta em { font-style: normal; opacity: 0.9; }

  .form {
    border: 1.4px solid #000;
    background: #fff;
  }
  .form-main { display: flex; flex-direction: column; min-width: 0; width: 100%; }

  .cmr-head { border-bottom: 1.2px solid #000; }
  .head-titles { padding: 2px 6px 3px; text-align: center; }
  .t-pl { font-weight: 700; font-size: 9.5px; letter-spacing: 0.02em; }
  .t-de, .t-en { font-size: 7.5px; font-weight: 600; }
  .oval-row {
    display: flex; align-items: center; justify-content: center; gap: 12px;
    margin: 2px 0 1px;
  }
  .head-brand {
    display: flex; align-items: center; gap: 5px; text-align: left;
    max-width: 50mm;
  }
  .brand-logo { width: 26px; height: 26px; object-fit: contain; flex-shrink: 0; }
  .brand-txt strong { display: block; font-size: 10px; font-family: Arial, Helvetica, sans-serif; }
  .brand-txt span { font-size: 6px; color: #333; }
  .cmr-oval {
    display: inline-block;
    padding: 2px 26px; border: 2px solid #000; border-radius: 999px;
    font-family: Arial, Helvetica, sans-serif; font-weight: 800;
    font-size: 20px; letter-spacing: 0.16em; line-height: 1.1;
  }
  .conv { font-size: 5.4px; line-height: 1.2; color: #222; margin-top: 1px; }

  .box {
    position: relative;
    border-bottom: 1px solid #000;
    border-right: 1px solid #000;
    padding: 1px 3px 2px 12px;
    min-height: 11mm;
  }
  .box .num {
    position: absolute; left: 2px; top: 1px;
    font-weight: 800; font-size: 9px; font-family: Arial, sans-serif;
  }
  .box .lbl {
    display: block; font-size: 5.4px; line-height: 1.12; color: #222; margin-bottom: 1px;
  }
  .box .lbl b { font-size: 6px; }
  .box .val {
    font-size: 8.5px; line-height: 1.25; min-height: 1em; outline: none;
  }
  .box .val.sig { min-height: 14mm; }
  .box .checks { display: flex; flex-direction: column; gap: 1px; font-size: 7.5px; }
  .box .checks label { display: flex; align-items: center; gap: 4px; }
  .box .lines { border-bottom: 1px solid #666; min-height: 9mm; }

  .top-grid {
    display: grid;
    grid-template-columns: 1.15fr 0.85fr;
  }
  .col-left .box:last-child, .col-right .box:last-child { border-bottom: 0; }
  .col-left { border-bottom: 1px solid #000; }
  .col-right { border-bottom: 1px solid #000; }
  .b1, .b2, .b16, .b17 { min-height: 16mm; }
  .b3, .b4, .b5, .b18 { min-height: 11mm; }
  .b5 { border-bottom: 0 !important; }

  .goods {
    width: 100%; border-collapse: collapse;
    border-top: 1px solid #000; border-bottom: 1px solid #000;
  }
  .goods th, .goods td {
    border: 1px solid #000; padding: 1px 2px; vertical-align: top;
    font-size: 7.5px; font-weight: 400;
  }
  .goods th {
    font-size: 5.2px; line-height: 1.12; text-align: left;
  }
  .goods th .num { font-size: 8px; margin-right: 2px; }
  .goods .c6 { width: 14%; }
  .goods .c7 { width: 9%; }
  .goods .c8 { width: 12%; }
  .goods .c9 { width: 28%; }
  .goods .c10 { width: 11%; }
  .goods .c11 { width: 13%; }
  .goods .c12 { width: 13%; }
  .goods td.c { text-align: center; }
  .goods td.r { text-align: right; }
  .goods .goods-blank td { height: 6mm; }
  .goods .totals td { font-size: 7.5px; }
  .goods .tot-lbl { text-align: right; }

  .adr-row {
    display: grid;
    grid-template-columns: auto 1fr auto 1fr auto 1fr auto 1.4fr;
    border-bottom: 1px solid #000; font-size: 5.5px;
  }
  .adr-title {
    padding: 2px 3px; border-right: 1px solid #000;
    display: flex; align-items: center; white-space: nowrap;
  }
  .adr-field {
    padding: 2px 3px; border-right: 1px solid #000; min-height: 6mm;
    font-size: 8px; outline: none;
  }
  .adr-field.wide { border-right: 0; }

  .mid-grid {
    display: grid;
    grid-template-columns: 1.15fr 0.85fr;
  }
  .mid-left .box, .mid-right .box { min-height: 16mm; }
  .b13 { min-height: 18mm; }
  .b14 { border-bottom: 0; }
  .b19 { min-height: 24mm; border-bottom: 0; }

  .pay-grid {
    display: grid;
    grid-template-columns: 0.7fr 1.3fr;
    border-top: 1px solid #000;
  }
  .b21 { min-height: 20mm; border-bottom: 0; }
  .b20 { min-height: 32mm; padding-bottom: 1px; }
  .b15 { min-height: 12mm; border-bottom: 0; }
  .pay-table {
    width: 100%; border-collapse: collapse; margin-top: 1px; font-size: 6px;
  }
  .pay-table th, .pay-table td {
    border: 1px solid #000; padding: 1px 2px; vertical-align: middle;
  }
  .pay-table th { font-weight: 600; line-height: 1.1; }
  .pay-table td:first-child { width: 38%; font-size: 5.5px; }
  .pay-table td[contenteditable] { min-width: 10mm; height: 4mm; font-size: 7.5px; }

  .sig-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    border-top: 1px solid #000;
  }
  .sig-grid .box { min-height: 22mm; border-bottom: 0; }
  .sig-grid .box:last-child { border-right: 0; }

  .form-foot {
    border-top: 1px solid #000; padding: 2px 4px;
    font-size: 5.4px; color: #222; line-height: 1.3;
  }
  .foot-legal { display: block; margin-bottom: 1px; }

  [contenteditable="true"]:focus {
    outline: 1px solid #c9a000;
  }

  /* —— PRINT: exactly 4 A4 pages, real borders, no writing-mode/transform —— */
  @media print {
    @page { size: A4 portrait; margin: 0; }
    html, body {
      width: 210mm;
      margin: 0 !important;
      padding: 0 !important;
      background: #fff !important;
      -webkit-print-color-adjust: exact;
      print-color-adjust: exact;
    }
    .toolbar, .no-print, script { display: none !important; }
    .sheets {
      display: block;
      padding: 0 !important;
      margin: 0 !important;
      gap: 0 !important;
    }
    .sheet {
      width: 210mm !important;
      height: 297mm !important;
      min-height: 0 !important;
      max-height: 297mm !important;
      margin: 0 !important;
      padding: 0 !important;
      border: 0 !important;
      box-shadow: none !important;
      background: #fff !important;
      overflow: hidden !important;
      page-break-after: always;
      break-after: page;
      page-break-inside: avoid;
      break-inside: avoid;
    }
    .sheet:last-child {
      page-break-after: auto;
      break-after: auto;
    }
    .sheet-outer {
      padding: 4mm !important;
      height: 297mm;
      max-height: 297mm;
      overflow: hidden;
    }
    .copy-banner {
      writing-mode: horizontal-tb !important;
      transform: none !important;
      margin-bottom: 1.5mm;
    }
    .form {
      writing-mode: horizontal-tb !important;
      transform: none !important;
      height: auto;
      max-height: calc(297mm - 8mm - 9mm);
      overflow: hidden;
    }
    .form-main, .top-grid, .mid-grid, .pay-grid, .sig-grid, .adr-row, .goods {
      writing-mode: horizontal-tb !important;
      transform: none !important;
    }
    /* Borders print without “background graphics” — avoid bg fills */
    .goods th, .goods .totals td, .adr-title, .pay-table th {
      background: transparent !important;
    }
    [contenteditable="true"]:focus {
      outline: none;
    }
  }
`;
  }

  function buildCmrHtml(result, parties = {}, opts = {}) {
    const p = defaultParties(parties);
    const today = new Date().toLocaleDateString('pl-PL');
    const docNo = opts.docNo || 'CMR-' + Date.now().toString().slice(-8);
    const logoSrc = opts.logoSrc || 'assets/logo-paletyzator-pro.png';
    const shared = { today, docNo, logoSrc };

    const sheets = COPIES.map((c) => buildSheet(c, result, p, shared)).join('\n');

    const tabs = COPIES.map(
      (c) =>
        `<a class="tab" href="#copy-${c.n}" data-copy="${c.n}">${c.n}/4</a>`
    ).join('');

    return `<!DOCTYPE html>
<html lang="pl">
<head>
<meta charset="UTF-8">
<title>CMR ×4 — Paletyzator Pro · ${esc(docNo)}</title>
<style>${cmrStyles()}</style>
</head>
<body>
  <div class="toolbar no-print">
    <strong>CMR · Paletyzator Pro</strong>
    <button class="print" type="button" onclick="window.print()">Drukuj wszystkie 4</button>
    <button type="button" onclick="window.close()">Zamknij</button>
    ${tabs}
    <span class="hint">3 oryginały + 1 kopia · pola edytowalne · ${esc(docNo)}</span>
  </div>
  <div class="sheets">
    ${sheets}
  </div>
  <script>
    (function () {
      var tabs = document.querySelectorAll('.toolbar .tab');
      function setActive() {
        var hash = location.hash || '#copy-1';
        tabs.forEach(function (t) {
          t.classList.toggle('active', t.getAttribute('href') === hash);
        });
      }
      tabs.forEach(function (t) {
        t.addEventListener('click', function () {
          setTimeout(setActive, 0);
        });
      });
      window.addEventListener('hashchange', setActive);
      setActive();
    })();
  <\/script>
</body>
</html>`;
  }

  let _logoDataUrlCache = null;

  async function logoAsDataUrl() {
    if (_logoDataUrlCache) return _logoDataUrlCache;
    const src = new URL(
      'assets/logo-paletyzator-pro.png',
      window.location.href
    ).href;
    try {
      const res = await fetch(src);
      const blob = await res.blob();
      _logoDataUrlCache = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(blob);
      });
    } catch (e) {
      _logoDataUrlCache =
        'data:image/svg+xml,' +
        encodeURIComponent(
          '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><rect fill="#0b121e" width="64" height="64" rx="12"/><text x="32" y="40" text-anchor="middle" fill="#3b7aef" font-size="28" font-family="sans-serif" font-weight="700">P</text></svg>'
        );
    }
    return _logoDataUrlCache;
  }

  function closeCmrModal() {
    const root = document.getElementById('cmr-modal-root');
    if (!root) return;
    const frame = root.querySelector('.cmr-frame');
    const blobUrl = frame && frame.dataset.blobUrl;
    if (blobUrl) {
      try {
        URL.revokeObjectURL(blobUrl);
      } catch (_) {
        /* ignore */
      }
    }
    root.innerHTML = '';
    document.removeEventListener('keydown', onCmrEscape, true);
  }

  function onCmrEscape(ev) {
    if (ev.key === 'Escape') {
      ev.preventDefault();
      closeCmrModal();
    }
  }

  function showCmrModal(html) {
    let root = document.getElementById('cmr-modal-root');
    if (!root) {
      root = document.createElement('div');
      root.id = 'cmr-modal-root';
      document.body.appendChild(root);
    }
    root.innerHTML = `
      <div class="cmr-overlay" role="dialog" aria-modal="true" aria-label="List przewozowy CMR">
        <div class="cmr-overlay-bar">
          <strong>CMR · 4 egzemplarze · Paletyzator Pro</strong>
          <div class="cmr-overlay-actions">
            <button type="button" class="primary" id="cmr-modal-print">Drukuj wszystkie 4</button>
            <button type="button" class="quiet" id="cmr-modal-close">Zamknij</button>
          </div>
        </div>
        <iframe class="cmr-frame" title="CMR" sandbox="allow-same-origin allow-modals allow-scripts"></iframe>
      </div>`;
    const frame = root.querySelector('.cmr-frame');
    // srcdoc / blob — niezawodniejsze niż document.write (pusty grey iframe)
    let loaded = false;
    try {
      if ('srcdoc' in frame) {
        frame.srcdoc = html;
        loaded = true;
      }
    } catch (_) {
      loaded = false;
    }
    if (!loaded) {
      try {
        const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
        const blobUrl = URL.createObjectURL(blob);
        frame.dataset.blobUrl = blobUrl;
        frame.src = blobUrl;
        loaded = true;
      } catch (_) {
        loaded = false;
      }
    }
    if (!loaded) {
      try {
        const doc = frame.contentDocument;
        doc.open();
        doc.write(html);
        doc.close();
      } catch (_) {
        /* ignore */
      }
    }

    const closeBtn = root.querySelector('#cmr-modal-close');
    if (closeBtn) closeBtn.onclick = (e) => {
      e.preventDefault();
      closeCmrModal();
    };
    root.querySelector('#cmr-modal-print').onclick = () => {
      try {
        frame.contentWindow.focus();
        frame.contentWindow.print();
      } catch (_) {
        window.print();
      }
    };
    document.addEventListener('keydown', onCmrEscape, true);
    return root;
  }

  async function openCmr(result, parties, opts = {}) {
    if (!result || result.error) {
      throw new Error('Brak wyniku obliczenia do CMR.');
    }
    const logoSrc = opts.logoSrc || (await logoAsDataUrl());
    const html = buildCmrHtml(result, parties, { ...opts, logoSrc });
    // Preferuj modal w tej samej karcie — pewny render 4 egz. + działające Zamknij.
    // Nowa karta tylko gdy wymuszona (opts.forceTab) i popup dozwolony.
    if (opts.forceTab) {
      const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const w = window.open(url, '_blank');
      if (w) {
        setTimeout(() => URL.revokeObjectURL(url), 120_000);
        try {
          w.focus();
        } catch (_) {
          /* ignore */
        }
        return { mode: 'tab', window: w, url };
      }
      URL.revokeObjectURL(url);
    }

    showCmrModal(html);
    return { mode: 'modal' };
  }

  global.PaletyzatorCMR = {
    COPIES,
    defaultParties,
    goodsFromResult,
    buildCmrHtml,
    openCmr,
    showCmrModal,
    closeCmrModal,
    logoAsDataUrl,
  };
})(typeof window !== 'undefined' ? window : globalThis);
